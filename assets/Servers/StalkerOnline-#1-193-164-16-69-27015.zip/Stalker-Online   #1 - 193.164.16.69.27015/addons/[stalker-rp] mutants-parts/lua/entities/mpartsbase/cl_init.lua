include('shared.lua') --Include shared.lua

function ENT:Initialize()
end


local v = debug.getregistry().Vector
local CD = v.DistToSqr
local P = LocalPlayer
local e = debug.getregistry().Entity
local d, s = e.DrawModel, e.DrawShadow
local static = 1250*1250
function ENT:Draw()
	s(self,false)
	d(self)
end
