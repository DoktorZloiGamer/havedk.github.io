ENT.Type 		= "anim"
ENT.Base 		= "mpartsbase"
ENT.Category 		= "Mutants Parts"
ENT.PrintName	= "Хвост Кошки"
ENT.Author		= "Stalker Developers"

ENT.Spawnable		= true
ENT.AdminOnly	= true
ENT.model = "models/cat_tail.mdl"
