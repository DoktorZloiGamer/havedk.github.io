ENT.Type 		= "anim"
ENT.Base 		= "mpartsbase"
ENT.Category 		= "Mutants Parts"
ENT.PrintName	= "Рука Излома"
ENT.Author		= "Stalker Developers"

ENT.Spawnable		= true
ENT.AdminOnly	= true
ENT.model = "models/mutants_loot/izlom_hand.mdl"
