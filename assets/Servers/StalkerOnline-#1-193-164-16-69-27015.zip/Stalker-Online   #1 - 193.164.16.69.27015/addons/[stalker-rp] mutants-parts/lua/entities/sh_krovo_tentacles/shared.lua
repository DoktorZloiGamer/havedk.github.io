ENT.Type 		= "anim"
ENT.Base 		= "mpartsbase"
ENT.Category 		= "Mutants Parts"
ENT.PrintName	= "Щупальца Кровососа"
ENT.Author		= "Stalker Developers"

ENT.Spawnable		= true
ENT.AdminOnly	= true
ENT.model = "models/spec45as/stalker/quest/item_krovosos_jaw.mdl"
