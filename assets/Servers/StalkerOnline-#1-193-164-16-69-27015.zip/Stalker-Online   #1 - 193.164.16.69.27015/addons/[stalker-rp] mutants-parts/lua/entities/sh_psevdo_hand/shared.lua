ENT.Type 		= "anim"
ENT.Base 		= "mpartsbase"
ENT.Category 		= "Mutants Parts"
ENT.PrintName	= "Рука Псевдогиганта"
ENT.Author		= "Stalker Developers"

ENT.Spawnable		= true
ENT.AdminOnly	= true
ENT.model = "models/mutants_loot/psevdogigant_hand.mdl"
