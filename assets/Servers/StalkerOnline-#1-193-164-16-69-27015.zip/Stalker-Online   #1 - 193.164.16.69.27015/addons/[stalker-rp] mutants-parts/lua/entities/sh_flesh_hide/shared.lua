ENT.Type 		= "anim"
ENT.Base 		= "mpartsbase"
ENT.Category 		= "Mutants Parts"
ENT.PrintName	= "Шкура Плоти"
ENT.Author		= "Stalker Developers"

ENT.Spawnable		= true
ENT.AdminOnly	= true
ENT.model = "models/props_junk/cardboard_box004a.mdl"
