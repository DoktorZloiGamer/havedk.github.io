ENT.Type 		= "anim"
ENT.Base 		= "base_gmodentity" 
ENT.Category 		= "None"  
ENT.PrintName	= "mut base"
ENT.Author		= "бес." 
ENT.Contact		= "" 
 
ENT.Spawnable		= false
ENT.AdminSpawnable	= false