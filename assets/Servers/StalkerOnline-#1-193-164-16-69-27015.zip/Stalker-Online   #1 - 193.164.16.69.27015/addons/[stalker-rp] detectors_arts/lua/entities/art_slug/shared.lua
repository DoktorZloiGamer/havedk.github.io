ENT.Type 		= "anim"
ENT.Base 		= "artifacts_base"
ENT.Category 		= "Stalker Artefacts"

ENT.PrintName	= "Слизняк"
ENT.Author		= "Stalker Developers"
ENT.Contact		= ""

ENT.Spawnable		= true --Spawnable?
ENT.AdminOnly = true
