ENT.Type 		= "anim"
ENT.Base 		= "artifacts_base"
ENT.Category 		= "Stalker Artefacts"

ENT.PrintName	= "Ночная Звезда"
ENT.Author		= "Stalker Developers"
ENT.Contact		= ""

ENT.Spawnable		= true
ENT.AdminOnly = true
