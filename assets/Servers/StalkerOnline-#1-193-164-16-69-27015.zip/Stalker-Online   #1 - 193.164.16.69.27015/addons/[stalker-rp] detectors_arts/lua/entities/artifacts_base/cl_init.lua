include('shared.lua') --Include shared.lua

function ENT:Initialize()
end


local v = FindMetaTable('Vector')
local CD = v.DistToSqr
local P = LocalPlayer
local t = {['detector_echo'] = 1;['detector_bear'] = 2;['detector_veles'] = 3;['detector_svarog'] = 3;} -- иначе в чём смысл, есть ли детекторы будут бесполезными
local e = FindMetaTable 'Entity'
local d, s = e.DrawModel, e.DrawShadow
local anomalies = {}
anomalies["art_psi_field"] = 1
anomalies["art_control"] = 1
anomalies["art_dummy_battery"] = 1
anomalies["art_ballon"] = 2
anomalies["art_compass"] = 3
anomalies["art_crystal"] = 1
anomalies["art_eye"] = 2
anomalies["art_fireball"] = 1
anomalies["art_glass"] = 3
anomalies["art_fire"] = 3
anomalies["art_sun"] = 3
anomalies["art_electra_flash"] = 2
anomalies["art_goldfish"] = 3
anomalies["art_gravi"] = 2
anomalies["art_medusa"] = 1
anomalies["art_fuzz_kolobok"] = 2
anomalies["art_dummy_glassbeads"] = 1
anomalies["art_mincer_meat"] = 1
anomalies["art_electra_moonlight"] = 1
anomalies["art_nightstar"] = 1
anomalies["art_slug"] = 1
anomalies["art_dummy_dummy"] = 2
anomalies["art_ice"] = 3
anomalies["art_soul"] = 2
anomalies["art_electra_sparkler"] = 1
anomalies["art_blood"] = 1
anomalies["art_crystal_flower"] = 1
anomalies["art_crystal_plant"] = 1
anomalies["art_vyvert"] = 1

function ENT:Draw()
	s(self,false)
	if !self:GetNWBool("_DR") then
		local p = P()
		local c1 = (IsValid(p:GetActiveWeapon()) && p:GetActiveWeapon():GetClass()) || ''
		if c1 == '' || !t[c1] then return end

		local c2 = self:GetClass()
		if anomalies[c2] > t[c1] then return end

		local p1, p2 = self:GetPos(), p:GetPos()
		if CD(p1, p2) > (7500) and !self:GetNWBool("_DR") then return end
	end
	d(self)
end
