ENT.Type 		= "anim"
ENT.Base 		= "base_gmodentity"
ENT.Category 		= "Artefacts"
ENT.PrintName	= "Artefacts Base"
ENT.Author		= "Predator-cz"
ENT.Contact		= ""

ENT.Spawnable		= false --Spawnable?
ENT.AdminOnly = true
ENT.AutomaticFrameAdvance = true
