AddCSLuaFile( 'acrashscreen/sh_start.lua' )
include( 'acrashscreen/sh_start.lua' )