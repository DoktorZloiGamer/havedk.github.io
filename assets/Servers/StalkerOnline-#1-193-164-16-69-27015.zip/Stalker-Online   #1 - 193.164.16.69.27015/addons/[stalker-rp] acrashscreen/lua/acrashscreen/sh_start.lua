aCrashScreen = aCrashScreen or {}
local _this = aCrashScreen
_this.config = _this.config or {}

local pinclude = false

if pinclude then

	if SERVER then

		AddCSLuaFile( 'lib/cl_protected_include.lua' )

		include( 'lib/sv_protected_include.lua' )

		_this.include.includeFile( 'acrashscreen/incl/sv_main.lua' )

		_this.include.includeFile( 'acrashscreen/cl_config.lua', true )
		_this.include.includeFile( 'acrashscreen/incl/cl_menu.lua' )
		_this.include.includeFile( 'acrashscreen/incl/cl_chat.lua' )
		_this.include.includeFile( 'acrashscreen/incl/cl_main.lua' )
		_this.include.includeFile( 'acrashscreen/incl/cl_web.lua' )
		_this.include.includeFile( 'acrashscreen/incl/cl_misc.lua' )

	else

		include( 'lib/cl_protected_include.lua' )

	end

else

	if SERVER then

		AddCSLuaFile( 'cl_config.lua' )
		AddCSLuaFile( 'incl/cl_menu.lua' )
		AddCSLuaFile( 'incl/cl_chat.lua' )
		AddCSLuaFile( 'incl/cl_main.lua' )
		AddCSLuaFile( 'incl/cl_web.lua' )
		AddCSLuaFile( 'incl/cl_misc.lua' )

		include( 'incl/sv_main.lua' )

	else

		include( 'cl_config.lua' )
		include( 'incl/cl_menu.lua' )
		include( 'incl/cl_chat.lua' )
		include( 'incl/cl_main.lua' )
		include( 'incl/cl_web.lua' )
		include( 'incl/cl_misc.lua' )

	end

end
