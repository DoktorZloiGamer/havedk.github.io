local _this = aCrashScreen

surface.CreateFont( 'acrashscreen_small', {
	font = "Graffiti1CTT",
	size = 27,
	weight = 300,
	extended = true,
	antialias = true,
	shadow = false,
})

surface.CreateFont( 'acrashscreen_medium', {
	font = 'Default',
	size = 32,
	weight = 300,
	extended = true,
	antialias = true,
	shadow = true,
})

surface.CreateFont( 'acrashscreen_big', {
	font = 'Default',
	size = 36,
	weight = 600,
	extended = true,
	antialias = true,
})

surface.CreateFont( 'acrashscreen_title', {
	font = 'AmazS.T.A.L.K.E.R.v.3.0',
	size = 110,
	weight = 300,
	extended = true,
	antialias = true,
})

local crash_icon = Material('stalker/hud/crashscreen.jpg')

-- Button paint
local buttonPaint = function( pnl, w, h )

	if pnl:IsDown() then
		draw.RoundedBox(2,0,0,w,h,Color(45,40,35,200))
		surface.SetDrawColor(229,122,48)
		surface.DrawOutlinedRect(0,0,w,h,2)
	elseif pnl:IsHovered() then
		draw.RoundedBox(2,0,0,w,h,Color(25,25,25,200))
		surface.SetDrawColor(229,122,48)
		surface.DrawOutlinedRect(0,0,w,h,2)
	else
		draw.RoundedBox(2,0,0,w,h,Color(15,15,15,200))
		surface.SetDrawColor(200,200,200)
		surface.DrawOutlinedRect(0,0,w,h,1)
	end
	--draw.SimpleText('Переподключиться', 'acrashscreen_medium', 0,0,Color(238,238,238),1,1)

end

-- Button text color
local buttonUpdateColours = function( pnl, skin )
	return pnl:SetTextStyleColor( Color( 255, 255, 255 ) )
end

local TYPE_DETERMINING, TYPE_WAITFORSERVER, TYPE_DELAYED = 0, 1, 2

local PANEL = {}

function PANEL:Init()

	self:SetPos( 0, 0 )
	self:SetSize( ScrW(), ScrH() )
	self:MakePopup()

	-- Reconnect button
	self.reconnectButton = vgui.Create( 'DButton', self )
	self.reconnectButton:SetSize( 260, 46 )
	self.reconnectButton:SetPos( ScrW()*0.5 - 140, 150 )
	self.reconnectButton:SetFont( 'acrashscreen_medium' )
	self.reconnectButton:SetTextColor(Color(200,200,200))
	self.reconnectButton:SetText( "Подключиться" )

	-- Disconnect button
	self.disconnectButton = vgui.Create( 'DButton', self )
	self.disconnectButton:SetSize( 260, 46 )
	self.disconnectButton:SetPos( ScrW()*0.5 - 140, 200 )
	self.disconnectButton:SetFont( 'acrashscreen_medium' )
	self.disconnectButton:SetTextColor(Color(200,200,200))
	self.disconnectButton:SetText( "Отключиться" )

	-- Set button paint
	self.reconnectButton.Paint = buttonPaint
	self.disconnectButton.Paint = buttonPaint

	-- Set button text color
	self.reconnectButton.UpdateColours = buttonUpdateColours
	self.disconnectButton.UpdateColours = buttonUpdateColours

	-- Set button functions
	self.reconnectButton.DoClick = function( pnl )
		RunConsoleCommand( 'retry' )
	end
	self.disconnectButton.DoClick = function( pnl )
		RunConsoleCommand( 'disconnect' )
	end

	-- Create custom buttons
	local buttonsTable = _this.config.buttons
	local height = 61 * #buttonsTable - 15
	for n, button in pairs( buttonsTable ) do

		local buttonText = button[ 1 ]
		local buttonFunc = button[ 2 ]

		local button = vgui.Create( 'DButton', self )
		button:SetSize( 300, 46 )
		button:SetPos( ScrW() - 280 - 40, ScrH()*0.5 - height*0.5 + 61*(n-1) )
		button:SetFont( 'acrashscreen_small' )
		button:SetText( buttonText )

		button.Paint = buttonPaint
		button.UpdateColours = buttonUpdateColours

		if isstring( buttonFunc ) then
			button.DoClick = function( pnl ) LocalPlayer():ConCommand( 'connect ' .. buttonFunc ) end
		elseif isfunction( buttonFunc ) then
			button.DoClick = function( pnl ) buttonFunc() end
		end

	end

	-- Community name
	self.communityName = _this.config.communityName

	self.backgroundColor = _this.config.backgroundColor or Color( 0, 75, 130 )

	self.reconnectingType = TYPE_DETERMINING
	self.isServerOnline = false -- Whether the server is online or not
	self.reconnectingInTime = 10 -- Time till player is automatically reconnected

	-- Background
	self.backgroundMaterial = nil
	self.backgroundWidth = 1920
	self.backgroundHeight = 1080

end

function PANEL:setReconnectingValues( reconnectingType, isServerOnline, time )
	self.reconnectingType = reconnectingType
	self.isServerOnline = isServerOnline
	self.reconnectingInTime = time
end

function PANEL:setBackground( background )

	if not ( background and background[ 1 ] ) then return end

	local material = background[ 1 ]
	local width, height = background[ 2 ], background[ 3 ]
	local fill = background[ 4 ]

	if fill then -- Fill the image, this will cut of a part of the image if the screen ratio is different
		width = ( ScrW() * ( 2048 / width ) ) * ( width / height ) / ( ScrW() / ScrH() )
		height = width
	else -- Stretch the image, will fill up the screen with the entire image, this can make the image look bad if the screen ratio is different
		width, height = ScrW() * ( 2048 / width ), ScrH() * ( 2048 / height )
	end

	self.backgroundWidth = width
	self.backgroundHeight = height

	self.backgroundMaterial = material

end

function PANEL:Paint( w, h )

		surface.SetDrawColor( 255, 255, 255, 255 )
		surface.SetMaterial( crash_icon )
		surface.DrawTexturedRect( 0, 0, ScrW(), ScrH() )

	-- Community name
	draw.SimpleText(
		self.communityName, 'acrashscreen_title',
		w*0.5, 50, Color( 238, 238, 238 ),
		TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )

	-- Auto reconnect when the server is back up
	if self.reconnectingType == TYPE_WAITFORSERVER then

		if self.isServerOnline then

			draw.SimpleText(
				"The server is back online!", 'acrashscreen_big',
				w*0.5 + 2, 86 + 2, Color( 0, 0, 0 ),
				TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )

			draw.SimpleText(
				"The server is back online!", 'acrashscreen_big',
				w*0.5, 86, Color( 255, 255, 255 ),
				TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )

			draw.SimpleText(
				"You will be automatically reconnected in " .. self.reconnectingInTime .. " seconds.", 'acrashscreen_small',
				w*0.5 + 2, 120 + 2, Color( 0, 0, 0 ),
				TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )

			draw.SimpleText(
				"You will be automatically reconnected in " .. self.reconnectingInTime .. " seconds.", 'acrashscreen_small',
				w*0.5, 120, Color( 255, 255, 255 ),
				TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )


		else

			draw.SimpleText(
				"The server is not responding", 'acrashscreen_big',
				w*0.5 + 2, 86 + 2, Color( 0, 0, 0 ),
				TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )

			draw.SimpleText(
				"The server is not responding", 'acrashscreen_big',
				w*0.5, 86, Color( 255, 255, 255 ),
				TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )

			draw.SimpleText(
				"You will be automatically reconnected when the server is back up!", 'acrashscreen_small',
				w*0.5 + 2, 120 + 2, Color( 0, 0, 0 ),
				TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )

			draw.SimpleText(
				"You will be automatically reconnected when the server is back up!", 'acrashscreen_small',
				w*0.5, 120, Color( 255, 255, 255 ),
					TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )

		end

	-- Delayed reconnection
	elseif self.reconnectingType == TYPE_DELAYED then

		draw.SimpleText( -- Outline
			"Автоматическое переподключение " .. self.reconnectingInTime .. " сек.", 'acrashscreen_small',
			w*0.5 + 2, 100 + 5, Color( 238, 238, 238 ),
			TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )

	-- Determining
	elseif self.reconnectingType == TYPE_DETERMINING then

		draw.SimpleText(
			"The server is not responding", 'acrashscreen_big',
			w*0.5 + 2, 102 + 2, Color( 0, 0, 0 ),
			TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )

		draw.SimpleText(
			"The server is not responding", 'acrashscreen_big',
			w*0.5, 102, Color( 255, 255, 255 ),
			TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )

	end

end

vgui.Register( 'aCrashScreen-menu', PANEL, 'EditablePanel' )
