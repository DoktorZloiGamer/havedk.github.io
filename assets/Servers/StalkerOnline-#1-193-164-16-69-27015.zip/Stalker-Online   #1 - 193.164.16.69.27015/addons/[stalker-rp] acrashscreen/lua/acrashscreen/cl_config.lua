local _this = aCrashScreen.config
---------------------------------


_this.chatID = "server_one"


_this.communityName = "S.T.A.L.K.E.R"


_this.serverStatusURL = "http://127.0.0.1:8080/acrashscreen/serverstatus.php"


_this.serverOnlineReconnectingTime = 15


_this.reconnectingTime = 45


_this.serverIP = "127.0.0.1"
_this.serverPort = "27015"


_this.backgroundUrls = {
	{
		"https://images.wallpapersden.com/image/download/stalker-2_bGptaGeUmZqaraWkpJRmbmdlrWZlbWU.jpg",
		1920, 1080,
		true
	}
}


_this.backgroundColor = Color( 255, 255, 255 )


_this.songUrls = { -- NOTE:
	"https://drive.google.com/uc?export=download&id=0B91z1MPPxaoLa3JrTW4wbXFiRlU",
	"https://drive.google.com/uc?export=download&id=0B91z1MPPxaoLUG84cXNWMXdTM3c",
	"https://drive.google.com/uc?export=download&id=0B91z1MPPxaoLa05vb0pWZGlidDg"
}


_this.chatURL = "http://localhost:8080/acrashscreen/chat/chat.php"


local ranks = {}
ranks[ 'manager' ] = { Color( 125, 0, 180 ), true }
ranks[ 'donator' ] = { Color( 255, 220, 0 ), false }

function _this.getUserProperties( ply ) -- This is somewhat more advanced

	local userGroup = ply:GetUserGroup()
	if ranks[ userGroup ] then
		return ranks[ userGroup ][ 1 ], ranks[ userGroup ][ 2 ] or false
	end

	if ply:IsSuperAdmin() then return Color( 255, 0, 0 ), true end -- Any superadmin
	if ply:IsAdmin() then return Color( 255, 100, 0 ), true end -- Any admin

	return Color( 200, 200, 200 ), false -- Default color
end

-- Custom buttons
_this.buttons = {

}
