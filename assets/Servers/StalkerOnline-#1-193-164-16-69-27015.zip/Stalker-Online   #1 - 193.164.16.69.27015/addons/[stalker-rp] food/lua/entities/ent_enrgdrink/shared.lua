
ENT.Type = "anim"
ENT.Base = "base_gmodentity"

ENT.PrintName = "Энергетик"
ENT.Category = "Stalker Food"
ENT.Autho = "Voody"
ENT.Spawnable = true
ENT.AdminSpawnable = false


