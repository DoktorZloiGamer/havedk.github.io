
ENT.Type = "anim"
ENT.Base = "base_gmodentity"

ENT.PrintName = "Консервы"
ENT.Category = "Stalker Food"
ENT.Autho = "Stal Play"
ENT.Spawnable = true
ENT.AdminSpawnable = false


