include("shared.lua")

function ENT:Draw()
	if self:GetPos():DistToSqr( LocalPlayer():GetPos() ) < 200000 then
	self:DrawModel()
end
end
