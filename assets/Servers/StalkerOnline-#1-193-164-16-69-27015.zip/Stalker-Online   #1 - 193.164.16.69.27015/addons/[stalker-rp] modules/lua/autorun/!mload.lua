ents_table = {}
do local a=false;local b=file.Find;local c=include;local d=AddCSLuaFile;local function e(f)if SERVER then c(f)end end;local function g(f)if SERVER then d(f)else c(f)end end;local function h(f)g(f)e(f)end;if a then print('\n=~~~~~~~~~~~~~~~~~~~~~~~~~~~~~=')MsgC(Color(235,175,75),'=~Загрузка модулей~=\n')MsgC(Color(235,235,235),'=~~~~~~~~~~~~~~~~~~~~~~~~~~~~~=\n')end;local i,j=b('mods/*',"LUA")for k=1,#j do local l=j[k]local m,n=b('mods/'..l..'/*','LUA')if a then MsgC(Color(235,75,75),'['..k..'] '..l..'.\n')end;do for k=1,#m do local o=m[k]local p='mods/'..l..'/'..o;if o:StartWith("sv_")then e(p)elseif o:StartWith("cl_")then g(p)else h(p)end end end;do for k=1,#n do local o=n[k]m,n=b('mods/'..l..'/'..o..'/*','LUA')for k=1,#m do local q=m[k]local p='mods/'..l..'/'..o..'/'..q;if q:StartWith("sv_")then e(p)elseif q:StartWith("cl_")then g(p)else h(p)end end end end end;if a then MsgC(Color(235,235,235),'=~~~~~~~~~~~~~~~~~~~~~~~~~~~~~=\n')MsgC(Color(75,235,75),'=~Загрузка завершена~=\n')print('=~~~~~~~~~~~~~~~~~~~~~~~~~~~~~=\n')end end
do
local H = hook.Add
local function L()
	for z = 1, #ents_table do
		local g = ents_table[z]
		ents_table[z] = nil
		local e = ents.Create(g.Base)
		e:SetPos(g.Pos)
		e:SetAngles(g.Ang)
		e.Use = g.Use
		e:SetModel(g.Model)
		g.Physics(e)
		e:Spawn()
		e:Activate()
	end
end
H("InitPostEntity", "ET", L)
H("PostCleanupMap", "ET", L)
end