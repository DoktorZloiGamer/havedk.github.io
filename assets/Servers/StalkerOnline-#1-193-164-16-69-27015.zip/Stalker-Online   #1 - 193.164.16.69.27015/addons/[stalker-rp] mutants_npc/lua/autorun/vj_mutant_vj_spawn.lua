
if (!file.Exists("autorun/vj_base_autorun.lua","LUA")) then return end
include('autorun/vj_controls.lua')

local LanguageChoosen = 0

local vCat = "Stalker Mutants" -- Category


VJ.AddNPC("Собака [Слепая]","vj_mutant_dog",vCat) -- Add a human SNPC to the spawnlist
VJ.AddNPC("Тушканчик","vj_mutant_tushkan",vCat) -- Add a human SNPC to the spawnlist

VJ.AddNPC("Псевдособака [Электро]","vj_mutant_psevdodog5",vCat) -- Add a human SNPC to the spawnlist
VJ.AddNPC("Псевдособака [Обычная] Dog","vj_mutant_psevdodog3",vCat) -- Add a human SNPC to the spawnlist

VJ.AddNPC("Кровосос [Обычный]","vj_mutant_bloodsucker2",vCat) -- Add a human SNPC to the spawnlist
VJ.AddNPC("Кровосос [Невидимый]","vj_mutant_bloodsucker",vCat) -- Add a human SNPC to the spawnlist
VJ.AddNPC("Кровосос [Белый]","vj_mutant_bloodsucker5",vCat) -- Add a human SNPC to the spawnlist
VJ.AddNPC("Стронглав","vj_mutant_bloodsucker6",vCat) -- Add a human SNPC to the spawnlist

VJ.AddNPC("Снорк [Обычный]","vj_mutant_snork",vCat) -- Add a human SNPC to the spawnlist
VJ.AddNPC("Снорк [Ветеран]","vj_mutant_snork2",vCat) -- Add a human SNPC to the spawnlist
VJ.AddNPC("Снорк [Кислотный]","vj_mutant_snork3",vCat) -- Add a human SNPC to the spawnlist
VJ.AddNPC("Снорк [Псевдо]","vj_mutant_snork4",vCat) -- Add a human SNPC to the spawnlist

VJ.AddNPC("Химера","vj_mutant_chimera",vCat) -- Add a human SNPC to the spawnlist

VJ.AddNPC("Псевдогигант [Обычный]","vj_mutant_pseudogiant",vCat) -- Add a human SNPC to the spawnlist

VJ.AddNPC("Псевдогигант [Мутированный]","vj_mutant_pseudogiant2",vCat) -- Add a human SNPC to the spawnlist

VJ.AddNPC("Кабан [Обычный]","vj_mutant_boar",vCat) -- Add a human SNPC to the spawnlist
VJ.AddNPC("Кабан [Ветеран]","vj_mutant_boar2",vCat) -- Add a human SNPC to the spawnlist

VJ.AddNPC("Кошка [Обычная]","vj_mutant_cat",vCat) -- Add a human SNPC to the spawnlist
VJ.AddNPC("Кот [Баюн]","vj_mutant_cat2",vCat) -- Add a human SNPC to the spawnlist

VJ.AddNPC("Плоть [Обычная]","vj_mutant_flesh",vCat) -- Add a human SNPC to the spawnlist
VJ.AddNPC("Плоть [Ветеран]","vj_mutant_flesh2",vCat) -- Add a human SNPC to the spawnlist

VJ.AddNPC("Излом [Обычный]","vj_mutant_izlom",vCat) -- Add a human SNPC to the spawnlist
VJ.AddNPC("Излом [Ветеран]","vj_mutant_izlom5",vCat) -- Add a human SNPC to the spawnlist

VJ.AddNPC("Зомби [Житель]","vj_mutant_zombi2",vCat) -- Add a human SNPC to the spawnlist
VJ.AddNPC("Зомби [Обычный]","vj_mutant_zombi",vCat) -- Add a human SNPC to the spawnlist
VJ.AddNPC("Зомби [Камикадзе] Kamikaze","vj_mutant_zombi7",vCat) -- Add a human SNPC to the spawnlist

VJ.AddNPC("Эксперимент X-18 Ghost","vj_mutant_zombi8",vCat) -- Add a human SNPC to the spawnlist

VJ.AddNPC("Бюрер","vj_mutant_burer",vCat) -- Add a human SNPC to the spawnlist

VJ.AddNPC("Контролер","vj_mutant_controler",vCat) -- Add a human SNPC to the spawnlist

VJ.AddNPC("Призрак","vj_mutant_goust",vCat) -- Add a human SNPC to the spawnlist

if(SERVER) then

sound.Add( {
	name = "Bloodsucker.FootStep",
	channel = CHAN_BODY,
	volume = 1,
	level = 280,
	pitch = { 100, 103 },
	sound = {"npc/bloodsucker/foot1.wav",
	"npc/bloodsucker/foot2.wav",
	"npc/bloodsucker/foot3.wav",
	"npc/bloodsucker/foot4.wav"}
} )

sound.Add( {
	name = "Bloodsucker.PunchGrass",
	channel = CHAN_BODY,
	volume = 1,
	level = 280,
	pitch = { 100, 103 },
	sound = {"npc/bloodsucker/punch.ogg"}
} )

sound.Add( {
	name = "Bloodsucker.DigGrass",
	channel = CHAN_BODY,
	volume = 1,
	level = 280,
	pitch = { 100, 103 },
	sound = {"npc/bloodsucker/dig.ogg"}
} )

sound.Add( {
	name = "Bloodsucker.Eat",
	channel = CHAN_BODY,
	volume = 1,
	level = 280,
	pitch = { 100, 103 },
	sound = {"npc/bloodsucker/eat_0.ogg", "npc/bloodsucker/eat_1.ogg"}
} )


sound.Add( {
	name = "Bloodsucker.Vampire1",
	channel = CHAN_BODY,
	volume = 1,
	level = 280,
	pitch = { 100, 103 },
	sound = {"npc/bloodsucker/vampire_grasp.ogg"}
} )

sound.Add( {
	name = "Bloodsucker.Vampire2",
	channel = CHAN_BODY,
	volume = 1,
	level = 280,
	pitch = { 100, 103 },
	sound = {"npc/bloodsucker/vampire_sucking.ogg"}
} )

sound.Add( {
	name = "Bloodsucker.Vampire3",
	channel = CHAN_BODY,
	volume = 1,
	level = 280,
	pitch = { 100, 103 },
	sound = {"npc/bloodsucker/vampire_hit.ogg"}
} )

end
local VJExists = file.Exists("lua/autorun/vj_base_autorun.lua","GAME")
if VJExists == true then
	include('autorun/vj_controls.lua')


game.AddParticles("particles/shadowmonster.pcf")
game.AddParticles("particles/vortigaunte_fx.pcf")
local particlename = {

"shadow",
"shadow2",
"shadow_hid",
"shadow_comer",
"shadow_blood",
"shadow_spike",
"shadow_bloodpool",
"shadow_blooder",
"shadow_bloodpool2",
"shadow_bloodpool3",
"shadow_blood_remove",
"shadow_blood_remove_monster",
	"vortigaunt_hand_glow_bs",
	"vortigaunt_hand_glow_cs",
	"vortigaunt_hand_glows",
}
for _,v in ipairs(particlename) do PrecacheParticleSystem(v) end
	  for k, v in pairs( player.GetAll() ) do



	if v:IsPlayer() then

					v.friclass = "CLASS_NEUTRAL" and "CLASS_NEUTRALS"
					v.SquadName = "vj_neutral"
					v.Class = "CLASS_NEUTRAL" and "CLASS_NEUTRALS"
					v.Classify = "CLASS_NEUTRAL" and "CLASS_NEUTRALS"
					v.VJ_NPC_Class = {"CLASS_HERO_NEUTRAL","CLASS_HERO_BANDIT","CLASS_HERO_FREEDOM","CLASS_HERO_DUTY","CLASS_HERO_CS","CLASS_HERO_HUNTER","CLASS_HERO_SKIT","CLASS_HERO_UCHENIY","CLASS_HERO_KILLER","CLASS_HERO_GREH"}
					v.GetClass = "CLASS_NEUTRAL" and "CLASS_NEUTRALS"
					v.SetClass = "CLASS_NEUTRAL" and "CLASS_NEUTRALS"



			end

		end
		end
game.AddParticles( "particles/Advisor_FX.pcf" )
game.AddParticles( "particles/advisor.pcf" )
game.AddParticles( "particles/hunter_flechette.pcf" )
game.AddParticles( "particles/hunter_intro.pcf" )
game.AddParticles( "particles/hunter_projectile.pcf" )
game.AddParticles( "particles/hunter_shield_impact.pcf" )
game.AddParticles( "particles/effect_hl2.pcf" )
game.AddParticles( "particles/mortar_fx.pcf" )
game.AddParticles( "particles/vorti_fx.pcf" )

game.AddParticles( "particles/blood_impact.pcf" )
game.AddParticles( "particles/choreo_gman.pcf" )
game.AddParticles( "particles/electrical_fx.pcf" )
game.AddParticles( "particles/striderbuster.pcf" )
game.AddParticles( "particles/fire_01.pcf" )

VJ.AddParticle("particles/electrical_fx.pcf",{"electrical_arc_01_parent"}) -- Add a human SNPC to the spawnlist

VJ.AddParticle("particles/mortar_fx.pcf",{"striderbuster_break_lightnings1"}) -- Add a human SNPC to the spawnlist
VJ.AddParticle("particles/vorti_fx.pcf",{"striderbuster_break_lightnings2"}) -- Add a human SNPC to the spawnlist
game.AddParticles("particles/vortigaunte_fx.pcf")
PrecacheParticleSystem("vortigaunt_hand_glow_bs")
PrecacheParticleSystem("vortigaunt_hand_glow_cs")
PrecacheParticleSystem("vortigaunt_hand_glows")
