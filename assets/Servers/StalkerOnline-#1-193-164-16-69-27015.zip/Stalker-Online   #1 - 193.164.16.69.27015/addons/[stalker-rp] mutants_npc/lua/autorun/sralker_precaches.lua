

game.AddParticles("particles/vortigaunte_fx.pcf")
PrecacheParticleSystem("vortigaunt_hand_glow_bs")
PrecacheParticleSystem("vortigaunt_hand_glow_cs")
PrecacheParticleSystem("vortigaunt_hand_glows")


