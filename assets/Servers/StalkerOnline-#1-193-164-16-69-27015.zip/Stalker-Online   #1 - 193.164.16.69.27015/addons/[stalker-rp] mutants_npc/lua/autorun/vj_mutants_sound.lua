if(SERVER) then

sound.Add( {
	name = "Dog.tyaftyaf",
	channel = CHAN_BODY,
	volume = 1,
	level = 85,
	pitch = 100,
	sound = {"npc/dog/bdog_distant_0.ogg",
	"npc/dog/bdog_distant_1.ogg",
	"npc/dog/bdog_distant_2.ogg",
	"npc/dog/bdog_distant_3.ogg",
	"npc/dog/bdog_distant_4.ogg",
	"npc/dog/bdog_distant_5.ogg"}
} )


sound.Add( {
	name = "Dog.voet",
	channel = CHAN_BODY,
	volume = 1,
	level = 95,
	pitch = 100,
	sound = {"npc/dog/bdog_howl_0.ogg",
	"npc/dog/bdog_howl_1.ogg",
	"npc/dog/bdog_howl_2.ogg"}
} )

sound.Add( {
	name = "Dog.est",
	channel = CHAN_BODY,
	volume = 1,
	level = 70,
	pitch = 100,
	sound = {"npc/dog/bdog_eat_0.ogg",
	"npc/dog/bdog_eat_1.ogg"}
} )
end
