ENT.Type = "anim"
ENT.Base = "base_gmodentity"
 
ENT.PrintName		= "Controler Psy Field"
ENT.Author			= ""
ENT.Contact			= ""
ENT.Category 		= ""

ENT.Spawnable			= false
ENT.AdminSpawnable		= false

function ENT:OnRemove()
end

function ENT:PhysicsUpdate()
end

function ENT:PhysicsCollide(data,phys)

end