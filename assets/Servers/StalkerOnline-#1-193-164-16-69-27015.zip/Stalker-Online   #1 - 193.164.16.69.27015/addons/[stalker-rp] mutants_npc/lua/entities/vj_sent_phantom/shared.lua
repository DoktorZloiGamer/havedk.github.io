ENT.Base 			= "obj_vj_spawner_base"
ENT.Type 			= "anim"
ENT.PrintName 		= "Random Civil"
ENT.Author 			= "vlt"
ENT.Contact 		= "http://steamcommunity.com/groups/vrejgaming"
ENT.Purpose 		= "a normal peaple"
ENT.Instructions 	= "Click on the spawnicon to spawn it."
ENT.Category		= "Civilian"

ENT.Spawnable		= false
ENT.AdminSpawnable	= false