ENT.Type = "anim"
ENT.Base = "base_gmodentity"
 
ENT.PrintName		= "Pseudogiant Step"
ENT.Author			= ""
ENT.Contact			= ""
ENT.Category 		= "Darsenvall's Anomalies"

ENT.Spawnable			= false
ENT.AdminSpawnable		= false

function ENT:OnRemove()
end

function ENT:PhysicsUpdate()
end

function ENT:PhysicsCollide(data,phys)

end