ENT.Base 			= "npc_vj_creature_base"
ENT.Type 			= "ai"
ENT.PrintName 		= "Brain"
ENT.Author 			= "Comrade Communist"
ENT.Purpose 		= "Spawn it and fight with it!"
ENT.Instructions 	= "Click on the spawnicon to spawn it."
ENT.Category		= "S.T.A.L.K.E.R"

if (CLIENT) then
local Name = "Brain"
local LangName = "vj_mutant_brain_tuman"
language.Add(LangName, Name)
killicon.Add(LangName,"HUD/killicons/default",Color ( 255, 80, 0, 255 ) )
language.Add("#"..LangName, Name)
killicon.Add("#"..LangName,"HUD/killicons/default",Color ( 255, 80, 0, 255 ) )

--[[	net.Receive( "Controller5", function()
		RunConsoleCommand( "pp_colormod", "1" )
		RunConsoleCommand( "pp_colormod_addb", "50" )
		RunConsoleCommand( "pp_colormod_addg", "50" )
		RunConsoleCommand( "pp_colormod_addr", "50" )
		RunConsoleCommand( "pp_colormod_brightness", "-1.30" )
		RunConsoleCommand( "pp_colormod_color", "0.09" )
		RunConsoleCommand( "pp_colormod_contrast", "3.55" )
		RunConsoleCommand( "pp_colormod_mulb", "0" )
		RunConsoleCommand( "pp_colormod_mulg", "0" )
		RunConsoleCommand( "pp_colormod_mulr", "0" )
		RunConsoleCommand( "play", "monolith/geiger_8.ogg" )
		RunConsoleCommand( "pp_mat_overlay", "overlays/rad.vmt" )
			
	timer.Create( "ControllerAttackStop", 6, 1, function()
			RunConsoleCommand( "pp_colormod", "0" )
			RunConsoleCommand( "pp_mat_overlay", "\"\"" )
		end)
		end)]]



end