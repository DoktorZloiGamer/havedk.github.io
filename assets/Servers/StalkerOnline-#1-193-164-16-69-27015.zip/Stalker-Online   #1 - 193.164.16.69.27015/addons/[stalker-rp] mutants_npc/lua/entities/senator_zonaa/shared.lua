ENT.Type = "anim"
ENT.Base = "base_gmodentity"
 
ENT.PrintName		= "SenatorZonaa"
ENT.Author			= ""
ENT.Contact			= ""
ENT.Category 		= ""

ENT.Spawnable			= false
ENT.AdminSpawnable		= false