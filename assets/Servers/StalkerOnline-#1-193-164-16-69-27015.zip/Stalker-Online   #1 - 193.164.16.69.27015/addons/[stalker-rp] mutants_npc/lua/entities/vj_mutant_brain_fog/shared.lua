ENT.Base 			= "npc_vj_creature_base"
ENT.Type 			= "ai"
ENT.PrintName 		= "Fog"
ENT.Author 			= "Comrade Communist"
ENT.Purpose 		= "Spawn it and fight with it!"
ENT.Instructions 	= "Click on the spawnicon to spawn it."
ENT.Category		= "S.T.A.L.K.E.R"

if (CLIENT) then
local Name = "Fog"
local LangName = "vj_mutant_brain_fog"
language.Add(LangName, Name)
killicon.Add(LangName,"HUD/killicons/default",Color ( 255, 80, 0, 255 ) )
language.Add("#"..LangName, Name)
killicon.Add("#"..LangName,"HUD/killicons/default",Color ( 255, 80, 0, 255 ) )

	net.Receive( "Controller3", function()
		RunConsoleCommand( "pp_colormod", "1" )
		RunConsoleCommand( "pp_colormod_addb", "0" )
		RunConsoleCommand( "pp_colormod_addg", "95" )
		RunConsoleCommand( "pp_colormod_addr", "102" )
		RunConsoleCommand( "pp_colormod_brightness", "-1.75" )
		RunConsoleCommand( "pp_colormod_color", "0.09" )
		RunConsoleCommand( "pp_colormod_contrast", "3.55" )
		RunConsoleCommand( "pp_colormod_mulb", "0" )
		RunConsoleCommand( "pp_colormod_mulg", "0" )
		RunConsoleCommand( "pp_colormod_mulr", "0" )
		RunConsoleCommand( "play", "senator/psy_"..math.random(1,3)..".ogg" )

			
	timer.Create( "ControllerAttackStop", 6, 1, function()
			RunConsoleCommand( "pp_colormod", "0" )
		end)
		end)



end