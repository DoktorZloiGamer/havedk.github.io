ENT.Base 			= "npc_vj_creature_base"
ENT.Type 			= "ai"
ENT.PrintName 		= "Burer Imitator"
ENT.Author 			= "Comrade Communist"
ENT.Purpose 		= "Spawn it and fight with it!"
ENT.Instructions 	= "Click on the spawnicon to spawn it."
ENT.Category		= "S.T.A.L.K.E.R"
if (CLIENT) then
local Name = "Burer Imitator"
local LangName = "vj_mutant_burer4"
language.Add(LangName, Name)
killicon.Add(LangName,"HUD/killicons/default",Color(255,80,0,255))
language.Add("#"..LangName, Name)
killicon.Add("#"..LangName,"HUD/killicons/default",Color(255,80,0,255))

	net.Receive( "Psyburer", function()
		RunConsoleCommand( "pp_colormod", "1" )
		RunConsoleCommand( "pp_colormod_addb", "150" )
		RunConsoleCommand( "pp_colormod_addg", "0" )
		RunConsoleCommand( "pp_colormod_addr", "100" )
		RunConsoleCommand( "pp_colormod_brightness", "-1.1" )
		RunConsoleCommand( "pp_colormod_color", "0.14" )
		RunConsoleCommand( "pp_colormod_contrast", "0.55" )
		RunConsoleCommand( "pp_colormod_mulb", "0" )
		RunConsoleCommand( "pp_colormod_mulg", "0" )
		RunConsoleCommand( "pp_colormod_mulr", "0" )
		RunConsoleCommand( "play", "npc/burer/burer_scan_affect_3.ogg" )

		
	timer.Create( "PsydogAttackStop", 10, 1, function()
			RunConsoleCommand( "pp_colormod", "0" )
		end)
		end)
end