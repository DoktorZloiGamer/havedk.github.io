EFFECT.mat = Material("sprites/doom3/boomboom")
local exists = file.Exists("materials/sprites/doom3/boomboom.vmt", "GAME")

function EFFECT:Init(data)
	if cvars.Bool("doom3_firelight") then
		local dynlight = DynamicLight(self:EntIndex())
		dynlight.Pos = data:GetOrigin()
		dynlight.Size = 128
		dynlight.Decay = 256
		dynlight.R = 255
		dynlight.G = 200
		dynlight.B = 100
		dynlight.Brightness = 6
		dynlight.DieTime = CurTime()+.3
	end

	self.Time = 0
	self.Size = 0
end

function EFFECT:Think()
	self.Time = self.Time + FrameTime()
	self.Size = 300 * self.Time^.2

	return self.Time < .3
end

function EFFECT:Render()
	local Pos = self:GetPos() + (EyePos()-self:GetPos()):GetNormal()

	render.SetMaterial(self.mat)
	if exists then
		self.mat:SetInt("$frame", math.Clamp(math.floor(self.Time*8), 0, 2))
	end
	render.DrawSprite(Pos, self.Size, self.Size)
end