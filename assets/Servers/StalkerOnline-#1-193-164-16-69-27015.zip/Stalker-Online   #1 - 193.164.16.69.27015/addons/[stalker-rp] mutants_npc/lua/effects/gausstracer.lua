
local BLAST_SHOOT = Material( "effects/gauss_tracer")

function EFFECT:Init( data )

	self.Position = data:GetStart()
	self.EndPos = data:GetOrigin()
	self.WeaponEnt = data:GetEntity()
	self.Attachment = data:GetAttachment()
	self.StartPos = self:GetTracerShootPos( self.Position, self.WeaponEnt, self.Attachment )
	self:SetRenderBoundsWS( self.StartPos, self.EndPos )

	self.Dir = ( self.EndPos - self.StartPos ):GetNormalized()
	self.Dist = self.StartPos:Distance( self.EndPos )
	
	self.LifeTime = 0.25 - ( 0.01 / self.Dist )
	self.DieTime = CurTime() + self.LifeTime
end
function EFFECT:Think()
	if ( CurTime() > self.DieTime ) then return false end
	return true
end
function EFFECT:Render()

	local v1 = ( CurTime() - self.DieTime ) / self.LifeTime
	local v2 = ( self.DieTime - CurTime() ) / self.LifeTime
	local a = self.EndPos - self.Dir * math.min( 100 - ( v1 * self.Dist ), self.Dist )

	render.SetMaterial(BLAST_SHOOT)
	render.DrawBeam( a, self.EndPos, v2 * 20, 0, self.Dist / 10, Color( 150, 150, 150, v2 * 250 ) )

end
