include('shared.lua')

function ENT:Draw()

self:DrawModel()

end

function ENT:OnRemove()
end

function ENT:Initialize()
pos = self:GetPos()

self.emitter = ParticleEmitter( pos )
end

function ENT:Think()
end

local GraMAT = Material("gui/gradient")

local L = Lerp
local n = .4
local b = false
local p = LocalPlayer()
local s = DrawSharpen
local min, Clamp, sin, Round = math.min, math.Clamp, math.sin, math.Round
local Mat, Clr, Draw = surface.SetMaterial, surface.SetDrawColor, surface.DrawTexturedRectRotated
hook.Add( "RenderScreenspaceEffects", "SobelShader", function()
	p = LocalPlayer()
	local rad = p:GetNWFloat("Radiation")
	if rad == 0 then return end
	if rad < 150 then n = 0 return end
	local _min, max = rad * .008, rad *.015
	-- print(rad, min,max)
	if n >=_min || n <= max then b = !b end
	n = Lerp(FrameTime()*10, n, b && _min || max)
	s(n, 1.2)
	local Lower = min(_min, max)
	local Per = (Lower*.5)

	local will = Clamp(255 -(1-Per) * 255, 0, 255)
	local col = Color(0, 0, 0, will)
	local Size = will < 255 && 40 + Lower*500 + Round(sin(CurTime())*30)*2 || 40 + Lower*550 + Round(sin(CurTime())*30)*2
	local w = ScrW() * .5
	Mat(GraMAT)
	Clr(col)
	Draw(w,Size*.5,Size,ScrW(),270)
	Draw(w,ScrH() - Size*.5,Size,ScrW(),90)
	
	Draw(Size*.5,Size*.5,Size,ScrH()*2,0)
	Draw(ScrW() - Size*.5,Size*.5,Size,ScrH()*2,180)
end )