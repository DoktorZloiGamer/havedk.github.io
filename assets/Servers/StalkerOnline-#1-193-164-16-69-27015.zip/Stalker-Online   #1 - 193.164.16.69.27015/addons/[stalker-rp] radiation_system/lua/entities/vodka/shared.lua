ENT.Type = "anim"
ENT.Base = "base_gmodentity"

ENT.Category		= "Stalker Items"
ENT.PrintName		= "Водка"

ENT.Author = "Stalker Developers"
ENT.Contact = ""
ENT.Purpose = ""
ENT.Instructions = "-50 Rad +aclho"
ENT.Model = Model("models/kali/miscstuff/stalker/food/cossacks vodka.mdl")

ENT.Spawnable = true
ENT.AdminSpawnable = false
