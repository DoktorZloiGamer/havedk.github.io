ENT.Type = "anim"
ENT.Base = "base_gmodentity"

ENT.Category		= "Stalker Items"
ENT.PrintName		= "Анабиотик"

ENT.Author = "Stalker-RP"
ENT.Contact = ""
ENT.Purpose = ""
ENT.Instructions = "-Emission"
ENT.Model = Model("models/spec45as/stalker/items/drug_anabiotic.mdl")

ENT.Spawnable = true
ENT.AdminSpawnable = false
