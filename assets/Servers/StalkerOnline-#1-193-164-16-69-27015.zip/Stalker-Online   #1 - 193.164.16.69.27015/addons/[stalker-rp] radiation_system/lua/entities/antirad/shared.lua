ENT.Type = "anim"
ENT.Base = "base_gmodentity"

ENT.Category		= "Stalker Items"
ENT.PrintName		= "Анти-Рад"

ENT.Author = "Stalker-RP"
ENT.Contact = ""
ENT.Purpose = ""
ENT.Instructions = "-Rad"
ENT.Model = Model("models/spec45as/stalker/items/antirad.mdl")

ENT.Spawnable = true
ENT.AdminSpawnable = false
