ENT.Type = "anim"
ENT.Base = "base_gmodentity"

ENT.Category		= "Stalker Items"
ENT.PrintName		= "Пси-Блокада"

ENT.Author = "Stalker-RP"
ENT.Contact = ""
ENT.Purpose = ""
ENT.Instructions = "-Psi"
ENT.Model = Model("models/spec45as/stalker/items/drug_psy_blockade.mdl")

ENT.Spawnable = true
ENT.AdminSpawnable = false
