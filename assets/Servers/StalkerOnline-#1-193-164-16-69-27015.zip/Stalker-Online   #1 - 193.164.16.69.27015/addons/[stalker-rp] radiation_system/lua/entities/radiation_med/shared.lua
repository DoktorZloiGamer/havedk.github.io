ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Radiation (Medium)"
ENT.Author = "Barney"
ENT.Category = "Stalker Radiation"
ENT.Spawnable = true
ENT.AdminSpawnable = true
