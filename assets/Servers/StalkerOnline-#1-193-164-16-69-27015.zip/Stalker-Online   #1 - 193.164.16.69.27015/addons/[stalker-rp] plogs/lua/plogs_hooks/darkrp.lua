--[[
addons/lgos/lua/plogs_hooks/darkrp.lua
--]]

-- Names
plogs.Register('Имена', true, Color(51, 128, 255))

plogs.AddHook('onPlayerChangedName', function(pl, old, new)
	if IsValid(pl) and (old ~= nil) then
		plogs.PlayerLog(pl, 'Имена', pl:NameID() .. ' changed their name to ' .. new ..  ' from ' .. old, {
			['Name'] 	= pl:Name(),
			['SteamID']	= pl:SteamID()
		})
	end
end)


plogs.Register('Деньги', false, Color(51, 128, 255))

plogs.AddHook('playerPickedUpMoney', function(pl, amout, ent)
	if IsValid(pl) then
		plogs.PlayerLog(pl, 'Деньги', pl:NameID() .. ' поднял ' .. amout ..  ' руб ' , {
			['Ник'] 	= pl:Name(),
			['Стимид']	= pl:SteamID()
		})
	end
end)

plogs.AddHook('playerGaveMoney', function(pl, pl2, amout)
	if IsValid(pl) then
		plogs.PlayerLog(pl,'Деньги', pl:NameID()..' дал '..amout..'р игроку: '..pl2:NameID(), {
			['Ник'] 	= pl:Name(),
			['Стимид']	= pl:SteamID(),
			['Ник кому дали денег'] = pl2:Name(),
			['Стим ид кому дали денег'] = pl2:SteamID()
		})
	end
end)

plogs.AddHook('playerDroppedMoney', function(pl,amout)
	if IsValid(pl) then
		plogs.PlayerLog(pl,'Деньги', pl:NameID()..' скинул на землю '..amout..'р',{
			['Ник'] 	= pl:Name(),
			['Стимид']	= pl:SteamID(),
		})
	end
end)

-- Job changes
plogs.Register('Работы', true, Color(51, 128, 255))

plogs.AddHook('OnPlayerChangedTeam', function(pl, old, new)
	if IsValid(pl) then
		plogs.PlayerLog(pl, 'Работы', pl:NameID() .. ' changed their job to ' .. team.GetName(new) ..  ' from ' .. team.GetName(old), {
			['Name'] 	= pl:Name(),
			['SteamID']	= pl:SteamID()
		})
	end
end)


-- Demotions
plogs.Register('Увольнение', true, Color(51, 128, 255))

plogs.AddHook('onPlayerDemoted', function(demoter, demotee, reason)
	if IsValid(demoter) and IsValid(demotee) then
		plogs.PlayerLog(demoter, 'Увольнение', demoter:NameID() .. ' started a demotion on ' .. demotee:NameID() ..  ' for ' .. reason, {
			['Target Name'] 	= demotee:Name(),
			['Target SteamID']	= demotee:SteamID(),
			['Demotee Name'] 	= demoter:Name(),
			['Demotee SteamID']	= demoter:SteamID(),
		})
	end
end)

-- Police logs
plogs.Register('Полиция', true, Color(51, 128, 255))

plogs.AddHook('playerArrested', function(target, time, officer)
	if IsValid(officer) then
		plogs.PlayerLog(officer, 'Полиция', officer:NameID() .. ' арестовал ' .. target:NameID(), {
			['Target Name'] 	= target:Name(),
			['Target SteamID']	= target:SteamID(),
			['Officer Name'] 	= officer:Name(),
			['Officer SteamID']	= officer:SteamID(),
		})
	end
end)

plogs.AddHook('playerUnArrested', function(target, officer)
	if IsValid(officer) then
		plogs.PlayerLog(officer, 'Полиция', officer:NameID() .. ' снял арест ' .. target:NameID(), {
			['Target Name'] 	= target:Name(),
			['Target SteamID']	= target:SteamID(),
			['Officer Name'] 	= officer:Name(),
			['Officer SteamID']	= officer:SteamID(),
		})
	else
		plogs.Log('Полиция', target:NameID() .. ' вышел с джайла.', {
			['Name'] 	= target:Name(),
			['SteamID']	= target:SteamID(),
		})
	end
end)

plogs.AddHook('playerWanted', function(target, officer, reason)
	if IsValid(officer) then
		plogs.PlayerLog(officer, 'Полиция', officer:NameID() .. ' розыск ' .. target:NameID() .. ' причина ' .. reason, {
			['Target Name'] 	= target:Name(),
			['Target SteamID']	= target:SteamID(),
			['Officer Name'] 	= officer:Name(),
			['Officer SteamID']	= officer:SteamID(),
		})
	end
end)

plogs.AddHook('playerUnWanted', function(target, officer)
	if IsValid(officer) then
		plogs.PlayerLog(officer, 'Полиция', officer:NameID() .. ' снял розыск ' .. target:NameID(), {
			['Target Name'] 	= target:Name(),
			['Target SteamID']	= target:SteamID(),
			['Officer Name'] 	= officer:Name(),
			['Officer SteamID']	= officer:SteamID(),
		})
	else
		plogs.Log('Полиция', target:NameID() .. '\'s wanted has expired', {
			['Name'] 	= target:Name(),
			['SteamID']	= target:SteamID(),
		})
	end
end)

plogs.AddHook('playerWarranted', function(target, officer, reason)
	if IsValid(officer) then
		plogs.PlayerLog(officer, 'Полиция', officer:NameID() .. ' warranted ' .. target:NameID() .. ' for ' .. reason, {
			['Target Name'] 	= target:Name(),
			['Target SteamID']	= target:SteamID(),
			['Officer Name'] 	= officer:Name(),
			['Officer SteamID']	= officer:SteamID(),
		})
	end
end)

plogs.AddHook('playerUnWarranted', function(target, officer)
	if IsValid(officer) then
		plogs.PlayerLog(officer, 'Полиция', officer:NameID() .. ' unwarranted ' .. target:NameID(), {
			['Target Name'] 	= target:Name(),
			['Target SteamID']	= target:SteamID(),
			['Officer Name'] 	= officer:Name(),
			['Officer SteamID']	= officer:SteamID(),
		})
	else
		plogs.Log('Полиция', target:NameID() .. '\'s warrant has expired', {
			['Name'] 	= target:Name(),
			['SteamID']	= target:SteamID(),
		})
	end
end)


-- Purchases
plogs.Register('Покупки', false)

plogs.AddHook('playerBoughtCustomEntity', function(pl, ent_tbl, ent)
	plogs.PlayerLog(pl, 'Покупки', pl:NameID() .. ' purchased ' .. ent_tbl.name .. ' for $' .. ent_tbl.price, {
		['Name'] 	= pl:Name(),
		['SteamID']	= pl:SteamID()
	})
end)

-- Lockpicks
plogs.Register('Взломы', false)

plogs.AddHook('lockpickStarted', function(pl)
	plogs.PlayerLog(pl, 'Взломы', pl:NameID() .. ' Начал взлом', {
		['Name'] 	= pl:Name(),
		['SteamID']	= pl:SteamID()
	})
end)

plogs.AddHook('onLockpickCompleted', function(pl, succ)
	plogs.PlayerLog(pl, 'Взломы', pl:NameID() .. ' Закончил взлом ' .. (succ and 'Успешно' or 'Неудачно'), {
		['Name'] 	= pl:Name(),
		['SteamID']	= pl:SteamID()
	})
end)


-- Door buys
plogs.Register('Двери', false)

plogs.AddHook('playerBoughtDoor', function(pl, ent, cost)
	plogs.PlayerLog(pl, 'Двери', pl:NameID() .. ' купил дверь за $' .. cost, {
		['Name'] 	= pl:Name(),
		['SteamID']	= pl:SteamID()
	})
end)

plogs.AddHook('playerSellDoor', function(pl, ent)
	plogs.PlayerLog(pl, 'Двери', pl:NameID() .. ' продал дверь', {
		['Name'] 	= pl:Name(),
		['SteamID']	= pl:SteamID()
	})
end)

timer.Simple(0, function()
	DarkRP.log = function() end
end)

