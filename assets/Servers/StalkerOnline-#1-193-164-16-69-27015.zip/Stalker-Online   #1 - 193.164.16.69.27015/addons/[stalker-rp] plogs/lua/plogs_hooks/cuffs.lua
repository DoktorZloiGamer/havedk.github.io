--[[
addons/lgos/lua/plogs_hooks/cuffs.lua
--]]
plogs.Register('Наручники', false)

plogs.AddHook('OnHandcuffed', function(pl, targ)
	plogs.PlayerLog(pl, 'Наручники', pl:NameID() .. ' завязал ' .. targ:NameID(), {
		['Name'] 			= pl:Name(),
		['SteamID']			= pl:SteamID(),
		['Target Name'] 	= targ:Name(),
		['Target SteamID']	= targ:SteamID()
	})
end)

plogs.AddHook('OnHandcuffBreak', function(pl, cuffs, friend)
	if IsValid(friend) then
		plogs.PlayerLog(pl, 'Наручники', friend:NameID() .. ' развазял ' .. pl:NameID(), {
			['Name'] 			= pl:Name(),
			['SteamID']			= pl:SteamID(),
			['Fried Name'] 		= friend:Name(),
			['Target SteamID']	= friend:SteamID()
		})
	else
		plogs.PlayerLog(pl, 'Наручники', pl:NameID() .. ' освободился из наручников', {
			['Name'] 			= pl:Name(),
			['SteamID']			= pl:SteamID()
		})
	end
end)

