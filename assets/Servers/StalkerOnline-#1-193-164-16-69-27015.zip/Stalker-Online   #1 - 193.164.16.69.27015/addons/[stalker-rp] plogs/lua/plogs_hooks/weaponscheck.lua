plogs.Register('Чекер оружия', false, Color(205, 92, 92))

plogs.AddHook('playerWeaponsChecked', function(ply, pl)
	plogs.PlayerLog(ply, 'Чекер оружия', ply:NameID() .. ' проверил чекером оружия игрока ' .. pl:NameID(), {
		['Ник проверящего'] 	= ply:Name(),
		['Стимид проверящего']	= ply:SteamID(),
		['Ник которого проверили'] = pl:Name(),
		['Стимид которого проверили'] = pl:SteamID()
	})
end)

plogs.AddHook('playerWeaponsReturned', function(ply, pl)
	plogs.PlayerLog(ply, 'Чекер оружия', ply:NameID() .. ' вернул конфискованное оружие игроку ' .. pl:NameID(), {
		['Ник проверящего'] 	= ply:Name(),
		['Стимид проверящего']	= ply:SteamID(),
		['Ник которого проверили'] = pl:Name(),
		['Стимид которого проверили'] = pl:SteamID()
	})
end)

plogs.AddHook('playerWeaponsConfiscated', function(ply, pl)
	plogs.PlayerLog(ply, 'Чекер оружия', ply:NameID() .. ' конфисковал оружие у игрока ' .. pl:NameID(), {
		['Ник проверящего'] 	= ply:Name(),
		['Стимид проверящего']	= ply:SteamID(),
		['Ник которого проверили'] = pl:Name(),
		['Стимид которого проверили'] = pl:SteamID()
	})
end)