plogs.Register("Действия", false)

local commands = {
    ["me"] = true,
    ["y"] = true,
    ["w"] = true,
    ["do"] = true,
    ["looc"] = true,
}

plogs.AddHook("PlayerSay", function(ply, text)
    local cmd, args = text:match("/([A-Za-z%d]*)%s?(.*)")
    if(!commands[cmd])then return end

    plogs.PlayerLog(ply, "Действия", ply:NameID() .. " выполнил '" .. cmd .. "' с аргументами: " .. args, {
        ["Name"] = ply:Name(),
        ["SteamID"] = ply:SteamID(),
        ["Arguments"] = args,
        ["Command"] = cmd
    })
end)
