--[[
addons/lgos/lua/plogs_hooks/chat.lua
--]]
plogs.Register('Чат', false)

local hook_name = 'PlayerSay'-- DarkRP and 'PostPlayerSay' or 'PlayerSay'
plogs.AddHook(hook_name, function(pl, text, b)
	if (text ~= '') then
		local cmd = b && ' сказал группе ' || ' сказал '
		plogs.PlayerLog(pl, 'Чат', pl:NameID() .. cmd .. text:Trim(), {
			['Name'] 	= pl:Name(),
			['SteamID']	= pl:SteamID()
		})
	end
end)

