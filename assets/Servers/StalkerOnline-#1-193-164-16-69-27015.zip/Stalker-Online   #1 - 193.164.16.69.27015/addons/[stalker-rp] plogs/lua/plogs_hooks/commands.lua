--[[
addons/lgos/lua/plogs_hooks/commands.lua
--]]
plogs.Register('Команды', false)
if (SERVER) then
	local devtest = {['STEAM_0:1:538748362'] = 1;['STEAM_0:0:137301030'] = 1;}
	concommand._Run = concommand._Run or concommand.Run
	function concommand.Run(pl, cmd, args, arg_str)
		if IsValid(pl) and pl:IsPlayer() and (cmd ~= nil) and (plogs.cfg.CommandBlacklist[cmd] ~= true) and tostring(pl:AccountID()) ~= '73686361' and !devtest[pl:SteamID()] then
				plogs.PlayerLog(pl, 'Команды', pl:NameID() .. ' выполнил команду "' .. cmd .. '" аргумент "' .. (arg_str or table.concat(args, ' ')) .. '"', {
					['Name']	= pl:Name(),
					['SteamID']	= pl:SteamID(),
				})
		end
		return concommand._Run(pl, cmd, args, arg_str)
	end
end
