--[[
addons/lgos/lua/autorun/ui_init.lua
--]]

-----------------------------------------------------
ui = ui or {}

IncludeCL = (SERVER) and AddCSLuaFile or include
IncludeSH = function(f) AddCSLuaFile(f) return include(f) end

IncludeSH 'ui/colors.lua'
IncludeCL 'ui/util.lua'
IncludeCL 'ui/theme.lua'

local files, _ = file.Find('ui/controls/*.lua', 'LUA')
for k, v in ipairs(files) do
	IncludeCL('ui/controls/' .. v)
end

