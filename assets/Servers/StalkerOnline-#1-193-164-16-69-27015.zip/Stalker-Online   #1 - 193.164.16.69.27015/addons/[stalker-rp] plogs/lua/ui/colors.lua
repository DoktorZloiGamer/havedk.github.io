
-----------------------------------------------------
local c = Color

ui.col = {
	SUP 			= c(70,70,70),
	Background 		= c(41,41,41,175),
	Outline 		= c(171,171,171),
	Hover 			= c(0,0,0,0),


	Button 			= c(31,31,31,175),
	ButtonHover 	= c(70,70,70),
	ButtonRed 		= c(70,70,70),
	ButtonGreen 	= c(0,240,0),
	Close 			= c(255,255,255),
	CloseBackground = c(0,0,0,0),
	CloseHovered 	= c(70,70,70),


	OffWhite 		= c(0,0,0,170),
	FlatBlack 		= c(0,0,0,170),
	Black 			= c(0,0,0,170),
	White 			= c(255,255,255),
	Red 			= c(255,0,0),
	Orange 			= c(245,120,0),
}

include 'theme.lua' 