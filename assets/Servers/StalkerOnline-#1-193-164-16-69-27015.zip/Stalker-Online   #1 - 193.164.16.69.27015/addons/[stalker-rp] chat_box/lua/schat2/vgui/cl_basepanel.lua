local PANEL = {}
-- Color(12, 12, 12, 180)
-- Color(216, 101, 74)

function PANEL:Init()
	local posX, posY = SChat2:GetConvar("posX", 10), SChat2:GetConvar("posY", ScrH() * 0.5)
	local sizeW, sizeH = SChat2:GetConvar("sizeW", ScrW() / 3), SChat2:GetConvar("sizeH", ScrW() / 3)
	self:SetPos(posX, posY)
	self:SetSize(sizeW, sizeH)
	self:MakePopup()
	self:SetTitle("")
	self:ShowCloseButton(false)
	self:SetSizable(true)
	local minW, minH = SChat2.Config.sizeW / SChat2.Config.minSizeW, SChat2.Config.sizeH / SChat2.Config.minSizeH
	self:SetMinWidth(minW)
	self:SetMinHeight(minH)
	self:DockPadding(100, 0, 5, 5)
	self.Alpha = 255
	self.Displayed = true
	self.BlurMat = Material("pp/blurscreen")

	self.Closer = vgui.Create("DButton", self)
	self.Closer:SetSize(37, 18)
	self.Closer:SetText("")
	self.Closer.Paint = function(this, w, h)
		draw.SimpleText("X", "SChat220", w / 2 + 2, h / 2, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	self.Closer.DoClick = function()
		self:ChatHide()
	end

	self.Txt = vgui.Create("RichText", self)
	self.Txt:SetSize(self:GetWide() - 10, self:GetTall() - 57)
	self.Txt:InsertColorChange(215, 215, 215, 255)
	self.Txt.Paint = function(_self, w, h)
		draw.RoundedBox(0, 0, 0, w, h, Color(0, 0, 0, self.Alpha))
	end
	self.Txt.PerformLayout = function(_self)
		_self:SetFontInternal("SChat218")
	end

	self.TextEntry = vgui.Create("DTextEntry", self)
	self.TextEntry:SetSize(self:GetWide() - 105, 22)
	self.TextEntry:SetPos(5, self:GetTall() - 26)
	self.TextEntry.History = {}
	self.TextEntry:SetPaintBackgroundEnabled(true)
	self.TextEntry:SetHistoryEnabled(true)
	self.TextEntry:SetCursorColor(Color(200, 200, 200, 255))
	self.TextEntry:SetTextColor(Color(200, 200, 200, 255))
	self.TextEntry:SetHighlightColor(SChat2:GetConvar("Color", Color(66, 139, 202, 255)))
	self.TextEntry.OnEnter = function()
		self:Chat()
	end
	self.TextEntry.PerformLayout = function()
		self.TextEntry:SetFontInternal("SChat218")
		self.TextEntry:SetBGColor(Color(0, 0, 0, self.Alpha))
		-- gamemode.Call("ChatTextChanged", self.TextEntry:GetValue())
	end
	self.TextEntry.OnChange = function(self)
		local maxLen = SChat2.Config.maxTextLength
		local value = utf8.force(self:GetText())
		local valueLen = value:utf8len()
		if valueLen >= maxLen then
			value = value:utf8sub(1, maxLen)

			self:SetText(value)
			self:SetCaretPos(valueLen)
			surface.PlaySound("UI/buttonclick.wav")
		end
	end
	self.TextEntry.UpdateFromHistory = function(self)

		-- if IsValid(self.Menu) then
		-- 	return self:UpdateFromMenu()
		-- end

		local pos = self.HistoryPos
		if pos < 0 then pos = #self.History end
		if pos > #self.History then pos = 0 end

		local text = self.History[ pos ]
		if not text then text = "" end

		self:SetText(text)
		self:SetCaretPos(text:utf8len())

		self:OnTextChanged()
		self.HistoryPos = pos
	end
	self.TextEntry:RequestFocus()

	self.TextActivate = vgui.Create("DButton", self)
	self.TextActivate:SetSize(90, 22)
	self.TextActivate:SetPos(self:GetWide() - 95, self:GetTall() - 26)
	self.TextActivate:SetText("")
	self.TextActivate.DoClick = function()
		self:Chat()
	end
	self.TextActivate.Paint = function(this, w, h)
		draw.RoundedBox(2, 0, 0, w, h, Color(0, 0, 0, 255))
		draw.SimpleText("Отправить", "SChat217", w / 2, h / 2, Color(237, 237, 237), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
end

function PANEL:Think()
	self.BaseClass.Think(self)

	local x, y = self:GetPos()
	local sizeX, sizeY = self:GetSize()
	local w, h = ScrW() - sizeX, ScrH() - sizeY
	if (x < 0 or x > w) or (y < 0 or y > h) then
		x = math.max(math.min(x, w), 0)
		y = math.max(math.min(y, h), 0)
		self:SetPos(x, y)
	end

	if not self.Displayed then
		self:MoveToBack()
	end

	local esc, tilda = input.IsKeyDown(KEY_ESCAPE), input.IsKeyDown(KEY_BACKQUOTE)
	if self.Displayed and (esc or tilda) --[[or gui.IsGameUIVisible()]] then
		gui.HideGameUI()
		if not tilda then
			self:ChatHide()
		end
	end
end

function PANEL:PerformLayout()
	self.BaseClass.PerformLayout(self)

	self.TextEntry:SetSize(self:GetWide() - 105, 22)
	self.TextEntry:SetPos(5, self:GetTall() - 26)

	self.TextActivate:SetSize(90, 22)
	self.TextActivate:SetPos(self:GetWide() - 95, self:GetTall() - 26)

	self.Txt:SetSize(self:GetWide() - 10, self:GetTall() - 55)
	self.Txt:SetPos(5, 26)

	self.Closer:SetSize(40, 18)
	self.Closer:SetPos(self:GetWide() - 45, 2)

	self.TextEntry.Paint = function(this, w, h)
		self.TextEntry:SetFontInternal("SChat218")
		self.TextEntry:SetBGColor(Color(0, 0, 0, 255))
	end
end

function PANEL:DrawBlur(panel, layers, density, alpha)
	local x, y = panel:LocalToScreen(0, 0)

	surface.SetDrawColor(255, 255, 255, alpha)
	surface.SetMaterial(self.BlurMat)

	for i = 1, 3 do
		self.BlurMat:SetFloat("$blur", (i / layers) * density)
		self.BlurMat:Recompute()
		render.UpdateScreenEffectTexture()
		surface.DrawTexturedRect(-x, -y, ScrW(), ScrH())
	end
end

function PANEL:Paint(width, height)
	self:DrawBlur(self, 1, 1, self.Alpha)
	draw.RoundedBox(0, 0, 0, width, height, Color(30, 25, 10, self.Alpha))
	-- draw.RoundedBox(2, 0, 0, width, 22, Color(0, 0, 0, self.Alpha))
	draw.RoundedBox(2, 0, 0, width, 22, Color(229, 122, 38, self.Alpha))
	surface.SetDrawColor(Color(229, 122, 38, self.Alpha))
	surface.DrawOutlinedRect(0,0,width,22,2)
	draw.SimpleText('Stalker-Online #1', "SChat220", 27, 2, Color(255, 255, 255, self.Alpha), TEXT_ALIGN_LEFT)
	draw.SimpleText('☢', "SChat220", 5, 0, Color(255, 255, 255, self.Alpha), TEXT_ALIGN_LEFT)
end

function PANEL:AddNewLine(info)
	-- local Line = vgui.Create("SChat2Line", self.ScrollPanel)
	-- Line:HandleSetup(...)
	-- local y = self.ScrollPanel.pnlCanvas:GetTall()
	-- local w, h = Line:GetSize()

	-- y = y + h * 0.5
	-- y = y - self.ScrollPanel:GetTall() * 0.5

	-- self.ScrollPanel.VBar:AnimateTo(y, 0.5, 0, 0.5)
	if SChat2:GetConvar("showTimestamps", false) then
		self.Txt:InsertColorChange(210, 210, 210, 210)
		self.Txt:AppendText("" .. os.date("%X", os.time()) .. " ")
		self.Txt:InsertFade(10, 2)
	end
	-- PrintTable(info)
	for _, v in ipairs(info) do
		-- print(type(v))
		if type(v) == "Player" then
			local col = team.GetColor(v:Team())
			self.Txt:InsertColorChange(col.r, col.g, col.b, 255)
			self.Txt:AppendText(v:Nick())
			self.Txt:InsertFade(10, 2)
			self.Txt:InsertColorChange(215, 215, 215, 255)
			self.Txt:AppendText(": ")
			self.Txt:InsertFade(10, 2)
		elseif type(v) == "string" then
			self.Txt:AppendText(v)
			self.Txt:InsertFade(10, 2)
		elseif type(v) == "table" then
			self.Txt:InsertColorChange(v.r, v.g, v.b, 255)
		end
	end
	self.Txt:AppendText("\n")

	-- if not IsValid(self.Ply) then
	-- 	self.Col = Color(210, 210, 210)
	-- 	self:InvalidateLayout()
	-- end
end

function PANEL:Chat()
	local textEntry = self.TextEntry
	local text = textEntry:GetValue()
	local textLen = text:utf8len()
	if textLen == 0 then
		self:ChatHide()
		return
	end

	if not (textEntry.lastLine or ""):find(text, 1, true) then
		local histCount = math.min(#textEntry.History, 19)
		textEntry.History[histCount + 1] = text

		textEntry.lastLine = text
	end

	if textLen > SChat2.Config.maxTextLength then
		surface.PlaySound("UI/buttonclick.wav")
		textEntry:SetCaretPos(textLen)
		return
	end

	textEntry:SetText("")
	textEntry:RequestFocus()
	self:ChatHide(true)

	local find = select(3, text:find("^([абвгдеёжзийклмнопрстуфхцчшщъьыэюяАБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЬЫЭЮЯ%g%s]+)$"))
	if find ~= text then
		find = nil
		return
	end
	find = nil

	text = text:gsub("%s+", " ")

	net.Start("SChat2.Send")
	net.WriteBool(self.TeamBased)
	net.WriteString(text)
	net.SendToServer()
end

function PANEL:ChatHide(enter)
	gamemode.Call("ChatTextChanged", "")
	if enter and not SChat2:GetConvar("closeOnEnter", true) then
		return
	end

	local x, y = self:GetPos()
	local w, h = self:GetSize()
	local _cvars = SChat2.cvars
	if x ~= _cvars["posX"] or y ~= _cvars["posY"] or w ~= _cvars["sizeW"] or h ~= _cvars["sizeH"] then
		SChat2:SetConvars({"sizeW", w}, {"sizeH", h}, {"posX", x}, {"posY", y})
	end

	self.Displayed = false

	self.Txt:SetVerticalScrollbarEnabled(false)
	self.Txt:ResetAllFades(false, true, 0)
	self.Txt:GotoTextEnd()

	self:ApplyAlpha()
	self:SetMouseInputEnabled(false)
	self:SetKeyboardInputEnabled(false)
	gamemode.Call("FinishChat")

	net.Start("SCHat2.Typing")
	net.WriteBool(false)
	net.SendToServer()
end

function PANEL:ChatShow()
	self.Displayed = true

	self.Txt:SetVerticalScrollbarEnabled(true)
	self.Txt:ResetAllFades(true, true, -1)

	self:ApplyAlpha()
	self:SetMouseInputEnabled(true)
	self:SetKeyboardInputEnabled(true)
	self.TextEntry:RequestFocus()
	gamemode.Call("ChatTextChanged", self.TextEntry:GetValue())
	gamemode.Call("StartChat", self.TeamBased)

	net.Start("SCHat2.Typing")
	net.WriteBool(true)
	net.SendToServer()
end

function PANEL:ApplyAlpha()
	if self.Displayed == true then
		self.Alpha = 170
	else
		self.Alpha = 0
	end
	self.Closer:SetAlpha(self.Alpha)
	self.TextEntry:SetAlpha(self.Alpha)
	self.TextActivate:SetAlpha(self.Alpha)
end

vgui.Register("SChat2Base", PANEL, "DFrame")
