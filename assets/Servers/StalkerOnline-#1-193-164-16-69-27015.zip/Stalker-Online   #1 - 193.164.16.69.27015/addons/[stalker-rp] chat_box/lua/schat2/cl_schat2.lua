include("schat2_config.lua")
include("vgui/cl_basepanel.lua")

if SChat2.Panel and IsValid(SChat2.Panel) then
	SChat2.Panel:Remove()
	SChat2.Panel = nil
end

//SChat2.AddChat = SChat2.AddChat or chat.AddText

local meta = debug.getregistry().Player
function meta:ChatPrint(str)
	chat.AddText(str)
end

local function parseArgs(...)
	local args = {}
	for _, v in ipairs({...}) do
		if v then
			args[#args + 1] = v
		end
	end
	return args
end


chatAddText = chatAddText or chat.AddText

function chat.AddText(...)
	local args = parseArgs(...)
	//SChat2.AddChat(args)
	chatAddText(...)
	if not SChat2.Panel then
		SChat2.Panel = vgui.Create("SChat2Base")
		SChat2.Panel:ChatHide()
	end
	SChat2.Panel:AddNewLine(args)
end

SChat2.AddChat = SChat2.AddChat or chat.AddText

function chat.GetChatBoxPos()
	if not SChat2.Panel then
		SChat2.Panel = vgui.Create("SChat2Base")
		SChat2.Panel:ChatHide()
	end
	return SChat2.Panel:GetPos()
end

function chat.GetChatBoxSize()
	if not SChat2.Panel then
		SChat2.Panel = vgui.Create("SChat2Base")
		SChat2.Panel:ChatHide()
	end
	return SChat2.Panel:GetSize()
end

hook.Add(
	"HUDShouldDraw",
	"SChat2HideHUD",
	function(v)
		if v == "CHudChat" then
			return false
		end
	end
)

hook.Add(
	"PlayerBindPress",
	"SChat2BindPress",
	function(ply, bind, pressed)
		if ply == LocalPlayer() then
			if bind == "messagemode" and pressed then
				if not IsValid(SChat2.Panel) then
					SChat2.Panel = vgui.Create("SChat2Base")
				end
				SChat2.Panel:ChatShow()
				SChat2.Panel.TeamBased = false
				return true
			elseif bind == "messagemode2" and pressed then
				if not IsValid(SChat2.Panel) then
					SChat2.Panel = vgui.Create("SChat2Base")
				end
				SChat2.Panel:ChatShow()
				SChat2.Panel.TeamBased = true
				return true
			end
		end
	end
)

hook.Add(
    "OnPlayerChat",
    "SChat2Handle",
    function(ply, msg, _, dead, prefixText, col1, col2)
        if SChat2.Panel then
            if prefixText then
                local tcol = ply:GetTeamColor()
                prefixText = prefixText .. ": "
                if prefixText:StartWith('[' .. ply:Team() .. ']') then
                    prefixText = '[' .. team.GetName(ply:Team()) .. '] ' .. ply:GetName() .. ': '
                    -- prefixText = prefixText:sub(4,#prefixText)
                end
                -- prefixText = string.Replace(prefixText, ply:Nick() .. ": ", "")
                chat.AddText(tcol, prefixText, col2, msg)
            else --Most likely a server 'say' message
                chat.AddText(Color(143, 218, 230), msg)
            end
            return true
        end
    end
)

net.Receive(
	"SChat2Message",
	function()
		chat.AddText(Color(151, 211, 255), net.ReadString())
	end
)

net.Receive(
	"SChat2Message2",
	function()
		chat.AddText(unpack(net.ReadTable()))
	end
)
