SChat2 = SChat2 or {}
SChat2.Config = SChat2.Config or {}

SChat2.Config.maxTextLength = 512
if CLIENT then
	include("cl_schat2_cvars.lua")

	SChat2.Config.posX = 10
	SChat2.Config.posY = ScrH() * 0.5

	SChat2.Config.sizeW = ScrW() / 3
	SChat2.Config.sizeH = ScrH() / 3

	SChat2.Config.minSizeW = 1.2
	SChat2.Config.minSizeH = 1.5

	SChat2.Config.remainTime = 7

	SChat2.Config.showTimestamps = false

	SChat2.Config.closeOnEnter = true

	SChat2.Config.Color = Color(66, 139, 202, 255)

	surface.CreateFont("SChat217", {font = "Roboto", size = 15, weight = 600, shadow = true, extended = true, antialias = true})
	surface.CreateFont("SChat218", {font = "Arial", size = 17, weight = 600, shadow = true, extended = true, antialias = true})
	surface.CreateFont("SChat218Italic", {font = "Arial", size = 18, weight = 500, italic = true, extended = true})
	surface.CreateFont("SChat220", {font = "Roboto", size = 19, weight = 600, extended = true})
end

local meta = FindMetaTable("Player")
function meta:IsTyping()
	return false//self:GetNetVar("IsTyping", false) and not self:GetNetVar("IgnoreIsTalking")
end
