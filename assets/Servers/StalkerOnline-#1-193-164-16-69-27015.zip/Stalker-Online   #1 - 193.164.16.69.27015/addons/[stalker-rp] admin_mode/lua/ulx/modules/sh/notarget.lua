--[[---------------------------
		Made by Zaktak
-----------------------------]]
-- Do not reupload, ty :P


--[[--------------
	No-Target
----------------]]
function ulx.notarget(calling_ply, target_plys, should_save)
	if !calling_ply:GetNetVar("AMode",true) and !calling_ply:IsSuperAdmin() then return end
	for k, v in pairs( target_plys ) do	 -- For loop on target players given
		if (!IsValid(v)) then return end -- If they aren't valid, abort.
		v:SetNoTarget(true) -- Set them to be no-targeted
		if (should_save == true) then -- If given "true"
			v:SetNWBool("zk_ulxntsave", true) -- Save NW Var.
		else
			v:SetNWBool("zk_ulxntsave", false) -- Save NW Var.
		end
	end

	if (should_save == true) then
		ulx.fancyLogAdmin( calling_ply, "#A включил видимость НПС для #T, (Persistent: #s)", target_plys, should_save)
	else
		ulx.fancyLogAdmin( calling_ply, "#A включил видимость НПС для #T", target_plys)
	end
end


local notarget = ulx.command( "Утилиты", "ulx notarget", ulx.notarget, {"!notarget", "!nt"} )
notarget:addParam{ type=ULib.cmds.PlayersArg }
notarget:addParam{ type=ULib.cmds.BoolArg, hint="Persistent?", invisible=true }
notarget:defaultAccess( ULib.ACCESS_ADMIN )
notarget:help( "Включает игнор всех НПС." )



--[[--------------
   Un-No-Target
----------------]]

function ulx.unnotarget(calling_ply, target_plys)
	if !calling_ply:GetNetVar("AMode",true) and !calling_ply:IsSuperAdmin() then return end

	for k, v in pairs( target_plys ) do	 -- For loop on target players given
		if (!IsValid(v)) then return end -- If they aren't valid, abort.
		v:SetNoTarget(false) -- Set them to be targeted.
		v:SetNWBool("zk_ulxntsave", false) -- Save NW Var.
	end
	ulx.fancyLogAdmin( calling_ply, "#A отключил видимость НПС для #T", target_plys )
end

local unnotarget = ulx.command( "Утилиты", "ulx unnotarget", ulx.unnotarget, {"!unnotarget", "!unnt"} )
unnotarget:addParam{ type=ULib.cmds.PlayersArg }
unnotarget:defaultAccess( ULib.ACCESS_ADMIN )
unnotarget:help( "Отключает игнор всех НПС." )



--[[--------------
	Save Hook
----------------]]
if SERVER then
	hook.Add("PlayerSpawn", "ZK_ULXNTSpawn", function(ply)
		if (ply:GetNWBool("zk_ulxntsave") == true) then -- If NW Var is true
			ply:SetNoTarget(true) -- Set them to be no-targeted again.
		end
	end)
end
