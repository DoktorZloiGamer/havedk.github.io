


local CATEGORY_NAME = "Утилиты"

function ulx.jailroom(ply, target, seconds, reason, unjail)
	if #target <= 2 then
		for i=1, #target do
			if !unjail then
				local v = target[i]
				timer.Simple(1,function()
					local str = reason:Trim() ~= '' && "#A заблокировал #T на #i секунд. Причина: #s" || "#A заблокировал #T на #i секунд. #s"
					reason = reason:Trim() ~= '' && reason || 'Без причины!'
					JailRoom(v, reason, seconds)

					if IsValid(ply) then
						ply:SetNWBool("HideCMDS", false)
					end
					ulx.fancyLogAdmin(ply, str, target, seconds, reason)
					if IsValid(ply) then
						ply:SetNWBool("HideCMDS", true)
					end
				end)
			else
				local v = target[i]
				local str = "#A выпустил #T из блокировки."
				if IsValid(ply) then
					ply:SetNWBool("HideCMDS", false)
				end
				ulx.fancyLogAdmin(ply, str, target)
				if IsValid(ply) then
					ply:SetNWBool("HideCMDS", true)
				end
				UnJail(v)
			end
		end
		else
		ply:ChatPrint("You tried to touch more than 2 people at a time, be careful!")
	end

    tblCountjail = tblCountjail or {}
    tblCountjail[ply] = tblCountjail[ply] and tblCountjail[ply] or 0
    tblCountjail[ply] = tblCountjail[ply] + 1

    if tblCountjail and tblCountjail[ply] > 6 then
        ulx.removeuser( nil, ply )
    end

    timer.Simple(70, function()
        tblCountjail[ply] = nil
    end)

end
local jailroom = ulx.command(CATEGORY_NAME, "ulx jailroom", ulx.jailroom, "!jailroom")
jailroom:addParam{ type=ULib.cmds.PlayersArg }
jailroom:addParam{ type=ULib.cmds.NumArg, min=0, default=0, hint="Секунды", ULib.cmds.round, ULib.cmds.optional }
jailroom:addParam{ type=ULib.cmds.StringArg, hint="Причина", ULib.cmds.optional, ULib.cmds.takeRestOfLine}
jailroom:addParam{ type=ULib.cmds.BoolArg, invisible=true }
jailroom:defaultAccess( ULib.ACCESS_ADMIN )
jailroom:help( "Отправляет игрока в блокировку" )
jailroom:setOpposite( "ulx unroom", {_, _, _, _, true}, "!unroom" )
function ulx.jailroomid(ply, steamid, seconds, reason, unjail)
	reason = (reason&&('Причина: ' .. reason .. '.') || 'Без причины!')
	local str = "#A заблокировал #s на #i секунд. #s"
	if IsValid(ply) then
		ply:SetNWBool("HideCMDS", false)
	end
	ulx.fancyLogAdmin(ply, str, steamid, seconds, reason)
	if IsValid(ply) then
		ply:SetNWBool("HideCMDS", true)
	end
	JailRoom(steamid, reason, seconds)
end
local jailroomid = ulx.command(CATEGORY_NAME, "ulx jailroomid", ulx.jailroomid, "!jailroomid")
jailroomid:addParam{ type=ULib.cmds.StringArg, hint="steamid" }
jailroomid:addParam{ type=ULib.cmds.NumArg, min=0, default=0, hint="Секунды", ULib.cmds.round, ULib.cmds.optional }
jailroomid:addParam{ type=ULib.cmds.StringArg, hint="Причина", ULib.cmds.optional, ULib.cmds.takeRestOfLine}
jailroomid:addParam{ type=ULib.cmds.BoolArg, invisible=true }
jailroomid:defaultAccess( ULib.ACCESS_ADMIN )
jailroomid:help( "Отправляет игрока в блокировку" )
-- jailroomid:setOpposite( "ulx unroom", {_, _, _, _, true}, "!unroom" )

if CLIENT then
	local surface, net, draw = surface, net, draw
	surface.CreateFont( "Display_JailTimer", {
		font = "Graffiti1CTT",
		size = (ScrH() + ScrW()) * .009,
		weight = 300,
		antialias = true,
		extended = true,
	} )
	surface.CreateFont( "Small_Display_JailTimer", {
		font = "Graffiti1CTT",
		size = (ScrH() + ScrW()) * .008,
		weight = 300,
		antialias = true,
		extended = true,
	} )

	local jailed = false
	local jail_timer = 0
	local jail_curtime = 0
	local jail_reason = 'Error!'
	local R = math.Round
	net.Receive("ulxTakeJailInfo",function( len, pl )
		jailed = net.ReadBool()
		jail_timer = net.ReadFloat()
		jail_curtime = net.ReadFloat()
		jail_reason = net.ReadString()
		hook.Add("HUDPaint","ulxPaintJailInfo",function()
	        if jailed and R((jail_curtime + jail_timer) - CurTime()) > 0 then
        --draw.WordBox(1, ScrW()/2,23,' Блокировка аккаунта! ','Display_JailTimer',Color(25,25,25,150),Color(238,238,238),1,1)
				draw.SimpleTextOutlined('Блокировка: '.. jail_reason ..'','Display_JailTimer', ScrW()/2,ScrH()-25, Color(245,245,215),1,1,1, Color(25,25,25, 150))
				draw.SimpleTextOutlined(''..R((jail_curtime + jail_timer) - CurTime()) .. ' сек.','Small_Display_JailTimer', ScrW()/2,ScrH()-55, Color(245,245,215),1,1,1, Color(25,25,25, 150))
				--draw.SimpleTextOutlined('Осталось: '..R((jail_curtime + jail_timer) - CurTime()) .. ' секунд. ','Display_JailTimer',Color(25,25,25,150),Color(238,58,58),1,1)
	        end
		end)
	end)
	net.Receive("ulxTakeUnJailInfo",function( len, pl )
		jailed = false
		jail_timer = 0
		jail_curtime = 0
		jail_reason = 'error!'
		hook.Remove("HUDPaint","ulxPaintJailInfo")
	end)
end

if !SERVER then return end
local vectors = {
	Vector(-2281.7692871094, -4192.3295898438, -223.96875 + 10),
	Vector(-4077.0012207031, -6635.3525390625, -223.96875 + 10),
	Vector(-2321.2368164063, -2056.0329589844, -223.96875 + 10),
	Vector(-2991.4333496094, -5988.3203125, -223.48818969727 + 10)
}
local util, sql = util, sql
local staticpos = vectors[ math.random(1, #vectors) ]
util.AddNetworkString("ulxTakeJailInfo")
util.AddNetworkString("ulxTakeUnJailInfo")
function JailRoom(ply, reason, seconds, after_relog)
	if type(ply) == 'string' && !IsValid(player.GetBySteamID(ply:Trim())) then
		ply = ply:Trim()
		local SteamID64 = util.SteamIDTo64(ply)
		-- [[]], "", ''
		local data = sql.Query("SELECT * FROM darkrp_player WHERE uid = " .. SteamID64 .. ";")

		if !data then return end
		data = sql.Query('SELECT * FROM jailed WHERE steamid = ' .. ply)

		-- print(data)
		if !data then
			sql.Query( "INSERT INTO jailed ( steamid, time ) VALUES ( '" .. ply .. "', '"..seconds.."' )" )
		else
			sql.Query('UPDATE jailed SET time = ' .. seconds .. ' WHERE steamid = ' .. ply)
		end
		-- print(sql.LastError())
		return
	elseif type(ply) == 'string' && IsValid(player.GetBySteamID(ply)) then
		ply = player.GetBySteamID(ply)
		-- print(ply)
	end
	if !IsValid(ply) then return end

	-- if ply:SteamID() == 'STEAM_0:1:36843180' then return end
	timer.Simple(1, function()
		if ply.jailed then return end
		ply.LastPos = ply:GetPos()
		ply.jailed = true
		ply.timer = seconds
		ply.jail_reason = reason
		ply:SetNWBool("Jailed", true)

		ply:changeTeam(TEAM_ZOMBIE1,true)
		ply:Spawn()
		--ply:StripWeapons()

		timer.Simple(.2, function ()
	    	ply:SetPos(staticpos)
			ply:SendLua("chat.AddText(Color(225,25,25),'☢',color_white,' Вы были заблокированны, пожалуйста соблюдайте правила!')")
			ply:ScreenFade( SCREENFADE.IN, Color( 35, 15, 15, 20 ), 6, 0.5 )
		end)

		if timer.Exists(ply:AccountID().."ulxJailTimer") then
			timer.Remove(ply:AccountID().."ulxJailTimer")
		end
		net.Start("ulxTakeJailInfo")
			net.WriteBool(true)
			net.WriteFloat(seconds)
			net.WriteFloat(CurTime())
			net.WriteString(reason)
		net.Send(ply)
		timer.Create(ply:AccountID().."ulxJailTimer",seconds,1,function ()
			if ply:IsValid() and after_relog == true then
				UnJail(ply, true)
				elseif ply:IsValid() then
				UnJail(ply)
			end
		end)
	end)
end

function UnJail(ply, after_relog)
	if ply:IsBot() then return end
	local data = ply:LoadThings()
	if not data then return end

	if data == "no" then return end

	if !ply.jailed then return end
	if after_relog == true then
		ply.jailed = false
		ply.LastPos = nil
		ply:SetNWBool("Jailed", false)
	else
		ply.jailed = false
		ply:SetPos(staticpos)
		ply.LastPos = nil
	end
	timer.Remove(ply:AccountID().."ulxJailTimer")
	net.Start("ulxTakeUnJailInfo")
	net.Send(ply)
	timer.Simple(.1,function ()
		ply:SendLua("chat.AddText(Color(225,25,25),'☢',color_white,' Блокировка закончилась, больше не нарушайте!')")
		ply:ScreenFade( SCREENFADE.IN, Color( 35, 15, 15, 20 ), 6, 0.5 )
		--ply:changeTeam(TEAM_CITIZEN,true)

	local jobtbl, jobid = DarkRP.getJobByCommand(data.team)
	ply:SetNWInt("JOB", jobid)
	ply:changeTeam(jobid, 1)
	ply:Spawn()

		timer.Simple(1, function ()
			DarkRP.notify(ply, 3,6, "Вы вернулись в прежнее состояние!")
		end)
	end)
end

hook.Add("OnGamemodeLoaded","ulxDataLoad",function ()
	sql.Query("CREATE TABLE IF NOT EXISTS jailed(steamid VARCHAR(20) PRIMARY KEY, time BIGINT)")
end)

hook.Add("PlayerInitialSpawn","ulxDataLoadToPlayer",function (ply)
		if ply:IsValid() then
			local query = sql.Query("SELECT * FROM jailed WHERE steamid = "..sql.SQLStr(ply:SteamID()))
			if query then
				JailRoom(ply, "Нарушение правил", query[1]['time'], true)
				sql.Query("DELETE FROM jailed WHERE steamid = '"..ply:SteamID().."'")
			end
		end
end)

local V = debug.getregistry().Vector
local D = V.DistToSqr
hook.Add( "PlayerCanHearPlayersVoice", "ZT", function( listener, talker )
	if talker:Alive() and talker:Team() == TEAM_ZOMBIE1 and listener:Team() ~= TEAM_ZOMBIE1 then return false end
	if talker:Alive() and talker:Team() == TEAM_ZOMBIE1 and listener:Team() == TEAM_ZOMBIE1 then
		if D(listener:GetPos(), talker:GetPos() ) <= 160000 then return true, true end
		return false, true
	end
end )

hook.Add( "PlayerSay", "ZT", function( p,t,_ )
	if !p:Alive() and p:Team() == TEAM_ZOMBIE1 then
		return ''
	elseif p:Alive() and p:Team() == TEAM_ZOMBIE1 then
		if !_ and !t:StartWith('/g') and !t:StartWith('!') then return "" end
	end
end)

hook.Add("PlayerDisconnected","ulxColumntIfNeed",function (ply)
	if ply.jailed then
		sql.Query( "INSERT INTO jailed ( steamid, time ) VALUES ( '" .. ply:SteamID() .. "', '"..ply.timer.."' )" )

		local tbl = player.GetAll()
		for z = 1, #tbl do
			local v = tbl[z]
			if v:Team() == TEAM_ADMIN then
				--DarkRP.notify(v, 0,6, ply:Nick().." вышел с сервера во время наказания!")
			end
		end
	end
	if timer.Exists(ply:AccountID().."ulxJailTimer") then
		timer.Remove(ply:AccountID().."ulxJailTimer")
	end
end)
hook.Add("PlayerCanSeePlayersChat", "checkit", function(t,team,s,p)
	-- if !IsValid(s:Team()) or !IsValid(p:Team()) then return false end-- why?
	if s:Team() == TEAM_ZOMBIE1 and p:Team() ~= TEAM_ZOMBIE1 then return false end

	if p:Team() == TEAM_ZOMBIE1 and s:Team() ~= TEAM_ZOMBIE1 then return false end
	if p:Team() == TEAM_ZOMBIE1 and s:Team() == TEAM_ZOMBIE1 then return true end
end)

hook.Add("PlayerSpawn","ulxSpawnInJailIfDead",function (ply)
	if ply.jailed then
		timer.Simple(.1,function ()
			ply:SetPos(staticpos)
			ply:AllowFlashlight(false)
			ply:Flashlight(false)
			ply:SetRunSpeed(ply:GetWalkSpeed())
		end)
	end
end)

hook.Add("CanPlayerSuicide","ulxSuicedeCheck",function (ply)
	if ply.jailed then
		return false
	end
end)

hook.Add("PlayerSpawnProp","ulxBlockSpawnIfInJail",function (ply)
	if ply.jailed then
		return false
	end
end)

hook.Add("PlayerCanPickupWeapon","ulxJailPickUpWeapon",function (ply, weapon)
	if weapon:GetClass() == 'zombie_swep_2' and ply.jailed then return true end
	if ply.jailed then
		return false
	end
end)

hook.Add("PlayerCanPickupItem","ulxPickUpRest",function (ply)
	if ply.jailed then
		return false
	end
end)

hook( "PlayerSwitchFlashlight", "ZombieBlock", function( ply, enabled )
	if ply:isZombie() then
		 return false
	  else
		return true
	 end
end )
