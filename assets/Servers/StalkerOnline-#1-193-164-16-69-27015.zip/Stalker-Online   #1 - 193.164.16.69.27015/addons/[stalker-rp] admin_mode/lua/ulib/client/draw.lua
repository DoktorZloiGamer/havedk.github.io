surface.CreateFont( "Xui", {
	font = "Graffiti1CTT",
	size = 32,
	weight = 300,
	extended = true,
	antialias = true,
} )


function ULib.csayDraw( msg, color, duration, fade )
	color = color or Color( 255, 255, 255, 255 )
	duration = duration or 7
	local start = CurTime()

	local function drawToScreen()
		local alpha = 255
		local dtime = CurTime() - start

		if dtime > duration then -- Our time has come :'(
			hook.Remove( "HUDPaint", "CSayHelperDraw" )
			return
		end


		color.a  = alpha

		if !color.xx then color.xx = 0 end
color.xx = Lerp(FrameTime()*2.5, color.xx, 0+250 )

if !color.x then color.x = 0 end
color.x = Lerp(FrameTime()*2.5, color.x, 0+120 )

if !color.xxx then color.xxx = 0 end
color.xxx = Lerp(FrameTime()*6.5, color.xxx, ScrW() * 0.0 + ScrW() * 0.5 )

		--draw.DrawText( msg, "TargetID", ScrW() * 0.5, ScrH() * 0.25, color, TEXT_ALIGN_CENTER )
		draw.WordBox( 2, color.xxx, ScrH() * 0.1, " "..msg.." ", "Xui", Color(15,15,15,color.x), Color(255,255,255,color.xx), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP )
		--draw.WordBox( 2, color.xxx, ScrH() * 0.1, " "..msg.." ", "Xui", Color(15,15,15,color.x), Color(255,255,255,color.xx), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP )

	end

	hook.Add( "HUDPaint", "CSayHelperDraw", drawToScreen )
end
