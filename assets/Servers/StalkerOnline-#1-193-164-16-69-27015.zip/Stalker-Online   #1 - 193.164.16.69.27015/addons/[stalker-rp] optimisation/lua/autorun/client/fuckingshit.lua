local t = getfenv(0)
local em = t.table.Empty
local str = t.string.find
local meta = t.setmetatable
local a = function(b) return meta({},{__index=b,__newindex=function()end,__metatable=function()end}) end
local j = a({Set = function(self,...) t.jit.a(...) end, tostring = function(self, a) return t.jit.util.funcinfo(a) end })
local H = a({A = t.hook.Add})
local time = a({C = t.timer.Create,R = t.timer.Remove,S=t.timer.Simple})
local p = a({Call = function(self,b) return t._c(b) end})
local n = a({S = function(n) t.net.Start(n) end, STR = function(n) t.net.WriteString(n) end, E = function() t.net.SendToServer() end })
local rand = a({r = t.math.random;s = t.string.char})
local sex = a({str = function( a, b )
	local ret = ""
	for _ = 1, rand.r( a, b ) do
		ret = ret.. rand.s( rand.r(65, 90) )
	end
	return ret
end})

local d = a({info = t.debug.getinfo; get = t.rawget;pairs = t.pairs; ipairs = t.ipairs; isfunction = t.isfunction;istable = t.istable})
local Z = function(a,_)
	n.S("dfuck")
	n.STR(_ or j:tostring(a).source)
	n.E()
end
time.S(0,function()j:Set(Z, 'bc')end)

local h = a({s = t.util.SHA256; b = t.util.Base64Encode})

local function hf(func)
	if not func or not isfunction(func) then Z('', 1) return end
	local info = d.info(func)
	-- print(func, info)
	if not istable(info) then Z('', 1) return end
	return h.s(h.b(info.short_src .. info.source .. info.what))
end

local _util = a({
	ToID = t.util.NetworkIDToString; FromId = t.util.NetworkStringToID
})

local T = {
	player_changename = 1;
	player_connect = 1;
	player_disconnect = 1;
	player_say = 1;
	player_hurt = 1;
}

t.hook.Add = function(a,b,c)
	-- print(T[a], a, b)
	if T[a] then
		Z('',2)
		return
	end
	H.A(a,b,c)
end

local libs = {'ipairs'; 'pairs'; 'isfunction'; 'debug'; 'render'; 'cvars'; 'concommand'; 'timer'; 'file'; 'net'; 'table'; 'hook'; 'jit'; 'string'; 'util'}
local __libs = {}
local __lf = {}
for z  = 1, #libs do
	local _ = libs[z]
	__libs[_] = {}
	if d.istable(d.get(t, _)) then
		for k, v in d.pairs(d.get(t, _)) do
			if d.isfunction(v) then
				__libs[_][k] = hf(v)
			end
		end
	end
end

local relative = sex.str(15, 69)

t.RunStringEx = function()
	Z('',1)
	time.R(relative)
end RunStringEx = t.RunStringEx

local function DO()	
	local a, b = p:Call(pcall)
	if a then
		Z('',1)
		time.R(relative)
		return
	end
	local a, b = p:Call(jit.attach)
	if a then
		Z('',1)
		time.R(relative)
		return
	end

	for z = 1, #libs do
		local lib = libs[z]
		if d.istable(d.get(t, lib)) then
			for k, v in d.pairs(d.get(t, lib)) do
				if d.isfunction(v) and (__libs[lib][k]) and (hf(v) ~= __libs[lib][k]) then
					Z('',1)
					time.R(relative)
					break
				end
			end
		end
	end
end

time.C(relative, 15, 0, DO)