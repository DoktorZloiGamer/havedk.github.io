
AddCSLuaFile()

ENT.Type 			= "anim"
ENT.Base 			= "base_anim"
ENT.PrintName		= "Генератор"
ENT.Author			= "Stalker Developers"
ENT.Information		= ""
ENT.Category		= "Stalker Ents"

ENT.Spawnable		= true
ENT.AdminOnly		= false

--Radio music
ENT.RacysSong1 = NULL
ENT.RacysSong2 = NULL

ENT.SongSt = 0
ENT.NxtDelay = CurTime()



function ENT:Initialize( )
	if ( SERVER ) then
	self:SetModel( "models/stalkers/t_disel_generator_01.mdl" )
		self:SetMoveType( MOVETYPE_VPHYSICS )
		self:PhysicsInit( SOLID_VPHYSICS )
		self:SetUseType( SIMPLE_USE )
    local phys = self:GetPhysicsObject()
	if(phys:IsValid()) then phys:Wake() end

	self.Engine = NULL

self.RacysSong1 = CreateSound(self.Entity,"disel")
self.RacysSong2 = CreateSound(self.Entity,"disel2")
end
end
--------------
function ENT:Use()
	if self.NxtDelay < CurTime() then
	self.NxtDelay = CurTime()+0.5
	self.SongSt = self.SongSt + 1
					self:EmitSound("radio_sounds/dfan-switch.ogg")

			if self.SongSt >2 then
			self.SongSt = 0
					self:EmitSound("radio_sounds/dfan-switch.ogg")
			end



	end
end
-------------------
function ENT:Think()
	if ( SERVER ) then
if self.Entity:WaterLevel() > 0 then

		local effectdata = EffectData()
		effectdata:SetOrigin( self.Entity:GetPos())
		effectdata:SetStart(Vector(0,0,2))
		util.Effect( "PropellerBubbles", effectdata )
end

if self.SongSt == 0 then
	self.RacysSong1:Stop()
		self.RacysSong2:Stop()
end

if self.SongSt == 1 then
	self.RacysSong1:Play()

end
if self.SongSt == 2 then
	self.RacysSong1:Stop()
		self.RacysSong2:Play()
end

end
end
-------------------
function ENT:OnRemove()
	if ( SERVER ) then
	self.RacysSong1:Stop()
	self.RacysSong2:Stop()
	end
end
