
AddCSLuaFile()

ENT.Type 			= "anim"
ENT.Base 			= "base_anim"
ENT.PrintName		= "Пианино"
ENT.Author			= "Stalker Developers"
ENT.Information		= ""
ENT.Category		= "Stalker Ents"

ENT.Spawnable		= true
ENT.AdminOnly		= false

--Radio music
ENT.RacysSong1 = NULL
ENT.RacysSong2 = NULL
ENT.RacysSong3 = NULL
ENT.RacysSong4 = NULL
ENT.RacysSong5 = NULL
ENT.RacysSong6 = NULL
ENT.RacysSong7 = NULL
ENT.RacysSong8 = NULL
ENT.RacysSong9 = NULL


ENT.SongSt = 0
ENT.NxtDelay = CurTime()



function ENT:Initialize( )
	if ( SERVER ) then
	self:SetModel( "models/stalkers/st_piano_01.mdl" )
		self:SetMoveType( MOVETYPE_VPHYSICS )
		self:PhysicsInit( SOLID_VPHYSICS )
		self:SetUseType( SIMPLE_USE )
	self:SetAngles(Angle(0,0,0))
    local phys = self:GetPhysicsObject()
	if(phys:IsValid()) then phys:Wake() end

	self.Engine = NULL

self.RacysSong1 = CreateSound(self.Entity,"pi1")
self.RacysSong2 = CreateSound(self.Entity,"pi2")
self.RacysSong3 = CreateSound(self.Entity,"pi3")
self.RacysSong4 = CreateSound(self.Entity,"pi4")
self.RacysSong5 = CreateSound(self.Entity,"pi5")
self.RacysSong6 = CreateSound(self.Entity,"pi6")
self.RacysSong7 = CreateSound(self.Entity,"pi7")
self.RacysSong8 = CreateSound(self.Entity,"pi8")
self.RacysSong9 = CreateSound(self.Entity,"pi9")
		end
end
--------------
function ENT:Use()
	if ( SERVER ) then
	if self.NxtDelay < CurTime() then
	self.NxtDelay = CurTime()+0.5
	self.SongSt = self.SongSt + 1


			if self.SongSt >9 then
			self.SongSt = 0

			end



	end
	end
end
-------------------
function ENT:Think()
	if ( SERVER ) then
if self.Entity:WaterLevel() > 0 then

		local effectdata = EffectData()
		effectdata:SetOrigin( self.Entity:GetPos())
		effectdata:SetStart(Vector(0,0,2))
		util.Effect( "PropellerBubbles", effectdata )
end

if self.SongSt == 0 then
	self.RacysSong1:Stop()
	self.RacysSong2:Stop()
	self.RacysSong3:Stop()
	self.RacysSong4:Stop()
	self.RacysSong5:Stop()
	self.RacysSong6:Stop()
	self.RacysSong7:Stop()
	self.RacysSong8:Stop()
	self.RacysSong9:Stop()
end

if self.SongSt == 1 then
	self.RacysSong1:Play()
end

if self.SongSt == 2 then
	self.RacysSong1:Stop()
	self.RacysSong2:Play()
end

if self.SongSt == 3 then
	self.RacysSong2:Stop()
	self.RacysSong3:Play()
end

if self.SongSt == 4 then
	self.RacysSong3:Stop()
	self.RacysSong4:Play()
end

if self.SongSt == 5 then
	self.RacysSong4:Stop()
	self.RacysSong5:Play()
end

if self.SongSt == 6 then
	self.RacysSong5:Stop()
	self.RacysSong6:Play()
end

if self.SongSt == 7 then
	self.RacysSong6:Stop()
	self.RacysSong7:Play()
end

if self.SongSt == 8 then
	self.RacysSong7:Stop()
	self.RacysSong8:Play()
end
if self.SongSt == 9 then
	self.RacysSong8:Stop()
	self.RacysSong9:Play()
end
end
end
-------------------
function ENT:OnRemove()
	if ( SERVER ) then
	self.RacysSong1:Stop()
	self.RacysSong2:Stop()
	self.RacysSong3:Stop()
	self.RacysSong4:Stop()
	self.RacysSong5:Stop()
	self.RacysSong6:Stop()
	self.RacysSong7:Stop()
	self.RacysSong8:Stop()
	self.RacysSong9:Stop()
	end
end
