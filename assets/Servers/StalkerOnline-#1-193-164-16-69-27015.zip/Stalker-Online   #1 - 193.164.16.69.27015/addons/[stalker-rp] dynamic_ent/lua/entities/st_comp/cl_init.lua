include("shared.lua")

ENT.Category = "Stalker Ents"
ENT.PrintName = "Компьютер 90-х"
ENT.Author = "Stalker Developers"

function ENT:Initialize()
	self.PixVis1 = util.GetPixelVisibleHandle()
	self.PixVis2 = util.GetPixelVisibleHandle()
end

function ENT:GetSpritePos()
	local center = self:GetLightPos()+self:GetForward()

end

local matGlow = Material("sprites/light_ignorez")
function ENT:Draw()
	self:DrawModel()

	if not self:GetEnabled() then return end




	render.SetMaterial(matGlow)






	local dlight = DynamicLight( self:EntIndex() )

	if ( dlight ) then

		local c = self:GetColor()

		local size = math.Clamp(self:GetDistance()/10,0,100)
		local brght = self:GetBrightness()

		dlight.Pos = self:GetLightPos()
		dlight.r = 255
		dlight.g = 255
		dlight.b = 255
		dlight.Brightness = brght
		dlight.Decay = size * 5
		dlight.Size = size
		dlight.DieTime = CurTime() + 1

	end
end
