if (!file.Exists("autorun/vj_base_autorun.lua","LUA")) then return end

ENT.Base 			= "base_gmodentity"
ENT.Type 			= "anim"
ENT.PrintName 		= "Костер [Малый]"
ENT.Author 			= "Stalker Developers"
ENT.Contact 		= ""
ENT.Purpose 		= ""
ENT.Instructions 	= ""
ENT.Category		= "Stalker Ents"

ENT.Spawnable = true
ENT.AdminOnly = false
---------------------------------------------------------------------------------------------------------------------------------------------
if (CLIENT) then
	function ENT:Draw()
		self:DrawModel()
	end
end
---------------------------------------------------------------------------------------------------------------------------------------------
net.Receive("vj_fireplace_turnon5", function()
	local ent = net.ReadEntity()
	//if ent.FirePlaceOn == true then
	ent.FireLight1 = DynamicLight(ent:EntIndex())
	if (ent.FireLight1) then
		ent.FireLight1.Pos = ent:GetPos() +ent:GetUp()*15
		ent.FireLight1.r = 205
		ent.FireLight1.g = 80
		ent.FireLight1.b = 0
		ent.FireLight1.Brightness = 2
		ent.FireLight1.Size = 240
		ent.FireLight1.Decay = 240
		ent.FireLight1.DieTime = CurTime() + 1
	end
end)
---------------------------------------------------------------------------------------------------------------------------------------------
net.Receive("vj_fireplace_turnon6", function()
	local ent = net.ReadEntity()
	ParticleEffectAttach("burning_gib_01",PATTACH_ABSORIGIN_FOLLOW,ent,0)
	ParticleEffectAttach("env_embers_medium",PATTACH_ABSORIGIN_FOLLOW,ent,0)
end)
