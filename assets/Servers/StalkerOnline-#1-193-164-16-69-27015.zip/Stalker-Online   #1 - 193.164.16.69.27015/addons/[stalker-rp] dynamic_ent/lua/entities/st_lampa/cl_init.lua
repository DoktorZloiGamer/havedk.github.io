include("shared.lua")

ENT.Category = "Stalker Ents"
ENT.PrintName = "Настольная Лампа"
ENT.Author = "Stalker Developers"

function ENT:Initialize()
	self.PixVis1 = util.GetPixelVisibleHandle()
	self.PixVis2 = util.GetPixelVisibleHandle()
end

function ENT:GetSpritePos()
	local center = self:GetLightPos()+self:GetForward()
	local right = center - self:GetUp()*0 - self:GetForward()*1 - self:GetRight()*-5
	return right
end

local matGlow = Material("sprites/light_ignorez")
function ENT:Draw()
	self:DrawModel()

	if not self:GetEnabled() then return end

	local right = self:GetSpritePos()
	local visR = util.PixelVisible(right,12,self.PixVis1)


	render.SetMaterial(matGlow)

	if visR > 0 then
		render.DrawSprite(right,32*visR,32*visR,Color(155,155,150))
	end




	local dlight = DynamicLight( self:EntIndex() )

	if ( dlight ) then

		local c = self:GetColor()

		local size = math.Clamp(self:GetDistance()/10,0,100)
		local brght = self:GetBrightness()

		dlight.Pos = self:GetLightPos()
		dlight.r = 255
		dlight.g = 205
		dlight.b = 150
		dlight.Brightness = brght
		dlight.Decay = size * 5
		dlight.Size = size
		dlight.DieTime = CurTime() + 1

	end
end
