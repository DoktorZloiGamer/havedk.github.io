if (!file.Exists("autorun/vj_base_autorun.lua","LUA")) then return end

ENT.Base 			= "base_gmodentity"
ENT.Type 			= "anim"
ENT.PrintName 		= "Костер [Средний]"
ENT.Author 			= "Stalker Developers"
ENT.Contact 		= ""
ENT.Purpose 		= ""
ENT.Instructions 	= "."
ENT.Category		= "Stalker Ents"

ENT.Spawnable = true
ENT.AdminOnly = false
---------------------------------------------------------------------------------------------------------------------------------------------
if (CLIENT) then
	function ENT:Draw()
		self:DrawModel()
	end
end
---------------------------------------------------------------------------------------------------------------------------------------------
net.Receive("vj_fireplace_turnon3", function()
	local ent = net.ReadEntity()
	//if ent.FirePlaceOn == true then
	ent.FireLight1 = DynamicLight(ent:EntIndex())
	if (ent.FireLight1) then
		ent.FireLight1.Pos = ent:GetPos() +ent:GetUp()*15
		ent.FireLight1.r = 255
		ent.FireLight1.g = 50
		ent.FireLight1.b = 0
		ent.FireLight1.Brightness = 1
		ent.FireLight1.Size = 150
		ent.FireLight1.Decay = 150
		ent.FireLight1.DieTime = CurTime() + 1
	end
end)
---------------------------------------------------------------------------------------------------------------------------------------------
net.Receive("vj_fireplace_turnon4", function()
	local ent = net.ReadEntity()
	ParticleEffectAttach("burning_engine_fire",PATTACH_ABSORIGIN_FOLLOW,ent,0)
	ParticleEffectAttach("env_embers_large",PATTACH_ABSORIGIN_FOLLOW,ent,0)
end)
