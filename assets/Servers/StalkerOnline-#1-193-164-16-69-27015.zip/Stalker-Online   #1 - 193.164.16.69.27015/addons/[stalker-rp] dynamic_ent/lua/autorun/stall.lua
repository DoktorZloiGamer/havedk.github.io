sound.Add(
{
name = "tester1",
channel = CHAN_ITEM,
volume = 1,
level = 65,
soundlevel = SNDLVL_NORM,
sound = "Radio_Sounds/Racya/1.ogg"
})
sound.Add(
{
name = "tester2",
channel = CHAN_ITEM,
volume = 1,
level = 65,
soundlevel = SNDLVL_NORM,
sound = "Radio_Sounds/Racya/3.ogg"
})

sound.Add(
{
name = "tester3",
channel = CHAN_ITEM,
volume = 1,
level = 65,
soundlevel = SNDLVL_NORM,
sound = "Radio_Sounds/Racya/6.ogg"
})

sound.Add(
{
name = "tester4",
channel = CHAN_ITEM,
volume = 1,
level = 65,
soundlevel = SNDLVL_NORM,
sound = "Radio_Sounds/Racya/8a.ogg"
})

sound.Add(
{
name = "tester5",
channel = CHAN_ITEM,
volume = 1,
level = 65,
soundlevel = SNDLVL_NORM,
sound = "Radio_Sounds/Racya/8b.ogg"
})

sound.Add(
{
name = "tester6",
channel = CHAN_ITEM,
volume = 1,
level = 69,
soundlevel = SNDLVL_NORM,
sound = "Radio_Sounds/Racya/8c.ogg"
})

sound.Add(
{
name = "tester7",
channel = CHAN_ITEM,
volume = 1,
level = 60,
soundlevel = SNDLVL_NORM,
sound = "Radio_Sounds/Racya/8d.ogg"
})

sound.Add(
{
name = "tester8",
channel = CHAN_ITEM,
volume = 1,
level = 70,
soundlevel = SNDLVL_NORM,
sound = "Radio_Sounds/Racya/radio_comm_2.ogg"
})

sound.Add(
{
name = "testers1",
channel = CHAN_ITEM,
volume = 1,
level = 60,
soundlevel = SNDLVL_NORM,
sound = "Radio_Sounds/Radio/megafon_music_1.ogg"
})


sound.Add(
{
name = "testers2",
channel = CHAN_ITEM,
volume = 1,
level = 60,
soundlevel = SNDLVL_NORM,
sound = "Radio_Sounds/Radio/megafon_music_3.ogg"
})

sound.Add(
{
name = "testers3",
channel = CHAN_ITEM,
volume = 1,
level = 65,
soundlevel = SNDLVL_NORM,
sound = "Radio_Sounds/Radio/bas_bad_music1.ogg"
})

sound.Add(
{
name = "testers4",
channel = CHAN_ITEM,
volume = 1,
level = 75,
soundlevel = SNDLVL_NORM,
sound = "Radio_Sounds/Radio/treck1.ogg"
})

sound.Add(
{
name = "testers5",
channel = CHAN_ITEM,
volume = 1,
level = 58,
soundlevel = SNDLVL_NORM,
sound = "Radio_Sounds/Radio/treck2.ogg"
})

sound.Add(
{
name = "testers6",
channel = CHAN_ITEM,
volume = 1,
level = 100,
soundlevel = SNDLVL_NORM,
sound = "Radio_Sounds/Radio/treck3.ogg"
})

sound.Add(
{
name = "testers7",
channel = CHAN_ITEM,
volume = 1,
level = 75,
soundlevel = SNDLVL_NORM,
sound = "Radio_Sounds/Radio/treck5.ogg"
})

sound.Add(
{
name = "testers8",
channel = CHAN_ITEM,
volume = 1,
level = 75,
soundlevel = SNDLVL_NORM,
sound = "Radio_Sounds/Radio/treck6.ogg"
})

sound.Add(
{
name = "testers9",
channel = CHAN_ITEM,
volume = 1,
level = 75,
soundlevel = SNDLVL_NORM,
sound = "Radio_Sounds/Radio/treck7.ogg"
})


sound.Add(
{
name = "testers10",
channel = CHAN_ITEM,
volume = 1,
level = 75,
soundlevel = SNDLVL_NORM,
sound = "Radio_Sounds/Radio/treck9.ogg"
})
sound.Add(
{
name = "testers11",
channel = CHAN_ITEM,
volume = 1,
level = 65,
soundlevel = SNDLVL_NORM,
sound = "Radio_Sounds/Radio/1.wav"
})


sound.Add(
{
name = "testera1",
channel = CHAN_ITEM,
volume = 1,
level = 65,
soundlevel = SNDLVL_NORM,
sound = "Radio_Sounds/music/duty_base_radio_1.ogg"
})

sound.Add(
{
name = "testera2",
channel = CHAN_ITEM,
volume = 1,
level = 65,
soundlevel = SNDLVL_NORM,
sound = "Radio_Sounds/music/duty_base_radio_2.ogg"
})

sound.Add(
{
name = "testera3",
channel = CHAN_ITEM,
volume = 1,
level = 65,
soundlevel = SNDLVL_NORM,
sound = "Radio_Sounds/music/freedom_base_radio_1.ogg"
})

sound.Add(
{
name = "testera4",
channel = CHAN_ITEM,
volume = 1,
level = 65,
soundlevel = SNDLVL_NORM,
sound = "Radio_Sounds/music/garbage_bandits_radio_1.ogg"
})

sound.Add(
{
name = "testera5",
channel = CHAN_ITEM,
volume = 1,
level = 65,
soundlevel = SNDLVL_NORM,
sound = "Radio_Sounds/music/marsh_radio_1.ogg"
})

sound.Add(
{
name = "testera6",
channel = CHAN_ITEM,
volume = 1,
level = 65,
soundlevel = SNDLVL_NORM,
sound = "Radio_Sounds/music/marsh_radio_2.ogg"
})

sound.Add(
{
name = "testera7",
channel = CHAN_ITEM,
volume = 1,
level = 65,
soundlevel = SNDLVL_NORM,
sound = "Radio_Sounds/music/radio_music_1.ogg"
})

sound.Add(
{
name = "testera11",
channel = CHAN_ITEM,
volume = 1,
level = 65,
soundlevel = SNDLVL_NORM,
sound = "Radio_Sounds/music/radio_music_2.ogg"
})

sound.Add(
{
name = "testera9",
channel = CHAN_ITEM,
volume = 1,
level = 65,
soundlevel = SNDLVL_NORM,
sound = "Radio_Sounds/music/radio_music_3.ogg"
})

sound.Add(
{
name = "testera10",
channel = CHAN_ITEM,
volume = 1,
level = 65,
soundlevel = SNDLVL_NORM,
sound = "Radio_Sounds/music/radio_music_4.ogg"
})

sound.Add(
{
name = "testera8",
volume = 1,
level = 65,
sound = "Radio_Sounds/music/radio_bruckner_2.ogg"
})

sound.Add(
{
name = "testera12",
volume = 1,
level = 65,
sound = "Radio_Sounds/music/radio_music_5.ogg"
})

sound.Add(
{
name = "vint",
volume = 1,
level = 65,
sound = "Radio_Sounds/dfan-spin.ogg"
})


sound.Add( {
	name = "firest",
	channel = CHAN_STATIC,
	volume = 1,
	level = 65,
	pitch = 100,
	sound = "radio_sounds/SP0000.wav"
} )

sound.Add( {
	name = "firest2",
	channel = CHAN_STATIC,
	volume = 1,
	level = 55,
	pitch = 100,
	sound = "radio_sounds/SP0001.wav"
} )

sound.Add( {
	name = "vns2",
	channel = CHAN_ITEM,
	volume = 1,
	level = 65,
	pitch = 100,
	sound = "radio_sounds/vhs/per.ogg"
} )

sound.Add( {
	name = "vns1",
	channel = CHAN_ITEM,
	volume = 1,
	level = 65,
	pitch = 100,
	sound = "radio_sounds/vhs/idle_1.ogg"
} )

sound.Add( {
	name = "vns3",
	channel = CHAN_ITEM,
	volume = 1,
	level = 65,
	pitch = 100,
	sound = "radio_sounds/vhs/pda5.ogg"
} )

sound.Add( {
	name = "vns4",
	channel = CHAN_ITEM,
	volume = 1,
	level = 65,
	pitch = 100,
	sound = "radio_sounds/vhs/idle_3.ogg"
} )

sound.Add( {
	name = "vns5",
	channel = CHAN_ITEM,
	volume = 1,
	level = 65,
	pitch = 100,
	sound = "radio_sounds/vhs/idle_4.ogg"
} )

sound.Add( {
	name = "vns6",
	channel = CHAN_ITEM,
	volume = 1,
	level = 65,
	pitch = 100,
	sound = "radio_sounds/vhs/idle_7.ogg"
} )

sound.Add( {
	name = "vns7",
	channel = CHAN_ITEM,
	volume = 1,
	level = 65,
	pitch = 100,
	sound = "radio_sounds/vhs/idle_8.ogg"
} )

sound.Add( {
	name = "vns99",
	channel = CHAN_ITEM,
	volume = 1,
	level = 65,
	pitch = 100,
	sound = "radio_sounds/vhs/idle_9.ogg"
} )

sound.Add( {
	name = "tv1",
	channel = CHAN_ITEM,
	volume = 1,
	level = 65,
	pitch = 100,
	sound = "radio_sounds/vhs/oso_2.ogg"
} )


sound.Add( {
	name = "tv2",
	channel = CHAN_ITEM,
	volume = 1,
	level = 65,
	pitch = 100,
	sound = "radio_sounds/vhs/sip_1.wav"
} )


sound.Add( {
	name = "tv3",
	channel = CHAN_ITEM,
	volume = 1,
	level = 65,
	pitch = 100,
	sound = "radio_sounds/tv/t1.ogg"
} )


sound.Add( {
	name = "tv4",
	channel = CHAN_ITEM,
	volume = 1,
	level = 65,
	pitch = 100,
	sound = "radio_sounds/tv/t2.ogg"
} )


sound.Add( {
	name = "tv5",
	channel = CHAN_ITEM,
	volume = 1,
	level = 65,
	pitch = 100,
	sound = "radio_sounds/tv/t4.ogg"
} )


sound.Add( {
	name = "tv6",
	channel = CHAN_ITEM,
	volume = 1,
	level = 65,
	pitch = 100,
	sound = "radio_sounds/tv/t5.ogg"
} )



sound.Add( {
	name = "pi1",
	channel = CHAN_ITEM,
	volume = 1,
	level = 70,
	pitch = 100,
	sound = "radio_sounds/pi/bunker1.ogg"
} )


sound.Add( {
	name = "pi2",
	channel = CHAN_ITEM,
	volume = 1,
	level = 70,
	pitch = 100,
	sound = "radio_sounds/pi/bandit1.ogg"
} )


sound.Add( {
	name = "pi3",
	channel = CHAN_ITEM,
	volume = 1,
	level = 70,
	pitch = 100,
	sound = "radio_sounds/pi/elf1.ogg"
} )


sound.Add( {
	name = "pi4",
	channel = CHAN_ITEM,
	volume = 1,
	level = 70,
	pitch = 100,
	sound = "radio_sounds/pi/pian1.ogg"
} )


sound.Add( {
	name = "pi5",
	channel = CHAN_ITEM,
	volume = 1,
	level = 70,
	pitch = 100,
	sound = "radio_sounds/pi/pino.ogg"
} )


sound.Add( {
	name = "pi6",
	channel = CHAN_ITEM,
	volume = 1,
	level = 70,
	pitch = 100,
	sound = "radio_sounds/pi/priboy.ogg"
} )


sound.Add( {
	name = "pi7",
	channel = CHAN_ITEM,
	volume = 1,
	level = 70,
	pitch = 100,
	sound = "radio_sounds/pi/tank1.ogg"
} )

sound.Add( {
	name = "pi8",
	channel = CHAN_ITEM,
	volume = 1,
	level = 70,
	pitch = 100,
	sound = "radio_sounds/pi/metro.ogg"
} )
sound.Add( {
	name = "pi9",
	channel = CHAN_ITEM,
	volume = 1,
	level = 70,
	pitch = 100,
	sound = "radio_sounds/pi/metro2.ogg"
} )

sound.Add( {
	name = "disel",
	channel = CHAN_ITEM,
	volume = 1,
	level = 75,
	pitch = 100,
	sound = "radio_sounds/SPss.wav"
} )

sound.Add( {
	name = "disel2",
	channel = CHAN_ITEM,
	volume = 1,
	level = 75,
	pitch = 100,
	sound = "radio_sounds/SPsp.wav"
} )


sound.Add( {
	name = "disel3",
	channel = CHAN_ITEM,
	volume = 1,
	level = 75,
	pitch = 100,
	sound = "radio_sounds/SP111.wav"
} )



sound.Add( {
	name = "ruf1",
	channel = CHAN_ITEM,
	volume = 1,
	level = 100,
	pitch = 100,
	sound = "radio_sounds/rufor/magnitofon_2.ogg"
} )


sound.Add( {
	name = "ruf2",
	channel = CHAN_ITEM,
	volume = 1,
	level = 100,
	pitch = 100,
	sound = "radio_sounds/rufor/megafon_music_1.ogg"
} )


sound.Add( {
	name = "ruf3",
	channel = CHAN_ITEM,
	volume = 1,
	level = 100,
	pitch = 100,
	sound = "radio_sounds/rufor/megafon_music_2.ogg"
} )


sound.Add( {
	name = "ruf4",
	channel = CHAN_ITEM,
	volume = 1,
	level = 100,
	pitch = 100,
	sound = "radio_sounds/rufor/megafon_music_3.ogg"
} )


sound.Add( {
	name = "ruf5",
	channel = CHAN_ITEM,
	volume = 1,
	level = 100,
	pitch = 100,
	sound = "radio_sounds/rufor/megafon_music_4.ogg"
} )


sound.Add( {
	name = "ruf6",
	channel = CHAN_ITEM,
	volume = 1,
	level = 100,
	pitch = 100,
	sound = "radio_sounds/rufor/megafon_music_5.ogg"
} )


sound.Add( {
	name = "ruf7",
	channel = CHAN_ITEM,
	volume = 1,
	level = 100,
	pitch = 100,
	sound = "radio_sounds/rufor/megafon_music_6.ogg"
} )


sound.Add( {
	name = "ruf8",
	channel = CHAN_ITEM,
	volume = 1,
	level = 100,
	pitch = 100,
	sound = "radio_sounds/rufor/megafon_music_7.ogg"
} )


sound.Add( {
	name = "ruf9",
	channel = CHAN_ITEM,
	volume = 1,
	level = 100,
	pitch = 100,
	sound = "radio_sounds/rufor/megafon_music_8.ogg"
} )


sound.Add( {
	name = "ruf10",
	channel = CHAN_ITEM,
	volume = 1,
	level = 100,
	pitch = 100,
	sound = "radio_sounds/rufor/megafon_music_9.ogg"
} )


sound.Add( {
	name = "ruf11",
	channel = CHAN_ITEM,
	volume = 1,
	level = 100,
	pitch = 100,
	sound = "radio_sounds/rufor/megafon_music_10.ogg"
} )


sound.Add( {
	name = "ruf12",
	channel = CHAN_ITEM,
	volume = 1,
	level = 100,
	pitch = 100,
	sound = "radio_sounds/rufor/megafon_music_11.ogg"
} )


sound.Add( {
	name = "ruf13",
	channel = CHAN_ITEM,
	volume = 1,
	level = 100,
	pitch = 100,
	sound = "radio_sounds/rufor/megafon_music_12.ogg"
} )


sound.Add( {
	name = "ruf14",
	channel = CHAN_ITEM,
	volume = 1,
	level = 100,
	pitch = 100,
	sound = "radio_sounds/rufor/megafon_music_13.ogg"
} )


sound.Add( {
	name = "ruf15",
	channel = CHAN_ITEM,
	volume = 1,
	level = 100,
	pitch = 100,
	sound = "radio_sounds/rufor/megafon_music_14.ogg"
} )

sound.Add( {
	name = "ruf16",
	channel = CHAN_ITEM,
	volume = 1,
	level = 100,
	pitch = 100,
	sound = "radio_sounds/rufor/megafon_music_15.ogg"
} )

sound.Add( {
	name = "ruf17",
	channel = CHAN_ITEM,
	volume = 1,
	level = 100,
	pitch = 100,
	sound = "radio_sounds/pi/spsire.wav"
} )

sound.Add( {
	name = "ruf18",
	channel = CHAN_ITEM,
	volume = 1,
	level = 100,
	pitch = 100,
	sound = "radio_sounds/pi/spsiri.wav"
} )

sound.Add( {
	name = "ruf19",
	channel = CHAN_ITEM,
	volume = 1,
	level = 100,
	pitch = 100,
	sound = "radio_sounds/pi/spsira.wav"
} )

sound.Add( {
	name = "pc1",
	channel = CHAN_ITEM,
	volume = 1,
	level = 65,
	pitch = 100,
	sound = "radio_sounds/pc/start.ogg"
} )

sound.Add( {
	name = "pc2",
	channel = CHAN_ITEM,
	volume = 1,
	level = 65,
	pitch = 100,
	sound = "radio_sounds/pc/beep.ogg"
} )

sound.Add( {
	name = "pc3",
	channel = CHAN_ITEM,
	volume = 1,
	level = 65,
	pitch = 100,
	sound = "radio_sounds/pc/SP0000.wav"
} )

sound.Add( {
	name = "pc4",
	channel = CHAN_ITEM,
	volume = 1,
	level = 65,
	pitch = 100,
	sound = "radio_sounds/pc/stop.ogg"
} )
