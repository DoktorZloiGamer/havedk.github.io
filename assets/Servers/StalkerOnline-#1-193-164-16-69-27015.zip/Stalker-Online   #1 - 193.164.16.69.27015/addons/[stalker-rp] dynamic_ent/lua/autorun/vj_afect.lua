/*--------------------------------------------------
	=============== Autorun File ===============
	*** Copyright (c) 2012-2017 by DrVrej, All rights reserved. ***
	No parts of this code or any of its contents may be reproduced, copied, modified or adapted,
	without the prior written consent of the author, unless otherwise indicated for stand-alone materials.
--------------------------------------------------*/
------------------ Addon Information ------------------
local PublicAddonName = ""
local AddonName = ""
local AddonType = "SNPC"
local AutorunFile = "autorun/vj_shadow_autorun.lua"
-------------------------------------------------------
local VJExists = file.Exists("lua/autorun/vj_base_autorun.lua","GAME")
if VJExists == true then
	include('autorun/vj_controls.lua')


game.AddParticles("particles/shadowmonster.pcf")
game.AddParticles("particles/vortigaunte_fx.pcf")
local particlename = {
	
"shadow",
"shadow2",
"shadow_hid",
"shadow_comer",
"shadow_blood",
"shadow_spike",
"shadow_bloodpool",
"shadow_blooder",
"shadow_bloodpool2",
"shadow_bloodpool3",
"shadow_blood_remove",
"shadow_blood_remove_monster",
	"vortigaunt_hand_glow_bs",
	"vortigaunt_hand_glow_cs",
	"vortigaunt_hand_glows",
}
for _,v in ipairs(particlename) do PrecacheParticleSystem(v) end
	  for k, v in pairs( player.GetAll() ) do

		

	if v:IsPlayer() then

					v.friclass = "CLASS_NEUTRAL" and "CLASS_NEUTRALS"
					v.SquadName = "vj_neutral"
					v.Class = "CLASS_NEUTRAL" and "CLASS_NEUTRALS"
					v.Classify = "CLASS_NEUTRAL" and "CLASS_NEUTRALS" 
					v.VJ_NPC_Class = {"CLASS_HERO_NEUTRAL","CLASS_HERO_BANDIT","CLASS_HERO_FREEDOM","CLASS_HERO_DUTY","CLASS_HERO_CS","CLASS_HERO_HUNTER","CLASS_HERO_SKIT","CLASS_HERO_UCHENIY","CLASS_HERO_KILLER","CLASS_HERO_GREH"}
					v.GetClass = "CLASS_NEUTRAL" and "CLASS_NEUTRALS"
					v.SetClass = "CLASS_NEUTRAL" and "CLASS_NEUTRALS"
		  	   
	

			end

		end
		end


