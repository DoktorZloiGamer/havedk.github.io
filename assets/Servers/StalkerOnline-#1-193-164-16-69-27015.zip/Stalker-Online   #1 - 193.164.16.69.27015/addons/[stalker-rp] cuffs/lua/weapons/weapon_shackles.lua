--[[
addons/[weapons] cuffs/lua/weapons/weapon_cuff_shackles.lua
--]]

-----------------------------------------
// [RU] Cuffs - Handcuffs and Restraints
-----------------------------------------

AddCSLuaFile()

SWEP.Base = "weapon_cuff_base"

SWEP.Category = "Stalker Items"
SWEP.Author = "Stalker Developers"
SWEP.Instructions = ""

SWEP.Spawnable = true
SWEP.AdminOnly = false
SWEP.AdminSpawnable = true

SWEP.Slot = 3
SWEP.PrintName = "Кандалы"

SWEP.CuffTime = 0.2 -- Время заковывания в наручники
SWEP.CuffSound = Sound( "buttons/lever7.wav" )

SWEP.CuffMaterial = "phoenix_storms/cube"
SWEP.CuffRope = "cable/cable2"
SWEP.CuffStrength = 1.8
SWEP.CuffRegen = 0.8
SWEP.RopeLength = 0

SWEP.CuffReusable = true -- Возможность использовать повторно ( true или false )
SWEP.CuffRecharge = 10 -- Время до повторного использования

SWEP.CuffBlindfold = false
SWEP.CuffGag = false

SWEP.CuffStrengthVariance = 0.4 -- Случайная сила наручников
SWEP.CuffRegenVariance = 0.1 -- Случайная регенерация наручников
