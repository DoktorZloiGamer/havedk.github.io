--[[
addons/[weapons] cuffs/lua/weapons/weapon_cuff_elastic.lua
--]]

-----------------------------------------
// [RU] Cuffs - Handcuffs and Restraints
-----------------------------------------

AddCSLuaFile()

SWEP.Base = "weapon_cuff_base"

SWEP.Category = "Stalker Items"
SWEP.Author = "Stalker Developers"
SWEP.Instructions = ""

SWEP.Spawnable = true
SWEP.AdminOnly = false
SWEP.AdminSpawnable = true

SWEP.Slot = 3
SWEP.PrintName = "Наручники"

SWEP.CuffTime = 0.01 -- Время заковывания в наручники
SWEP.CuffSound = Sound( "buttons/lever7.wav" )

SWEP.CuffMaterial = "models/props_pipes/GutterMetal01a"
SWEP.CuffRope = "cable/rope"
SWEP.CuffStrength = 1.2
SWEP.CuffRegen = 1.6
SWEP.RopeLength = 50

SWEP.CuffReusable = true -- Возможность использовать повторно ( true или false )
SWEP.CuffRecharge = 5 -- Время до повторного использования

SWEP.CuffBlindfold = true
SWEP.CuffGag = true

SWEP.CuffStrengthVariance = 0.1 -- Случайная сила наручников
SWEP.CuffRegenVariance = 0.3 -- Случайная регенерация наручников
