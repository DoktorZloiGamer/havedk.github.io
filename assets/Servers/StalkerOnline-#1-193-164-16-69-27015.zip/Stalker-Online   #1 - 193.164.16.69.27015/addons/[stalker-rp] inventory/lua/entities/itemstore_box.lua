ENT.Type = "anim"

ENT.PrintName = "Small Box"
ENT.Category = "ItemStore"

ENT.Spawnable = true
ENT.AdminOnly = true

function ENT:SetupDataTables()
	self:NetworkVar( "Entity", 0, "owning_ent" ) -- i feel really stupid.
end

if SERVER then
	AddCSLuaFile()
	local tblcat = {
		['Бандиты'] = 1;
		['Долг'] = 2;
		['Монолит'] = 3;
		['Наемники'] = 4;
		['Свобода'] = 5;
		['Военные'] = 6;
		['Ученые'] = 7;
		['Торговцы'] = 8;
		['Грех'] = 9;
	}
	ENT.Model = "models/props_c17/FurnitureDrawer001a.mdl"

	ENT.ContainerWidth = 4
	ENT.ContainerHeight = 3
	ENT.ContainerPages = 10

	function ENT:Initialize()
		self:SetModel( self.Model )

		self:PhysicsInit( SOLID_VPHYSICS )
		self:SetMoveType( MOVETYPE_VPHYSICS )
		self:SetSolid( SOLID_VPHYSICS )
		self:SetUseType( SIMPLE_USE )
		if IsValid(self:GetPhysicsObject()) then
			self:GetPhysicsObject():Wake()
		end

		self.Container = itemstore.Container( self.ContainerWidth, self.ContainerHeight, self.ContainerPages )
		self.Container:SetOwner( self )

		if self.Items then
			for _, item in ipairs( self.Items ) do
				self.Container:AddItem( item:Copy() )
			end
		end

		local function callback( con, pl )
			if not IsValid( pl ) then return end

			if pl:GetPos():Distance( self:GetPos() ) < 250 then
				return true
			end

			return false
		end

		self.Container:AddCallback( "read", callback )
		self.Container:AddCallback( "write", callback )

		self:SetHealth( itemstore.config.BoxHealth )
	end

	function ENT:SpawnFunction( pl, trace, class )
		local ent = ents.Create( class )
		ent:SetPos( trace.HitPos + trace.HitNormal * 16 )
		ent:Spawn()

		return ent
	end
	local role = RPExtraTeams
	function ENT:Use( p )
		local get = role[p:Team()].group
			if self:GetNWString("Faction") ~= "" && get ~= self:GetNWString("Faction")  then return end
			if (!p:GetNWBool("AcS" .. (tblcat[get] || 0) .. '_') && !p:isLeader()) then DarkRP.notify(p, 1, 6, 'Нет доступа. Обратитесь к лидеру фракции.') return end

		self.Container:Sync(p)
		p:OpenContainer( self.Container:GetID(), "Хранилище" )
	end

	function ENT:Break()
		-- local effect = EffectData()
		-- effect:SetOrigin( self:GetPos() )
		-- util.Effect( "Explosion", effect, true, true )

		-- for _, item in pairs( self.Container.Items ) do
		-- 	item:CreateEntity( self:GetPos() )
		-- end

		-- self:Remove()
	end

	function ENT:OnTakeDamage( dmg )
		-- if not itemstore.config.BoxBreakable then return end

		-- self:SetHealth( self:Health() - dmg:GetDamage() )

		-- if self:Health() <= 0 then
		-- 	self:Break()
		-- end
	end

	function ENT:OnRemove()
	end
end



if CLIENT then
ENT.RenderGroup = RENDERGROUP_OPAQUE

	surface.CreateFont('Inventory_Title', {font='Graffiti1CTT',size=85,weight=300,extended=true,antilialias=true})
	surface.CreateFont('Inventory_Sub', {font='Graffiti1CTT',size=40,weight=100,extended=true,antilialias=true})

	local COL_TEXT = Color(255,255,255)
	local COL_BG   = Color(0,0,0,150)
	local FONT     = "Inventory_Title"
  local stash_icon = Material('icon16/box.png')
	local box_icon = Material('stalker/hud/box_fix_item.png')

	local function textPlate(text,y)
		surface.SetFont(FONT)
		local tw,th = surface.GetTextSize(text)
		local bx,by = -tw / 2 - 5, y - 35
		local bw,bh = tw + 10 + 10, th + 10 + 10

		--surface.SetDrawColor(45,45,45)
		--surface.DrawRect(bx,by, bw,bh+10)
		--surface.SetDrawColor(32,191,107)
		--surface.DrawRect(bx,by+66, bw,4)
		--surface.SetDrawColor(32, 191, 107)
		--surface.DrawOutlinedRect(bx,by, bw,bh+10,2)

		--surface.SetTextColor(COL_TEXT)
		--surface.SetTextPos(-tw / 2+3,y-30)
		--surface.DrawText(text)

		--draw.WordBox(1, -tw / 2+3,y-30,' '..text..' ','Main_Text_Stash',Color(25,25,25,150),Color(74, 191, 72),TEXT_ALIGN_LEFT)
		draw.SimpleText(' '..text..' ','Inventory_Title',-tw / 2+3-25,y-40,color_white,Color(0,0,0),1,1,1)

		surface.SetMaterial( box_icon )
		surface.SetDrawColor( 255, 255, 255, 255 )
		surface.DrawTexturedRect( -tw / 2+5-53,y-54, 56, 56 )

		surface.SetTextColor(Color(200,200,200))
		surface.SetTextPos(-tw / 2-40,y-15)
		surface.SetFont('Inventory_Sub')
		surface.DrawText('Только для членов группировки')
	end

	local function drawInfo(ent, text, dist)
		dist = dist or EyePos():DistToSqr(ent:GetPos())

		if dist < 60000 then
			surface.SetAlphaMultiplier( math.Clamp(3 - (dist / 20000), 0, 1) )

			local _,max = ent:GetRotatedAABB(ent:OBBMins(), ent:OBBMaxs() )
			local rot = (ent:GetPos() - EyePos()):Angle().yaw - 90
			local sin = math.sin(CurTime() + ent:EntIndex()) / 3 + .5 -- EntIndex дает разницу в движении
			local center = ent:LocalToWorld(ent:OBBCenter())

			cam.Start3D2D(center + Vector(1.5, -1, math.abs(max.z / 2) + 8 + sin), Angle(0, rot, 90), 0.13)
				textPlate(text,15)
			cam.End3D2D()

			surface.SetAlphaMultiplier(1)
		end
	end

	function ENT:Draw()
		local dist = EyePos():DistToSqr(self:GetPos())
		if _G['NPC_HIDE_ON_DISTANCE'] and dist > _G['NPC_HIDE_ON_DISTANCE'] then return end
	if self:GetPos():Distance( LocalPlayer():GetPos() ) < 1500 then
		self:DrawModel()
	end
		drawInfo(self, "Хранилище", dist)
	end
end
