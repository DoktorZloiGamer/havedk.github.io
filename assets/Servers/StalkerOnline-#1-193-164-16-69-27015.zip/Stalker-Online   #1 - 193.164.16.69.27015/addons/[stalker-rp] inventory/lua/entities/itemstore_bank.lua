ENT.Type = "anim"
ENT.RenderGroup = RENDERGROUP_TRANSLUCENT

ENT.PrintName = "Тайник"
ENT.Category = "Stalker Ents"

ENT.Spawnable = true
ENT.AdminOnly = true

if SERVER then
	AddCSLuaFile()

	function ENT:Initialize()
		self:SetModel( "models/z-o-m-b-i-e/st/equipment_cache/st_equipment_box_01.mdl" )

		self:PhysicsInit( SOLID_VPHYSICS )
		self:SetMoveType( MOVETYPE_VPHYSICS )
		self:SetSolid( SOLID_VPHYSICS )
		self:SetUseType( SIMPLE_USE )

		self:GetPhysicsObject():EnableMotion( false )
	end

	function ENT:SpawnFunction( pl, trace, class )
		local ent = ents.Create( class )
		ent:SetPos( trace.HitPos + trace.HitNormal * 16 )
		ent:Spawn()

		return ent
	end

	function ENT:Use( pl )
		if not IsValid( pl ) then return end

		pl.Bank:Sync()
		pl:OpenContainer( pl.Bank:GetID(), '' )
	end

	concommand.Add( "itemstore_savebanks", function( pl )
		if not game.SinglePlayer() and IsValid( pl ) then return end

		local banks = {}

		for _, ent in ipairs( ents.FindByClass( "itemstore_bank" ) ) do
			if ent:GetNWBool("DeathLoot") then continue end
			table.insert( banks, {
				Position = ent:GetPos(),
				Angles = ent:GetAngles()
			} )
		end

		file.Write( "itemstore/banks/" .. game.GetMap() .. ".txt", util.TableToJSON( banks ) )

		print( "Banks for map " .. game.GetMap() .. " saved." )
	end )

	hook.Add( "InitPostEntity", "ItemStoreSpawnBanks", function()
		local banks = util.JSONToTable( file.Read( "itemstore/banks/" .. game.GetMap() .. ".txt", "DATA" ) or "" ) or {}

		for _, data in ipairs( banks ) do
			local bank = ents.Create( "itemstore_bank" )
			bank:SetPos( data.Position )
			bank:SetAngles( data.Angles )
			bank:Spawn()
		end
	end )
else

	-- ENT.RenderGroup = RENDERGROUP_OPAQUE

	surface.CreateFont('Inventory_Title', {font='Graffiti1CTT',size=85,weight=300,extended=true,antilialias=true})
	surface.CreateFont('Inventory_Sub', {font='Graffiti1CTT',size=40,weight=100,extended=true,antilialias=true})

	local COL_TEXT = Color(255,255,255)
	local COL_BG   = Color(0,0,0,150)
	local FONT     = "Inventory_Title"
  local stash_icon = Material('stalker/hud/bank_item.png')

	local function textPlate(text,y)
		surface.SetFont(FONT)
		local tw,th = surface.GetTextSize(text)
		local bx,by = -tw / 2 - 5, y - 35
		local bw,bh = tw + 10 + 10, th + 10 + 10

		--surface.SetDrawColor(45,45,45)
		--surface.DrawRect(bx,by, bw,bh+10)
		--surface.SetDrawColor(32,191,107)
		--surface.DrawRect(bx,by+66, bw,4)
		--surface.SetDrawColor(32, 191, 107)
		--surface.DrawOutlinedRect(bx,by, bw,bh+10,2)

		--surface.SetTextColor(COL_TEXT)
		--surface.SetTextPos(-tw / 2+3,y-30)
		--surface.DrawText(text)

		--draw.WordBox(1, -tw / 2+3,y-30,' '..text..' ','Main_Text_Stash',Color(25,25,25,150),Color(74, 191, 72),TEXT_ALIGN_LEFT)
		draw.SimpleText(' '..text..' ','Inventory_Title',-tw / 2+3-25,y-40,color_white,Color(0,0,0),1,1,1)

		surface.SetMaterial( stash_icon )
		surface.SetDrawColor( 255, 255, 255, 255 )
		surface.DrawTexturedRect( -tw / 2+5-33,y-37, 32, 32 )

		surface.SetTextColor(Color(200,200,200))
		surface.SetTextPos(-tw / 2-40,y-15)
		surface.SetFont('Inventory_Sub')
		surface.DrawText('Используется как хранилище')
	end

	local function drawInfo(ent, text, dist)
		dist = dist or EyePos():DistToSqr(ent:GetPos())

		if dist < 60000 then
			surface.SetAlphaMultiplier( math.Clamp(3 - (dist / 20000), 0, 1) )

			local _,max = ent:GetRotatedAABB(ent:OBBMins(), ent:OBBMaxs() )
			local rot = (ent:GetPos() - EyePos()):Angle().yaw - 90
			local sin = math.sin(CurTime() + ent:EntIndex()) / 3 + .5 -- EntIndex дает разницу в движении
			local center = ent:LocalToWorld(ent:OBBCenter())

			cam.Start3D2D(center + Vector(1.5, -1, math.abs(max.z / 2) + 8 + sin), Angle(0, rot, 90), 0.13)
				textPlate(text,15)
			cam.End3D2D()

			surface.SetAlphaMultiplier(1)
		end
	end

	function ENT:Draw()
		local dist = EyePos():DistToSqr(self:GetPos())
		if _G['NPC_HIDE_ON_DISTANCE'] and dist > _G['NPC_HIDE_ON_DISTANCE'] then return end
	if self:GetPos():Distance( LocalPlayer():GetPos() ) < 1500 then
		self:DrawModel()
	end
		drawInfo(self, "Тайник", dist)
	end
end
