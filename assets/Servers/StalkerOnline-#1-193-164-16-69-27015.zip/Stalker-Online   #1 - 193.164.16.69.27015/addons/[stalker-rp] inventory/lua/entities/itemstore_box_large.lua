ENT.Type = "anim"
ENT.Base = "itemstore_box"

ENT.PrintName = "Хранилище"
ENT.Category = "ItemStore"

ENT.Spawnable = true
ENT.AdminOnly = true

if SERVER then
	AddCSLuaFile()

	ENT.Model = "models/z-o-m-b-i-e/st/shkaf/st_seif_02.mdl"

	ENT.ContainerWidth = 10
	ENT.ContainerHeight = 5
	ENT.ContainerPages = 10
end
