ITEM.Name = "11,43 х 23 мм"
ITEM.Description = "Восполняет боезапас\n + 7 патрон"
ITEM.HighlightColor = itemstore.config.HighlightColours.Other
ITEM.Base = "base_entity"
ITEM.Stackable = true
ITEM.DropStack = false
ITEM.MaxStack = 10

function ITEM:SaveData( ent )
	self:SetModel( ent:GetModel() )
end

function ITEM:Use( ply )
ply:EmitSound('items/ammo_pickup.wav',65, math.random(90,110), .7)
ply:GiveAmmo(7, "stalker_deagle")

    return self:TakeOne()
end
