ITEM.Name = "Хвост Псевдособаки"
ITEM.Description = "Часть тела"
ITEM.HighlightColor = itemstore.config.HighlightColours.Other
ITEM.Base = "base_entity"
ITEM.Stackable = false
ITEM.DropStack = false
ITEM.MaxStack = 5

function ITEM:SaveData( ent )
	self:SetModel( ent:GetModel() )
end
