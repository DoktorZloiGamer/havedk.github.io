ITEM.Name = "Колбаса"
ITEM.Description = "Восполняет голод\n + 25-35% к сытости"
ITEM.HighlightColor = itemstore.config.HighlightColours.Other
ITEM.Base = "base_entity"
ITEM.Stackable = true
ITEM.DropStack = false
ITEM.MaxStack = 10

function ITEM:SaveData( ent )
	self:SetModel( ent:GetModel() )
end

function ITEM:Use(ply)
DarkRP.StalNotify(ply,'Вы использовали: Колбаса')
	DarkRP.GiveEffect(ply, 'Food', 3)
		ply:SetNWInt( "Energy", math.Clamp( ( ply:GetNWInt("Energy") or 100 ) + math.floor(math.random(25, 35)), 0, 100 ) )
		ply:EmitSound("stalker/items/eat/eat1.mp3", 65, math.random(90,120), 0.9)
		return self:TakeOne()
end
