ITEM.Name = "Инструменты"
ITEM.Description = "Ремонтный набор"
ITEM.HighlightColor = itemstore.config.HighlightColours.Other
ITEM.Base = "base_entity"
ITEM.Stackable = true
ITEM.DropStack = false
ITEM.MaxStack = 5

function ITEM:SaveData( ent )
	self:SetModel( ent:GetModel() )
end
