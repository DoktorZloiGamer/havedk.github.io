ITEM.Name = "Голова Тушканчика"
ITEM.Description = "Часть тела"
ITEM.HighlightColor = itemstore.config.HighlightColours.Other
ITEM.Base = "base_entity"
ITEM.Stackable = true
ITEM.DropStack = false
ITEM.MaxStack = 10

function ITEM:SaveData( ent )
	self:SetModel( ent:GetModel() )
end
