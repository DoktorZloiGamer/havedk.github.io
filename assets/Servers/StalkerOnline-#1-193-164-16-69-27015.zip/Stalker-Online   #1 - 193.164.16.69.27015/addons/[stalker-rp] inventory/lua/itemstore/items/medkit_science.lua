ITEM.Name = "Аптечка Научная"
ITEM.Description = "Восполняет здоровье\n + 100 к здоровью - 50 мЗв"
ITEM.HighlightColor = itemstore.config.HighlightColours.Other
ITEM.Base = "base_entity"
ITEM.Stackable = true
ITEM.DropStack = false
ITEM.MaxStack = 5

function ITEM:SaveData( ent )
	self:SetModel( ent:GetModel() )
end

function ITEM:Use( ply )
self.x = 100
		if ply:GetNWInt("Heal") > CurTime() && math.Round(ply:GetNWInt("Heal") - CurTime()) > 0 then DarkRP.notify(ply, 1, 4, 'Вы недавно получили урон. Осталось ждать ' .. math.Round(ply:GetNWInt("Heal") - CurTime()) .. ' сек.') return end

if ply:Health() >= 100 then return end
local Rad = ply:GetNWFloat("Radiation")

if (ply:IsPlayer()) then
	-- hp
	if ply:Health() + self.x < 100 then
		ply:SetHealth(ply:Health() + self.x)
	else
		ply:SetHealth(100)
	end
	-- rad
	if Rad < 50 then
	 ply:SetNWFloat("Radiation", 0)
 elseif Rad > 50 then
		ply:SetNWFloat("Radiation", math.Clamp((ply:GetNWFloat("Radiation")) - 50, 0, 400))
	end

	ply:EmitSound('stalker/items/medkit.mp3', 65,100,0.5)

	DarkRP.StalNotify(ply,'Вы использовали: Аптечка Научная')
	DarkRP.GiveEffect(ply, 'Heal', 3)
	DarkRP.GiveEffect(ply, 'Rad', 3)
	ply:UseShot()
	if !ply:GetNetVar("Bleeding", false) then return self:TakeOne() end;
	local value = math.random(2)
	ply:SetNetVar("Bleeding", ply:GetNetVar("Bleeding") - value)
	if ply:GetNetVar("Bleeding",1) <= 0 then ply:SetNetVar("Bleeding", false) end;
	return self:TakeOne()
end
end
