local PANEL = {}
local render = render
local blur = Material( "pp/blurscreen" )
local surface = surface
local function formatNumber(n)
    if !n then return "" end
    if n >= 1e14 then return tostring(n) end
    n = tostring(n)
    local sep = sep or "."
    local dp = string.find(n, "%.") or #n + 1

    for i = dp - 4, 1, -3 do
        n = n:sub(1, i) .. sep .. n:sub(i + 1)
    end

    return n
end
surface.CreateFont('title', {font = 'Roboto', size = 13, weight = 0, extended = true, antialias = true})
local function matafakablur( panel, layers, density, alpha )

	local x, y = panel:LocalToScreen(0, 0)

	surface.SetDrawColor( 255, 255, 255, alpha )
	surface.SetMaterial( blur )

	for i = 1, 3 do
	blur:SetFloat( "$blur", ( i / layers ) * density )
	blur:Recompute()

	render.UpdateScreenEffectTexture()
	surface.DrawTexturedRect( -x, -y, ScrW(), ScrH() )
	end

end

function PANEL:Init()
	if LocalPlayer():GetLocalVar("closeReceveirs") then return end;
	self:SetSkin( "itemstore" )

	self.Container = vgui.Create( "ItemStoreContainer", self )
	self.Container:SizeToContents()

	self.icons = {}

	local setTitle = self.SetTitle
	local newTitle = vgui.Create("DLabel", self)

	self.SetTitle = function(...)
		setTitle(...)
		
		if self.Container ~= NULL then
			self.Container:SizeToContents()
		end
		newTitle:SetText(self.lblTitle:GetText())
		self.lblTitle:SetVisible(false)
		newTitle:SizeToContents()
		-- self.lblTitle:DockMargin(0,10,0,0)
	end
	
	newTitle:SetText('')
	newTitle:SetFont('title')
	newTitle:SetPos(12,18)
end

local back_inv = Material('stalker/hud/ui_inv_back.png')

function PANEL:PerformLayout()
	local color = team.GetColor(LocalPlayer():Team())
	local teamcolor = Color(color.r, color.g, color.b, 25)
	if !IsValid(self) then return end;
	-- print(self.Container:GetContainerID(), LocalPlayer().Inventory)
	if IsValid(self.Container) then
        self:SetSize(self:GetTitle() ~= '' and self.Container:GetWide() * .935 or self.Container:GetWide(), self.Container:GetTall() + 64) -- 164
        self.Container:SetPos(2, 35)
	end
	self:ShowCloseButton(true)
	self:SetDraggable(false)
	
	self.Paint = function(self,w,h)
		--matafakablur( self, 3, 3, 125 )
    surface.SetDrawColor(255,255,255)
		surface.SetMaterial(back_inv)
		surface.DrawTexturedRect(0,0,w,h)

    	--draw.RoundedBox(0,2,2,w-4,h-4,Color(75,75,75,95))
	--	draw.RoundedBox(0,0,0,w,h,Color(0,0,0,230))
		--draw.RoundedBox(3,self:GetWide()-37,1,35,21,Color(5,5,5,225))
		--draw.RoundedBox(3,1,1,w,21,Color(5,5,5,200))
    --draw.WordBox(0,self:GetWide()/2,25,' '..itemstore.Translate( "inventory" )..' ','Item_TitleMain',Color(5,5,5,200),color_white,Color(0,0,0,0),1,1,1)


		--[[draw.RoundedBox(1,98,24,323,94,Color(0,0,0,225))
		draw.RoundedBox(1,97,23,325,96,teamcolor)
		draw.RoundedBox(1,100,26,90,90,Color(15,15,15,235))
		surface.SetDrawColor(255,255,255,200)
		surface.SetMaterial(stalker_logo)
		surface.DrawTexturedRect(100,26,90,90)
		draw.SimpleText(LocalPlayer():getDarkRPVar('rpname'),'Item_Title',200,22,color_white,0,0)
		draw.SimpleText(LocalPlayer():getJobTable().category,'Item_Title',200,53,team.GetColor(LocalPlayer():Team()),0,0)
		draw.SimpleText(formatNumber(LocalPlayer():getDarkRPVar("money"))..' РУБ','Item_Small',200,85,color_white,0,0)--]]
	end

	self.BaseClass.PerformLayout( self )

	if self:GetTitle() ~= '' then
		return
	end;
	
	-- end

	--[[local button = vgui.Create('DButton', self.Container )
	button:SetPos(self.Container:GetWide()-67,0)
	button:SetSize(60,20)
	button:SetText('')
	button.Paint = function(self,w,h)
		draw.RoundedBox(0,0,0,w,h,Color(0,0,0,125))
		draw.SimpleText('Закрыть','DermaDefault',30,10,color_white,1,1)
		end
	button.DoClick = function()
		self:Remove()
	end

	local Avatar = vgui.Create( "AvatarImage", self )
	Avatar:SetSize( 90, 90 )
	Avatar:SetPos( 100,41 )
	Avatar:SetPlayer( LocalPlayer(), 90 )--]]

	--[[local Panel = vgui.Create( "DFrame", self )
	Panel:SetPos( 200, 200 )
	Panel:SetSize( 500, 500 )
	Panel:SetTitle( "Avatar Test" )
	Panel:MakePopup()
	Panel.Paint = function(self,w,h)
	end

	local Avatar = vgui.Create( "AvatarImage", Panel )
	Avatar:SetSize( 90, 90 )
	Avatar:SetPos( 100,41 )
	Avatar:SetPlayer( LocalPlayer(), 90 )--]]

	self.BaseClass.PerformLayout( self )
end

function PANEL:Think()
	if !IsValid(self.Container) then self:Remove() return end;
	if LocalPlayer():GetLocalVar("closeReceveirs") && self.Container:GetContainerID() == LocalPlayer():GetLocalVar("closeReceveirs") then self:Remove() return end;
end

function PANEL:Refresh()
	if !IsValid(self.Container) then return end
	self.Container:Refresh()
end

function PANEL:SetContainerID( id )
	if !IsValid(self.Container) then return end
	self.Container:SetContainerID( id )
end

function PANEL:GetContainerID()
	if !IsValid(self.Container) then return end
	return self.Container:GetContainerID()
end


vgui.Register( "ItemStoreContainerWindow", PANEL, "DFrame" )
