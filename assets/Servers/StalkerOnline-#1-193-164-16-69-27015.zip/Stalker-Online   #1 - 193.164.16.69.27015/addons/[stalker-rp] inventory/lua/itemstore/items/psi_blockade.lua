ITEM.Name = "Пси-Блокада"
ITEM.Description = "Защита от Пси-Излучения\n Действ. 120 сек."
ITEM.HighlightColor = itemstore.config.HighlightColours.Other
ITEM.Base = "base_entity"
ITEM.Stackable = true
ITEM.DropStack = false
ITEM.MaxStack = 10

function ITEM:SaveData( ent )
	self:SetModel( ent:GetModel() )
end

function ITEM:Use( ply )

	if ply:GetNWBool("AntiBrain") then return end
	if (ply:IsPlayer()) then
  ply:SetNWBool("AntiBrain", true)
		DarkRP.StalNotify(ply,'Вы использовали: Пси-Блокада')
		DarkRP.GiveEffect(ply, 'Anti-Psy', 120)

		timer.Simple(120, function()
				ply:SetNWBool("AntiBrain", false)
		end)

		ply:EmitSound('stalker/items/pills.mp3', 65,100,0.5)
	end

	return self:TakeOne()
end
