ITEM.Name = "12 x 70 мм"
ITEM.Description = "Восполняет боезапас\n + 10 патрон"
ITEM.HighlightColor = itemstore.config.HighlightColours.Other
ITEM.Base = "base_entity"
ITEM.Stackable = true
ITEM.DropStack = false
ITEM.MaxStack = 10

function ITEM:SaveData( ent )
	self:SetModel( ent:GetModel() )
end

function ITEM:Use( ply )
ply:EmitSound('items/ammo_pickup.wav',65, math.random(90,110), .7)
ply:GiveAmmo(10, "stalker_shotgun")
    return self:TakeOne()
end
