ITEM.Name = "Пси-Шлем"
ITEM.Description = "Пси-Шлем"
ITEM.HighlightColor = itemstore.config.HighlightColours.Other
ITEM.Base = "base_entity"
ITEM.Stackable = true
ITEM.DropStack = false
ITEM.MaxStack = 1

function ITEM:SaveData( ent )
	self.energy = (ent.energy || 100)
	self:SetModel( "models/psihelem.mdl" )
end

function ITEM:Use( p )
	p:SetNetVar("AntiBrainPerc", (self.energy||100))
	p:SetNetVar("AntiBrain", true)
    DarkRP.notify(p,2,6, "Вы надели Пси-Шлем!")
    p:EmitSound('npc/combine_soldier/gear2.wav', 60,100,0.7)
	return self:TakeOne()
end


function ITEM:CreateEntity( pos )
	local ent = ents.Create( self.Class )
	ent:SetPos( pos )
	ent:Spawn()
	ent.energy = self.energy

	return ent
end