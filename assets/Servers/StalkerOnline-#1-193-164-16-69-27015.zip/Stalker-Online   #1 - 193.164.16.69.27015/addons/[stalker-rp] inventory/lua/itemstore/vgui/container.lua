local PANEL = {}

function PANEL:Init()
    self.Pages = {}
    self.Slots = {}
    table.insert(itemstore.containers.Panels, self)
end

function PANEL:SetContainerID(id)
    self.ContainerID = id
    self:Refresh()
end

function PANEL:GetContainerID()
    return self.ContainerID
end

function PANEL:Refresh()
    local id = self:GetContainerID()
    local con = itemstore.containers.Get(id)
    -- PrintTable(con)
    if con then
        for i = 1, con:GetSize() do
            local page_id = con:GetPageFromSlot(i)
            local page = self.Pages[page_id]

            if not page then
                page = vgui.Create("DIconLayout")
                page:SetSpaceX(1)
                page:SetSpaceY(1)
                self.Pages[page_id] = page
                self:AddSheet(itemstore.Translate("page", page_id), page)
            end

            local slot = self.Slots[i]

            -- local nodrop = 3

            -- if LocalPlayer():GetNetVar("IGSData", {})["subs_3mo"] or LocalPlayer():GetNetVar("IGSData", {})["subs_1year"] then
            --     nodrop = nodrop + 3
            -- end
            
            if not slot then
                slot = page:Add("ItemStoreSlot")
                slot:SetSize(65, 65)
                slot:SetContainerID(self:GetContainerID())
                slot:SetSlot(i)


                self.Slots[i] = slot
            end
            -- print(i, con:GetItem(i))
            slot:SetItem(con:GetItem(i))
            slot:Refresh()
        end
    end

    self:SizeToContents()
end

function PANEL:SizeToContents()
    local id = self:GetContainerID()
    local con = itemstore.containers.Get(id)
    
    local name = self:GetParent()
    if name ~= NULL then name = name.lblTitle:GetText() end;
    local InventoryID = self.ContainerID == LocalPlayer().InventoryID
    -- print(name)
    if con then
        if name && name ~= 'Window' then
            self.name = self.name || name
        end
        
        local w = con:GetWidth() * 81 - (self.name == 'Хабар' && 114 || self.name == 'Хранилище' && 85 || InventoryID && 90 || 102)
        local h = con:GetHeight() * 81-(InventoryID && 20 || 25)
        self:SetSize(w, h)
        --self.Paint = function(self,w,h)
        --draw.RoundedBox(3,0,20,w,h,Color(15,15,15,225))
        --end
    end
end

vgui.Register("ItemStoreContainer", PANEL, "DPropertySheet")