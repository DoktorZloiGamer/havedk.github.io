local math, net = math, net
local meta = debug.getregistry().Player
local surface, draw = surface, draw

function meta:MoveItem( from_con_id, from_slot, to_con_id, to_slot )
	net.Start( "ItemStoreMove" )
		net.WriteUInt( from_con_id, 32 )
		net.WriteUInt( from_slot, 32 )
		net.WriteUInt( to_con_id, 32 )
		net.WriteUInt( to_slot, 32 )
	net.SendToServer()
end

function meta:UseItem( con_id, slot, ... )
	net.Start( "ItemStoreUse" )
		net.WriteUInt( con_id, 32 )
		net.WriteUInt( slot, 32 )
		net.WriteTable( { ... } )
	net.SendToServer()
end

function meta:UseItemWith( from_con_id, from_slot, to_con_id, to_slot )
	net.Start( "ItemStoreUseWith" )
		net.WriteUInt( from_con_id, 32 )
		net.WriteUInt( from_slot, 32 )
		net.WriteUInt( to_con_id, 32 )
		net.WriteUInt( to_slot, 32 )
	net.SendToServer()
end

function meta:DropItem( con_id, slot )
	net.Start( "ItemStoreDrop" )
		net.WriteUInt( con_id, 32 )
		net.WriteUInt( slot, 32 )
	net.SendToServer()
end

function meta:DestroyItem( con_id, slot )
	net.Start( "ItemStoreDestroy" )
		net.WriteUInt( con_id, 32 )
		net.WriteUInt( slot, 32 )
	net.SendToServer()
end

function meta:MergeItem( from_con_id, from_slot, to_con_id, to_slot )
	net.Start( "ItemStoreMerge" )
		net.WriteUInt( from_con_id, 32 )
		net.WriteUInt( from_slot, 32 )
		net.WriteUInt( to_con_id, 32 )
		net.WriteUInt( to_slot, 32 )
	net.SendToServer()
end

function meta:SplitItem( con_id, slot, amount )
	net.Start( "ItemStoreSplit" )
		net.WriteUInt( con_id, 32 )
		net.WriteUInt( slot, 32 )
		net.WriteUInt( amount, 16 )
	net.SendToServer()
end

hook.Add( "InitPostEntity", "ItemStoreRequestInventory", function()
	net.Start( "ItemStoreSyncInventory" ) net.SendToServer()
end )

local ContextInventory

net.Receive( "ItemStoreSyncInventory", function()
	LocalPlayer().InventoryID = net.ReadUInt( 32 )

	if not itemstore.config.ContextInventory then return end

	local inv = vgui.Create( "ItemStoreContainerWindow", g_ContextMenu )
	inv:SetTitle( itemstore.Translate( "inventory" ) )
	inv:SetContainerID( LocalPlayer().InventoryID )
	inv:ShowCloseButton( false )
	inv:SetDraggable( false )
	inv:InvalidateLayout( true )

	local side = itemstore.config.ContextInventoryPosition
	if side == "bottom" then
		inv:SetPos( ScrW() *.5 - inv:GetWide() *.5, ScrH() - inv:GetTall() )
	elseif side == "top" then
		inv:SetPos(ScrW() *.5 - inv:GetWide() *.5, ScrH() - 300 )
	elseif side == "left" then
		inv:SetPos( 0, ScrH() *.5 - inv:GetTall() *.5 )
	elseif side == "right" then
		inv:SetPos( ScrW() - inv:GetWide(), ScrH() *.5 - inv:GetTall() *.5 )
	end

	ContextInventory = inv
end )

hook.Add( "Tick", "ItemStoreHideContextInventory", function()
	if not IsValid( LocalPlayer() ) then return end
	if not IsValid( ContextInventory ) then return end

	ContextInventory:SetVisible( LocalPlayer():CanUseInventory() )
end )
local fo = 0
local function SetupFastSlots(self)
	local z = 0
	self.icons = self.icons || {}
	-- for z = 0, 3 do
		-- if z > 0 then continue end;
	if self.icons[z] then return end;
	self.icons[z] = self:Add('EditablePanel')
	local id = self.icons[z]
	id.Paint = function(s,w,h)
		surface.SetDrawColor(70,70,68,25)
		surface.DrawOutlinedRect(0,0,w,h,1)
    surface.SetDrawColor(35,35,32,55)
    surface.DrawRect(0,0,w,h)
	end

	id.mdl = id:Add("ModelImage")
	id.mdl:SetAlpha(0)

	id.title = id:Add('EditablePanel')

	id.title:Receiver("ItemStore", function(s, pnl, drop)
		pnl = pnl[1]
		if drop then
			if !GAMEMODE.Config.FastSlot[pnl:GetItem().Class] then return end;
			id.mdl:SetAlpha(255)
			id.mdl:SetModel(pnl:GetModel())

			net.Start("fs")
			net.WriteString(pnl:GetItem().Class)
			net.SendToServer()
		end
	end)
	id.title.OnMousePressed = function(s,key)
		if key ~= MOUSE_RIGHT then return end;
		local menu = DermaMenu(s)
		menu:AddOption('Очистить', function()
			self.icons[z].mdl:SetAlpha(0)
			self.icons[z].mdl:SetModel ""
			net.Start("fs")
			net.WriteString("")
			net.SendToServer()
		end):SetIcon('icon16/folder_delete.png')
		menu:Open()
	end
	-- end
	local F1ICON = LocalPlayer():GetNetVar("F1", "")
	-- print(F1ICON)
	-- for z = 0, 3 do
	-- 	if z > 0 then return end;
	self.icons[z].mdl:Dock(FILL)
	self.icons[z]:SetPos(15+z*79, 25)
	self.icons[z]:SetSize(78,78)

	self.icons[z].title:Dock(FILL)
	local title = 'F' .. z + 1
	self.icons[z].title.Paint = function(s,w,h)
		draw.SimpleText(title, 'ItemStoreF1Slot', 4, h-8, color_white, 0x0, 0x1)
	end

	if F1ICON ~= "" then
		self.icons[z].mdl:SetAlpha(255)
		self.icons[z].mdl:SetModel(GAMEMODE.Config.FastSlot[F1ICON])
	end
end
local green, red = Color(75, 235, 75), Color(235, 75, 75)
local function SetupArts(self, ContainerID)
	local pl = LocalPlayer()
	local oW, oH = self:GetWide(), self:GetTall()
	local slotSize = 78

	-- local rightPanel = self:Add("EditablePanel")
	-- rightPanel

	local infoPanel = self:Add("DScrollPanel")
	infoPanel:Dock(RIGHT)
	infoPanel:SetWide(self:GetWide()*.35)
	infoPanel:DockMargin(0,25,-10,25)
	infoPanel.ArtData = {
		['Гашение урона'] = 0;
		['Защита от разрыва'] = 0;
		['Ожог'] = 0;
		['Химический ожог'] = 0;
		['Электрошок'] = 0;
		['Радиация'] = 0;
		['Регенерация'] = 0;
		['Насыщение'] = 0;
	}
	infoPanel.Update = function(s)
		s:Clear()
		for name, value in SortedPairs(s.ArtData) do
			local dlable = s:Add("DLabel")
			dlable:Dock(TOP)
			dlable:SetFont('ItemStoreF1Slot')
			dlable:SetText(name .. (value > 0 && ' +' || ' ') .. value .. (name == 'Радиация' && 'мкЗв/сек' || '%'))
			dlable:SetTextColor(value == 0 && color_white || value > 0 && green || red)
		end
	end
	infoPanel:Update()
	infoPanel.AddArtInfo = function(s, name, value)
		s.ArtData[name] = s.ArtData[name] || 0
		s.ArtData[name] = s.ArtData[name] + value
		s:Update()
	end;

	infoPanel.RemoveArtInfo = function(s, name, value)
		if !s.ArtData[name] then return end;
		if math.Round(math.abs(s.ArtData[name]), 3) == math.Round(math.abs(value), 3) then
			s.ArtData[name] = 0
		else
			s.ArtData[name] = s.ArtData[name] - value
		end
		-- s.ArtData[name] = s.ArtData[name] ~= 0 && s.ArtData[name] || nil
		s:Update()
	end;

	for z = 1, 4 do
		local artPanel = self:Add("EditablePanel")
		artPanel:SetPos(15 + (z-1)*(slotSize+10), oH*.51 )
		artPanel:SetSize(slotSize, slotSize)
		artPanel.Paint = function(s,w,h)
			surface.SetDrawColor(175,100,68,25)
			surface.DrawOutlinedRect(0,0,w,h,1)

			surface.SetDrawColor(35,35,32,55)
			surface.DrawRect(0,0,w,h)
		end
		artPanel.mdl = artPanel:Add("ModelImage")
		artPanel.mdl:SetAlpha(0)
		local artData = pl:GetNetVar("ArtSlot" .. z)
		if artData then
			artPanel.mdl:SetAlpha(255)
			artPanel.mdl:SetModel(artData.model)
			local getinfo = GAMEMODE.Config.Artifacts[artData.class]
			for name, value in pairs(getinfo['Эффекты']) do
				infoPanel:AddArtInfo(name, value)
			end
		end
		artPanel.artData = artData
		artPanel.mdl.artData = artData
		artPanel.mdl:Receiver("ItemStore", function(s,p, drop)
			if !drop then return end;
			if s.artData then return end;
			p = p[1]
			local item = p:GetItem()
			if !item then return end;
			local class = item.Class
			local getinfo = GAMEMODE.Config.Artifacts[class]
			if !class || !getinfo then return end;
			net.Start("itemstore art")
			net.WriteBit(0)
			net.WriteUInt(item.Slot, 13)
			net.WriteUInt(z-1, 2)
			net.SendToServer()
			for name, value in pairs(getinfo['Эффекты']) do
				infoPanel:AddArtInfo(name, value)
			end
			s.artData = {
				class = class;
				model = item.Data.Model
			}
			s:SetAlpha(255)
			s:SetModel(item.Data.Model)
			-- PrintTable(p:GetItem())
		end)
		local Tooltip
		for _,artPNL in ipairs({artPanel; artPanel.mdl}) do
		function artPNL:GetItem()
			if !self.artData then return end;
			return itemstore.items.Get(self.artData.class)
		end
		function artPNL:CreateTooltip()
			if IsValid( Tooltip ) then
				Tooltip:SetVisible( true )
				Tooltip:Refresh()
				-- print('ppsh')
				self:UpdateTooltip()
				return
			end
			Tooltip = vgui.Create( "ItemStoreTooltip" )
			Tooltip.item = self:GetItem()
			self:UpdateTooltip()
		end

		function artPNL:UpdateTooltip()
			if not IsValid( Tooltip ) then return end
		end

		function artPNL:HideTooltip()
			if IsValid( Tooltip ) then Tooltip:SetVisible( false ) end
		end
		function artPNL:OnRemove()
			if IsValid(Tooltip) then
				Tooltip:Remove()
			end
		end
		function artPNL:OnCursorEntered()
			if not self:GetItem() then return end

			self:CreateTooltip()
			self:UpdateTooltip()
		end

		function artPNL:OnCursorMoved()
			if not IsValid( Tooltip ) then return end

			local x, y = gui.MousePos()
			Tooltip:SetPos( x, y - Tooltip:GetTall() )
		end

		function artPNL:LayoutEntity()
		end

		function artPNL:OnCursorExited()
			self:HideTooltip()
		end
		end
		artPanel.mdl.OnMousePressed = function(s,key)
			if key ~= MOUSE_RIGHT then return end;
			if s:GetAlpha() == 0 then return end;
			local menu = DermaMenu(s)
			menu:AddOption('Снять со слота', function()
				net.Start("itemstore art")
				net.WriteBit(1)
				net.WriteUInt(z-1, 2)
				net.SendToServer()
				s:SetAlpha(0)
				local getinfo = GAMEMODE.Config.Artifacts[s.artData.class]
				for name, value in pairs(getinfo['Эффекты']) do
					infoPanel:RemoveArtInfo(name, value)
				end

				s.artData = nil
				s:GetParent().artData = nil
			end):SetIcon('icon16/folder_go.png')
			menu:Open()
		end
	end
end
local MatMain = Material 'stalker/hud/ui_inv_back.png'
net.Receive( "ItemStoreOpen", function()
	local id = net.ReadUInt( 32 )
	local name = net.ReadString()
	local hideinv = net.ReadBit() == 1
	if fo > CurTime() then return end;
	local con = itemstore.containers.Get( id )
	if name == 'Тайник' then con.Pages = LocalPlayer():GetNWInt("ConPagesNew") end
	if not con then return end
	local panel = vgui.Create( "ItemStoreContainerWindow" )

	panel:SetContainerID( id )
	panel:SetTitle( name )
	-- panel:SetPos(ScrW() * .25 - panel:GetWide(),0)
	panel:Center()

	panel:MakePopup()
	local Think = panel.Think
	panel.created = CurTime() +.5
	panel.Think = function(s,...)
		if input.IsKeyDown(KEY_I) && (s.created || 0) <= CurTime() then panel:Remove() end;
		Think(s,...)
	end
	-- print(name)
	local playerPanel = vgui.Create('EditablePanel')
	playerPanel:SetSize(ScrW() * .3, ScrH() * .2)
	playerPanel:SetPos(ScrW()*.35,ScrH()*.79)
	playerPanel.Paint = function(s,w,h)
		surface.SetDrawColor(255,255,255)
		surface.SetMaterial(MatMain)
		surface.DrawTexturedRect(0,0,w,h)
	end
	SetupFastSlots(playerPanel)
	SetupArts(playerPanel, id)
	if name == 'блять' then panel:Remove() return end;
	local OnRemove = panel.OnRemove
	panel.OnRemove = function(s)
		fo = CurTime() + .5
		if IsValid(playerPanel) then
			playerPanel:Remove()
		end
		-- RunConsoleCommand('inv_close')
	end

	if not hideinv then
		local x, y = panel:GetPos()
		panel:MoveTo(x, ScrH()*.1, .5)
		local inv = vgui.Create( "ItemStoreContainerWindow" )
		inv:SetContainerID( LocalPlayer().InventoryID )
		inv:SetTitle( itemstore.Translate( "inventory" ) )
		inv:ShowCloseButton( false )
		inv:MakePopup()
		inv:InvalidateLayout( true )
		if IsValid(playerPanel) then
				playerPanel:Remove()
			end
		panel.Think = Think
		panel.OnRemove = function(s)
			-- OnRemove(s)
		end
		local think = inv.Think
		function inv:Think()
			think( self )


			if !IsValid(panel) then return end;
			-- if input.IsKeyDown(KEY_I) then print(panel)  end;
			local x, y = panel:GetPos()
			inv:SetPos( panel:GetPos() + ( panel:GetWide() *.5 - inv:GetWide() *.5 ), y + panel:GetTall() + 10 )
		end

		function panel:OnClose()
			if !tobool(inv) then return end;
			if IsValid(inv) then
				inv:Close()
			end
		end
	end
end )
