ITEM.Name = "Энергетик"
ITEM.Description = "Восполняет выносливость\n Действ. 180 сек."
ITEM.HighlightColor = itemstore.config.HighlightColours.Other
ITEM.Base = "base_entity"
ITEM.Stackable = true
ITEM.DropStack = false
ITEM.MaxStack = 10

function ITEM:SaveData( ent )
	self:SetModel( ent:GetModel() )
end

function ITEM:Use(ply)

		  if ply:GetNWBool('EnergyDrink') then
				DarkRP.notify(ply,1,4,'Энерегетический напиток уже действует!')
				 return
			  end

	    ply:SetNWBool("EnergyDrink", true)
			ply:SetNWInt( "Stamina", math.Clamp( ( ply:GetNWInt("Stamina") or 100 ) + 100, 0, 100 ) )
			ply:EmitSound("stalker/items/eat/softdrink.ogg", 65, math.random(90,120), 0.9)
			DarkRP.StalNotify(ply,'Вы использовали: Энергетик')
			DarkRP.GiveEffect(ply, 'Gas', 120)
			timer.Simple(120, function()
				ply:SetNWBool("EnergyDrink", false)
			end)
return		self:TakeOne()

end
