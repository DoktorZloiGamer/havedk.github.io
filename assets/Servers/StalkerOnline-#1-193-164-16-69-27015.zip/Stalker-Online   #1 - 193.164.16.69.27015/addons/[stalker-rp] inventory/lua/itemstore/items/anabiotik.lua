ITEM.Name = "Анабиотик"
ITEM.Description = "Защита от выброса\n Действ. 300 сек."
ITEM.HighlightColor = itemstore.config.HighlightColours.Other
ITEM.Base = "base_entity"
ITEM.Stackable = true
ITEM.DropStack = false
ITEM.MaxStack = 10

function ITEM:SaveData( ent )
	self:SetModel( ent:GetModel() )
end

function ITEM:Use( ply )

	if ply:GetNWInt("AntiEmission") > CurTime() then return end

	DarkRP.StalNotify(ply,'Вы использовали: Анабиотик')
	DarkRP.GiveEffect(ply, 'Anti-Psy', 300)

  	ply:SetNWInt("AntiEmission", CurTime() + 300)
	-- self.Entity:Remove()
	ply:EmitSound('stalker/items/pills.mp3', 65,100,0.5)

	return self:TakeOne()
end
