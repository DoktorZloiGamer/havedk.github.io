ITEM.Name = "Аптечка Маленькая"
ITEM.Description = "Восполняет здоровье\n + 50 к здоровью"
ITEM.HighlightColor = itemstore.config.HighlightColours.Other
ITEM.Base = "base_entity"
ITEM.Stackable = true
ITEM.DropStack = false
ITEM.MaxStack = 10

function ITEM:SaveData( ent )
	self:SetModel( ent:GetModel() )
end

function ITEM:Use( ply )
self.x = 50
if ply:GetNWInt("Heal") > CurTime() && math.Round(ply:GetNWInt("Heal") - CurTime()) > 0 then DarkRP.notify(ply, 1, 4, 'Вы недавно получили урон. Осталось ждать ' .. math.Round(ply:GetNWInt("Heal") - CurTime()) .. ' сек.') return end
if ply:Health() >= 100 then return end
if (ply:IsPlayer()) then
	if ply:Health() + self.x < 100 then
		ply:SetHealth(ply:Health() + self.x)
	else
		ply:SetHealth(100)
	end
	--self.Entity:Remove()
	ply:EmitSound('stalker/items/medkit.mp3', 65,100,0.5)
	DarkRP.StalNotify(ply,'Вы использовали: Аптечка Маленькая')
	DarkRP.GiveEffect(ply, 'Heal', 3)
	--self:Remove()
	ply:UseShot()
	return self:TakeOne()
end
end
