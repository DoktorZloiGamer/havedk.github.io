ITEM.Name = "Консервы"
ITEM.Description = "Восполняет голод\n + 35-45% к сытости"
ITEM.HighlightColor = itemstore.config.HighlightColours.Other
ITEM.Base = "base_entity"
ITEM.Stackable = true
ITEM.DropStack = false
ITEM.MaxStack = 10

function ITEM:SaveData( ent )
	self:SetModel( ent:GetModel() )
end

function ITEM:Use(ply)
	DarkRP.StalNotify(ply,'Вы использовали: Консервы')
	DarkRP.GiveEffect(ply, 'Food', 3)
		ply:SetNWInt( "Energy", math.Clamp( ( ply:GetNWInt("Energy") or 100 ) + math.floor(math.random(35, 45)), 0, 100 ) )
		ply:EmitSound("stalker/items/eat/eat2.mp3", 65, math.random(90,120), 0.9)
return	self:TakeOne()
end
