ITEM.Name = "Граната ВОГ-25"
ITEM.Description = "Выдает 1 заряд"
ITEM.HighlightColor = itemstore.config.HighlightColours.Other
ITEM.Base = "base_entity"
ITEM.Stackable = true
ITEM.DropStack = false
ITEM.MaxStack = 5

function ITEM:SaveData( ent )
	self:SetModel( ent:GetModel() )
end

function ITEM:Use( ply )
ply:GiveAmmo(1, "stalker_bull")
	ply:EmitSound('items/ammo_pickup.wav',65, math.random(90,110), .7)
	return self:TakeOne()
end
