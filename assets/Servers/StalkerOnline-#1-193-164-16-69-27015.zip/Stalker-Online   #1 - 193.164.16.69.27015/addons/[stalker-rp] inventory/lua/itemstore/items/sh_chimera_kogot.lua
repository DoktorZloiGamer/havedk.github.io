ITEM.Name = "Коготь Химеры"
ITEM.Description = "Часть тела"
ITEM.HighlightColor = itemstore.config.HighlightColours.Other
ITEM.Base = "base_entity"
ITEM.Stackable = true
ITEM.DropStack = false
ITEM.MaxStack = 3

function ITEM:SaveData( ent )
	self:SetModel( ent:GetModel() )
end
