ITEM.Name = "Бинт"
ITEM.Description = "Восполняет здоровье\n + 15 к здоровью"
ITEM.HighlightColor = itemstore.config.HighlightColours.Other
ITEM.Base = "base_entity"
ITEM.Stackable = true
ITEM.DropStack = false
ITEM.MaxStack = 15

function ITEM:SaveData( ent )
	self:SetModel( ent:GetModel() )
end

function ITEM:Use( ply )
self.x = 10
if ply:GetNWInt("Heal") > CurTime() && math.Round(ply:GetNWInt("Heal") - CurTime()) > 0 then DarkRP.notify(ply, 1, 4, 'Вы недавно получили урон. Осталось ждать ' .. math.Round(ply:GetNWInt("Heal") - CurTime()) .. ' сек.') return end
if ply:Health() >= 100 then return end
if (ply:IsPlayer()) then
	if ply:Health() + self.x < 100 then
		ply:SetHealth(ply:Health() + self.x)
	else
		ply:SetHealth(100)
	end
	--self.Entity:Remove()
	ply:EmitSound('stalker/items/bandage.ogg', 65,100,0.5)
	DarkRP.StalNotify(ply,'Вы использовали: Бинт')
	DarkRP.GiveEffect(ply, 'Heal', 1)
	--self:Remove()
	ply:UseShot()
	if !ply:GetNetVar("Bleeding", false) then return self:TakeOne() end;
	local value = math.random(2)
	ply:SetNetVar("Bleeding", ply:GetNetVar("Bleeding") - value)
	if ply:GetNetVar("Bleeding",1) <= 0 then ply:SetNetVar("Bleeding", false) end;
	return self:TakeOne()
end
end
