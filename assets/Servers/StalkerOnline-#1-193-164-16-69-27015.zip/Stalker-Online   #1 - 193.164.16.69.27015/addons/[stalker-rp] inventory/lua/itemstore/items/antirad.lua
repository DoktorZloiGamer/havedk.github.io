ITEM.Name = "Анти-Рад"
ITEM.Description = "Выводит радиацию\n - 100 мЗв"
ITEM.HighlightColor = itemstore.config.HighlightColours.Other
ITEM.Base = "base_entity"
ITEM.Stackable = true
ITEM.DropStack = false
ITEM.MaxStack = 10

function ITEM:SaveData( ent )
	self:SetModel( ent:GetModel() )
end

function ITEM:Use( ply )
self.Radremove = 100

local Rad = ply:GetNWFloat("Radiation")
if Rad < 1 then return end
if (ply:IsPlayer()) then
	if Rad > 100 then
	 ply:SetNWFloat("Radiation", math.Clamp((ply:GetNWFloat("Radiation")) - 100, 0, 400))
	else
		ply:SetNWFloat("Radiation", 0)
	end
	DarkRP.StalNotify(ply,'Вы использовали: Анти-Рад')
	DarkRP.GiveEffect(ply, 'Rad', 4)

	ply:EmitSound('stalker/items/pills.mp3', 65,100,0.5)

	return self:TakeOne()
end
end
