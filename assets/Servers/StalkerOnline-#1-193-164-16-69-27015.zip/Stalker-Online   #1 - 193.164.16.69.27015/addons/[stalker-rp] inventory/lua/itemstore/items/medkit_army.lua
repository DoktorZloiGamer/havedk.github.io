ITEM.Name = "Аптечка Армейская"
ITEM.Description = "Восполняет здоровье\n + 75 к здоровью - 25 мЗв"
ITEM.HighlightColor = itemstore.config.HighlightColours.Other
ITEM.Base = "base_entity"
ITEM.Stackable = true
ITEM.DropStack = false
ITEM.MaxStack = 7

function ITEM:SaveData( ent )
	self:SetModel( ent:GetModel() )
end

function ITEM:Use( ply )
self.x = 75
		if ply:GetNWInt("Heal") > CurTime() && math.Round(ply:GetNWInt("Heal") - CurTime()) > 0 then DarkRP.notify(ply, 1, 4, 'Вы недавно получили урон. Осталось ждать ' .. math.Round(ply:GetNWInt("Heal") - CurTime()) .. ' сек.') return end

if ply:Health() >= 100 then return end
local Rad = ply:GetNWFloat("Radiation")

if (ply:IsPlayer()) then
	-- hp
	if ply:Health() + self.x < 100 then
		ply:SetHealth(ply:Health() + self.x)
	else
		ply:SetHealth(100)
	end
	-- rad
	if Rad < 25 then
		ply:SetNWFloat("Radiation", 0)
 	elseif Rad > 25 then
		ply:SetNWFloat("Radiation", math.Clamp((ply:GetNWFloat("Radiation")) - 25, 0, 400))
	end
	DarkRP.StalNotify(ply,'Вы использовали: Аптечка Армейская')
	DarkRP.GiveEffect(ply, 'Heal', 3)
	DarkRP.GiveEffect(ply, 'Rad', 3)
	ply:UseShot()
	ply:EmitSound('stalker/items/medkit.mp3', 65,100,0.5)

	return self:TakeOne()
end
end
