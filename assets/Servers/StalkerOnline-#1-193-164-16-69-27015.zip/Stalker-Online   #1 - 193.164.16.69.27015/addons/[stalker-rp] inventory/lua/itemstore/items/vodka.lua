ITEM.Name = "Водка"
ITEM.Description = "Народное средство\n - 50 мЗв"
ITEM.HighlightColor = itemstore.config.HighlightColours.Other
ITEM.Base = "base_entity"
ITEM.Stackable = true
ITEM.DropStack = false
ITEM.MaxStack = 10

function ITEM:SaveData( ent )
	self:SetModel( "models/kali/miscstuff/stalker/food/cossacks vodka.mdl" )
end

function ITEM:Use(ply)
local Rad = ply:GetNWFloat("Radiation")

if (ply:IsPlayer()) then
	if Rad > 50 then
	 ply:SetNWFloat("Radiation", math.Clamp((ply:GetNWFloat("Radiation")) - 50, 0, 400))
	else
		ply:SetNWFloat("Radiation", 0)
	end
	ply:EmitSound('stalker/items/eat/vodka.ogg', 65,100,0.5)

	local int = ply:GetNWInt("Drunk") - CurTime()
	if int > 0 then
		ply:SetNWInt("Drunk", ply:GetNWInt("Drunk") + 60)
		DarkRP.GiveEffect(ply, 'Anti-Psy', int + 60)
	else
		ply:SetNWInt("Drunk", CurTime() + 60)
		DarkRP.GiveEffect(ply, 'Anti-Psy',60)
	end
	if ply:GetNWInt("Drunk") > CurTime() + 300 then 
		ply:SetNWInt("Drunk", 300) 
		DarkRP.GiveEffect(ply, 'Anti-Psy', 300) 
	end

	DarkRP.StalNotify(ply,'Вы использовали: Водочка')
	DarkRP.GiveEffect(ply, 'Rad', 3)

	return self:TakeOne()
	-- net.Start('Vodka_Effect')
	-- net.Send(ply)
end

end
