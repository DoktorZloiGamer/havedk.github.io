DEFINE_BASECLASS( "DListLayout" )

surface.CreateFont('Tooltip_Small', {size = 21, weight = 600,	antialias = true,	extended = true,	font = "Default"})
surface.CreateFont('Tooltip_Small_Desc', {size = 16, weight = 600,	antialias = true,	extended = true,	font = "Default"})
local blur = Material( "pp/blurscreen" )

local PANEL = {}

AccessorFunc( PANEL, "ContainerID", "ContainerID", FORCE_NUMBER )
AccessorFunc( PANEL, "Slot", "Slot", FORCE_NUMBER )
AccessorFunc( PANEL, "Item", "Item" )

local function matafakablur( panel, layers, density, alpha )

	local x, y = panel:LocalToScreen(0, 0)

	surface.SetDrawColor( 255, 255, 255, alpha )
	surface.SetMaterial( blur )

	for i = 1, 3 do
	blur:SetFloat( "$blur", ( i / layers ) * density )
	blur:Recompute()

	render.UpdateScreenEffectTexture()
	surface.DrawTexturedRect( -x, -y, ScrW(), ScrH() )
	end

end

function PANEL:Init()
	self:SetWide( 200 )
	self:SetDrawOnTop( true )
	self:DockPadding( 5, 5, 5, 5 )

	self.Name = self:Add( "DLabel" )
	self.Name:SetFont( "DermaDefaultBold" )
	self.Name:SetWrap( true )

	self.Model = self:Add( "DModelPanel" )
	self.Model:SetSize( 300, 5 )

	self.Description = self:Add( "DLabel" )
	self.Description:SetWrap( true )
end
local clr_gray = Color(45,45,42,150)
PANEL.Blur = Material( "pp/blurscreen" )
function PANEL:Paint( w, h )
	self.Blur:SetFloat( "$blur", 8 )
	self.Blur:Recompute()
	render.UpdateScreenEffectTexture()

	matafakablur( self, 3, 3, 100 )

	local x, y = self:LocalToScreen( 0, 0 )
	-- self.teamColor = self.teamColor || team.GetColor(LocalPlayer():Team())
	-- local teamcolor2 = Color(color.r, color.g, color.b, 1.5)
  --draw.RoundedBox(0,2,2,w-4,h-4,Color(75,75,75,75))
  	draw.RoundedBox(3,0,0,w,h,clr_gray)

	surface.SetDrawColor(70,70,68, 50 )
	surface.DrawOutlinedRect( 0, 0, w, h, 1 )
end

function PANEL:PerformLayout()
	self.Name:SizeToContents()
	self.Description:SizeToContents()

	BaseClass.PerformLayout( self )
end

function PANEL:Refresh()
	local item = self:GetItem() || self.item
	if not item then
		self.Model.Entity:Remove()
		self.Name:SetText( "" )
		self.Description:SetText( "" )

		return
	end
	-- PrintTable(item)
	local name = item.GetName && item:GetName() || item.name
	--[[if table.HasValue(all_weapons,item) then
	local desc = 'Огнестрельное оружие' or ""
elseif table.HasValue(detecors_table,item) then
	local desc = 'Детектор артефактов' or ""
elseif table.HasValue(bolt_tables,item) then
	local desc = 'Обнаружение аномалий' or ""
elseif table.HasValue(knife_tables,item) then
	local desc = 'Холодное оружие' or ""
else--]]
	local desc =  (GAMEMODE && GAMEMODE.Config && GAMEMODE.Config.ItemDescription && GAMEMODE.Config.ItemDescription[item.Class == 'spawned_weapon' && item.Data.Class || item.Class]) || ""

	if item.GetAmount && item:GetAmount() > 1 then
		name = name .. "\n Количество: " .. item:GetAmount()
	end

	if self:GetSlot() then
		--desc = desc .. "\n\n" .. itemstore.Translate( "dragtomove" )
		--desc = desc .. "\n" .. itemstore.Translate( "mclicktodrop" )
		--desc = desc .. "\n" .. itemstore.Translate( "rclickforoptions" )

		if item.Use then
			--desc = desc .. "\n" .. itemstore.Translate( "dclicktouse" )
		end
	end

	self.Name:SetText( ' '..name )
	self.Name:SetFont('ItemStore_TooltipBIG')
	self.Name:SizeToContents()

	self.Description:SetFont('ItemStore_TooltipSmall')
	self.Description:SetText( ' '..desc )
	self.Description:SizeToContents()

	--self.Model:SetModel( item:GetModel() )

	--self.Model.Entity:SetMaterial( item:GetMaterial() )
	--self.Model:SetColor( item:GetColor() or color_white )

	--min, max = self.Model.Entity:GetRenderBounds()

	--self.Model:SetCamPos( Vector( 0.55, 0.55, 0.55 ) * min:Distance( max ) )
	--self.Model:SetLookAt( ( min + max ) / 2 )

	self:InvalidateLayout( true )
end

vgui.Register( "ItemStoreTooltip", PANEL, "DListLayout" )
