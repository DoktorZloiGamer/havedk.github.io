ITEM.Name = "Вспышка"
ITEM.Description = "Артефакт"
ITEM.HighlightColor = itemstore.config.HighlightColours.Other
ITEM.Base = "base_entity"
ITEM.Stackable = false
ITEM.DropStack = false
ITEM.MaxStack = 1

function ITEM:SaveData( ent )
	self:SetModel( ent:GetModel() )
end


