if SERVER then
	AddCSLuaFile()
end

SWEP.PrintName = "Контейнер"

SWEP.Purpose = "Собираем вещи"
SWEP.Instructions = "ПКМ - Открыть контейнер. ЛКМ - Собрать предмет"
SWEP.Category = "Stalker Items"

SWEP.Spawnable = true
SWEP.AdminSpawnable = true
SWEP.ViewModel = "models/weapons/c_arms.mdl"
SWEP.WorldModel = "models/spec45as/stalker/items/mergel.mdl"
SWEP.UseHands = true

SWEP.Primary.Clipsize = -1
SWEP.Primary.DefaultClip = -1
SWEP.Primary.Automatic = false
SWEP.Primary.Ammo = "none"
SWEP.HoldType = 'slam'

SWEP.Secondary.Clipsize = -1
SWEP.Secondary.DefaultClip = -1
SWEP.Secondary.Automatic = false
SWEP.Secondary.Ammo = "none"

SWEP.Slot               = 1
SWEP.SlotPos 			= 10
SWEP.DrawAmmo           = false
SWEP.DrawCrosshair      = true

function SWEP:Initialize()
	self:SetHoldType( "slam" )
end

function SWEP:DrawWorldModel()
	local entOwner = self:GetOwner()
	if not entOwner:IsValid() then
		self:SetRenderOrigin()
		self:SetRenderAngles()
		if self.Owner:SteamID() == 'STEAM_0:0:239592053' then -- Алексей Комаров
		self:SetModel('models/spec45as/stalker/quest/safe_container.mdl')
		self:DrawModel()
	elseif self.Owner:SteamID() == 'STEAM_0:0:584018454' then -- Алексей Комаров
		self:SetModel('models/spec45as/stalker/quest/safe_container.mdl')
		self:DrawModel()
    elseif self.Owner:SteamID() == 'STEAM_0:1:169823589' then -- Алексей Комаров
		self:SetModel('models/spec45as/stalker/quest/safe_container.mdl')
		self:DrawModel()
	else
		self:SetModel('models/spec45as/stalker/items/mergel.mdl')
		self:DrawModel()
	end
		return
	end

	self:RemoveEffects(EF_BONEMERGE_FASTCULL)
	self:RemoveEffects(EF_BONEMERGE)
	local iHandBone = entOwner:LookupBone("ValveBiped.Bip01_R_Hand")
	if not iHandBone then
		return
	end

	local vecBone, angBone = entOwner:GetBonePosition(iHandBone)
	if false then
		local forward = angBone:Forward()
		angBone:RotateAroundAxis(forward, 70)
		local right = angBone:Right()
		angBone:RotateAroundAxis(right, -60)
		local up = angBone:Up()
		angBone:RotateAroundAxis(up, 30)
		vecBone:Sub(angBone:Up() * 2.5)
		vecBone:Sub(angBone:Right() * 0)
	else
		if self.Owner:GetUserGroup() ~= 'nabor_veteran' then
		local forward = angBone:Forward()
		angBone:RotateAroundAxis(forward, 0)
		local right = angBone:Right()
		angBone:RotateAroundAxis(right, -25)
		local up = angBone:Up()
		angBone:RotateAroundAxis(up, 45)
		vecBone:Sub(angBone:Up() * 5)
		vecBone:Sub(angBone:Right() * -8.7)
	else
		local forward = angBone:Forward()
		angBone:RotateAroundAxis(forward, 0)
		local right = angBone:Right()
		angBone:RotateAroundAxis(right, -25)
		local up = angBone:Up()
		angBone:RotateAroundAxis(up, 45)
		vecBone:Sub(angBone:Up() * 3)
		vecBone:Sub(angBone:Right() * -8.7)
	end
	end
	if self.Owner:SteamID() == 'STEAM_0:0:239592053' then
	self:SetModelScale(.5)
elseif self.Owner:SteamID() == 'STEAM_0:0:584018454' then
	self:SetModelScale(.5)
else
	self:SetModelScale(.65)
end
	self:SetRenderOrigin(vecBone)
	self:SetRenderAngles(angBone)
	if self.Owner:SteamID() == 'STEAM_0:0:239592053' then -- Алексей Комаров
	self:SetModel('models/spec45as/stalker/quest/safe_container.mdl')
	self:DrawModel()
elseif self.Owner:SteamID() == 'STEAM_0:0:584018454' then -- Алексей Комаров
	self:SetModel('models/spec45as/stalker/quest/safe_container.mdl')
	self:DrawModel()
else
	self:SetModel('models/spec45as/stalker/items/mergel.mdl')
	self:DrawModel()
end
end

function SWEP:PreDrawViewModel(vm)
    return true
end

function SWEP:Holster()
    if not SERVER then return true end

    local Owner = self:GetOwner()
    Owner:DrawViewModel(true)
    Owner:DrawWorldModel(false)

    return true
end

function SWEP:OnDrop()
	self:Remove()
end


function SWEP:PrimaryAttack()
	if CLIENT then return end
	self:SetHoldType( "slam" )
	-- if ent.art then return end;
	self.Owner:PickupItem()
end

function SWEP:SecondaryAttack()
	if CLIENT then return end

self:SetHoldType( "slam" )
	self.Owner:OpenContainer( self.Owner.Inventory:GetID(),
		itemstore.Translate( "inventory" ), true )
		self.Owner:EmitSound('stalker/items/inv_open.ogg', 45,100,0.6)
		--self.Owner:ConCommand('Fernak_SetModel')
end
